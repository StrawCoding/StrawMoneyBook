import{M as C,L as p,P as S,a2 as E,_ as R,B as U,h as b,m as D,u as x,g as F,K as M,a1 as f,i as y,c as N,a as d,b as h,w as H,e as I,R as w,t as W,k as v,l as P,o as L,d as B}from"./index-DScjtQ38.js";async function a(e,r){const n=await p(e,r);return Number(n?.values?.[0]?.count??0)}async function A(e){const[r,n,l,_,o,m,t]=await Promise.all([a(`SELECT COUNT(*) AS count
       FROM transactions t
       LEFT JOIN accounts a
         ON a.ledger_id = t.ledger_id
        AND a.id = t.account_id
       WHERE t.ledger_id = ?
         AND t.deleted_at IS NULL
         AND a.id IS NULL;`,[e]),a(`SELECT COUNT(*) AS count
       FROM transactions t
       LEFT JOIN categories c
         ON c.ledger_id = t.ledger_id
        AND c.id = t.category_id
       WHERE t.ledger_id = ?
         AND t.deleted_at IS NULL
         AND t.category_id IS NOT NULL
         AND c.id IS NULL;`,[e]),a(`SELECT COUNT(*) AS count
       FROM reimbursements r
       LEFT JOIN transactions t
         ON t.ledger_id = r.ledger_id
        AND t.id = r.paid_tx_id
       WHERE r.ledger_id = ?
         AND r.deleted_at IS NULL
         AND r.status = 'paid'
         AND (r.paid_tx_id IS NULL OR t.id IS NULL);`,[e]),a(`SELECT COUNT(*) AS count
       FROM reimbursements r
       LEFT JOIN (
         SELECT ledger_id, reimbursement_id, COALESCE(SUM(amount_minor), 0) AS sum_minor
         FROM reimbursement_items
         GROUP BY ledger_id, reimbursement_id
       ) x
         ON x.ledger_id = r.ledger_id
        AND x.reimbursement_id = r.id
       WHERE r.ledger_id = ?
         AND r.deleted_at IS NULL
         AND COALESCE(x.sum_minor, 0) <> r.total_minor;`,[e]),a(`SELECT COUNT(*) AS count
       FROM (
         SELECT transfer_group_id,
                COUNT(*) AS leg_count,
                COALESCE(SUM(amount_minor), 0) AS balance
         FROM transactions
         WHERE ledger_id = ?
           AND deleted_at IS NULL
           AND type = 'transfer'
           AND transfer_group_id IS NOT NULL
         GROUP BY transfer_group_id
       ) z
       WHERE z.leg_count <> 2 OR z.balance <> 0;`,[e]),a(`SELECT COUNT(*) AS count
       FROM (
         SELECT l.id,
                l.principal_minor,
                COALESCE(SUM(lp.amount_minor), 0) AS paid_minor
         FROM loans l
         LEFT JOIN loan_payments lp
           ON lp.ledger_id = l.ledger_id
          AND lp.loan_id = l.id
         WHERE l.ledger_id = ?
           AND l.deleted_at IS NULL
           AND l.status <> 'void'
         GROUP BY l.id
       ) z
       WHERE z.paid_minor > z.principal_minor;`,[e]),a(`SELECT COUNT(*) AS count
       FROM (
         SELECT l.id,
                l.status,
                l.principal_minor,
                COALESCE(SUM(lp.amount_minor), 0) AS paid_minor,
                CASE
                  WHEN l.status = 'void' THEN 'void'
                  WHEN COALESCE(SUM(lp.amount_minor), 0) <= 0 THEN 'active'
                  WHEN COALESCE(SUM(lp.amount_minor), 0) >= l.principal_minor THEN 'settled'
                  ELSE 'partial'
                END AS expected_status
         FROM loans l
         LEFT JOIN loan_payments lp
           ON lp.ledger_id = l.ledger_id
          AND lp.loan_id = l.id
         WHERE l.ledger_id = ?
           AND l.deleted_at IS NULL
         GROUP BY l.id
       ) z
       WHERE z.status <> z.expected_status;`,[e])]);return{orphanTxAccount:r,orphanTxCategory:n,missingPaidTransaction:l,reimbursementTotalMismatch:_,invalidTransferGroups:o,overpaidLoans:m,loanStatusMismatch:t}}async function J(e){return C(async()=>{const r={reimbursementTotalFixed:0,reimbursementPaidStateFixed:0,loanStatusFixed:0},n=await a(`SELECT COUNT(*) AS count
       FROM reimbursements r
       LEFT JOIN (
         SELECT ledger_id, reimbursement_id, COALESCE(SUM(amount_minor), 0) AS sum_minor
         FROM reimbursement_items
         GROUP BY ledger_id, reimbursement_id
       ) x
         ON x.ledger_id = r.ledger_id
        AND x.reimbursement_id = r.id
       WHERE r.ledger_id = ?
         AND r.deleted_at IS NULL
         AND COALESCE(x.sum_minor, 0) <> r.total_minor;`,[e]);await S(`UPDATE reimbursements
       SET total_minor = (
             SELECT COALESCE(SUM(amount_minor), 0)
             FROM reimbursement_items
             WHERE ledger_id = reimbursements.ledger_id
               AND reimbursement_id = reimbursements.id
           ),
           updated_at = ?
       WHERE ledger_id = ?
         AND deleted_at IS NULL;`,[E(),e]);const l=await a(`SELECT COUNT(*) AS count
       FROM reimbursements r
       LEFT JOIN (
         SELECT ledger_id, reimbursement_id, COALESCE(SUM(amount_minor), 0) AS sum_minor
         FROM reimbursement_items
         GROUP BY ledger_id, reimbursement_id
       ) x
         ON x.ledger_id = r.ledger_id
        AND x.reimbursement_id = r.id
       WHERE r.ledger_id = ?
         AND r.deleted_at IS NULL
         AND COALESCE(x.sum_minor, 0) <> r.total_minor;`,[e]);r.reimbursementTotalFixed=Math.max(0,n-l);const _=await S(`UPDATE reimbursements
       SET status = 'approved',
           paid_at = NULL,
           paid_tx_id = NULL,
           updated_at = ?
       WHERE ledger_id = ?
         AND deleted_at IS NULL
         AND status = 'paid'
         AND (
           paid_tx_id IS NULL OR NOT EXISTS (
             SELECT 1
             FROM transactions t
             WHERE t.ledger_id = reimbursements.ledger_id
               AND t.id = reimbursements.paid_tx_id
               AND t.deleted_at IS NULL
           )
         );`,[E(),e]);r.reimbursementPaidStateFixed=Number(_?.changes?.changes??0);const o=(await p(`SELECT
           l.id,
           l.status,
           l.principal_minor,
           COALESCE(SUM(lp.amount_minor), 0) AS paid_minor
         FROM loans l
         LEFT JOIN loan_payments lp
           ON lp.ledger_id = l.ledger_id
          AND lp.loan_id = l.id
         WHERE l.ledger_id = ?
           AND l.deleted_at IS NULL
         GROUP BY l.id;`,[e]))?.values??[];for(const t of o){if(t.status==="void")continue;let i="active";Number(t.paid_minor)>0&&Number(t.paid_minor)<Number(t.principal_minor)&&(i="partial"),Number(t.paid_minor)>=Number(t.principal_minor)&&(i="settled"),t.status!==i&&(await S(`UPDATE loans
           SET status = ?,
               settled_at = ?,
               updated_at = ?
           WHERE ledger_id = ?
             AND id = ?;`,[i,i==="settled"?E():null,E(),e,t.id]),r.loanStatusFixed+=1)}const m=await A(e);return{fixed:r,after:m}})}const k={class:"stack"},z={class:"card panel"},G={class:"row"},Y={key:0,class:"report"},V={__name:"SettingsRepairPage",setup(e){const r=U(),n=b(),l=D(),_=x(),o=F(),m=M(),t=f(),i=y(),u=P("");async function O(){await Promise.all([l.load(),n.load(),_.loadRecent(),o.loadMonth(o.monthKey),m.load(),t.load()])}async function g(){try{const s=await A(r.activeLedgerId);u.value=JSON.stringify(s,null,2),i.pushToast("掃描完成")}catch(s){i.pushToast(s.message??"掃描失敗","error")}}async function T(){try{const s=await J(r.activeLedgerId);u.value=JSON.stringify(s,null,2),await O(),i.pushToast("修復完成")}catch(s){i.pushToast(s.message??"修復失敗","error")}}return(s,c)=>(L(),N("section",k,[d("article",z,[d("header",G,[c[1]||(c[1]=d("h2",null,"資料修復工具",-1)),h(I(w),{class:"back-link",to:"/settings"},{default:H(()=>[...c[0]||(c[0]=[B("返回",-1)])]),_:1})]),d("div",{class:"row tool-row"},[d("button",{class:"btn",onClick:g},"掃描問題"),d("button",{class:"btn primary",onClick:T},"執行修復")]),u.value?(L(),N("pre",Y,W(u.value),1)):v("",!0)])]))}},q=R(V,[["__scopeId","data-v-66077aa5"]]);export{q as default};
