import{L as d}from"./index-DScjtQ38.js";const h=["account_groups","accounts","category_groups","categories","transactions","transaction_attachments","counterparties","loans","loan_payments","reimbursements","reimbursement_items","budgets","budget_items","app_settings","deleted_log"];function R(t){if(t==null)return"";const e=String(t);return e.includes(",")||e.includes('"')||e.includes(`
`)?`"${e.replaceAll('"','""')}"`:e}function f(t){return t==null?"":String(t).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&apos;")}function p(t){if(!t.length)return"";const e=Object.keys(t[0]),n=[e.join(",")];for(const r of t)n.push(e.map(a=>R(r[a])).join(","));return n.join(`
`)}function w(t,e,n){const r=e.map(o=>`<Cell><Data ss:Type="String">${f(o)}</Data></Cell>`).join(""),a=n.map(o=>`<Row>${e.map(l=>`<Cell><Data ss:Type="String">${f(o[l]??"")}</Data></Cell>`).join("")}</Row>`).join("");return`<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
  <Worksheet ss:Name="${f(t)}">
    <Table>
      <Row>${r}</Row>
      ${a}
    </Table>
  </Worksheet>
</Workbook>`}function E(t){const[e,n]=String(t??"").split("-").map(o=>Number(o)),r=new Date(e,n-1,1,0,0,0),a=new Date(e,n,1,0,0,0);return{startUtc:r.toISOString(),endUtc:a.toISOString()}}function D(t){const e=Number(t),n=new Date(e,0,1,0,0,0),r=new Date(e+1,0,1,0,0,0);return{startUtc:n.toISOString(),endUtc:r.toISOString()}}function L(t){const[e,n,r]=String(t??"").split("-").map(s=>Number(s)),a=new Date(e,n-1,r,0,0,0),o=new Date(e,n-1,r+1,0,0,0);return{startUtc:a.toISOString(),endUtc:o.toISOString()}}function O(t,e){const[n,r,a]=String(t??"").split("-").map(u=>Number(u)),[o,s,l]=String(e??"").split("-").map(u=>Number(u)),i=new Date(n,r-1,a,0,0,0),g=new Date(o,s-1,l+1,0,0,0);return{startUtc:i.toISOString(),endUtc:g.toISOString()}}function U(t,e={}){return t==="year"?D(e.yearKey):t==="month"?E(e.monthKey):t==="day"?L(e.dayKey):t==="custom"?O(e.startDate,e.endDate):{startUtc:null,endUtc:null}}const N=["類型","記帳時間","交易帳戶","交易帳本","貨幣符號","交易金額","一級分類","二級分類","交易標籤","備註","退款&轉銷","收回","歸還","手續費","匯率"];async function m(t,e){return(await d(`SELECT * FROM ${e} WHERE ledger_id = ?;`,[t]))?.values??[]}async function C(t){const e={schema_version:0,exported_at:new Date().toISOString(),ledger_id:t,tables:{}},n=await d("SELECT MAX(version) AS version FROM schema_migrations;");e.schema_version=Number(n?.values?.[0]?.version??0);const r=await d("SELECT * FROM ledgers WHERE id = ?;",[t]);e.tables.ledgers=r?.values??[];for(const a of h)e.tables[a]=await m(t,a);return e}async function v(t){const e=await m(t,"transactions");return p(e)}async function j(t){const e=await m(t,"accounts");return p(e)}async function F(t){const e=await m(t,"categories");return p(e)}async function I(t,e={}){const n=["all","year","month","day","custom"].includes(e.mode)?e.mode:"all",{startUtc:r,endUtc:a}=U(n,e),o=[t];let s="";r&&a&&(s=" AND t.occurred_at >= ? AND t.occurred_at < ?",o.push(r,a));const i=((await d(`SELECT
       t.type,
       t.occurred_at,
       t.note,
       t.origin_type,
       t.amount_minor,
       a.name AS account_name,
       a.currency_code,
       l.name AS ledger_name,
       cg.name AS category_group_name,
       c.name AS category_name
     FROM transactions t
     LEFT JOIN accounts a
       ON a.ledger_id = t.ledger_id
      AND a.id = t.account_id
     LEFT JOIN ledgers l
       ON l.id = t.ledger_id
     LEFT JOIN categories c
       ON c.ledger_id = t.ledger_id
      AND c.id = t.category_id
     LEFT JOIN category_groups cg
       ON cg.ledger_id = c.ledger_id
      AND cg.id = c.group_id
     WHERE t.ledger_id = ?
       AND t.deleted_at IS NULL
       ${s}
     ORDER BY t.occurred_at ASC, t.created_at ASC;`,o))?.values??[]).map(c=>{const b=Number(c.amount_minor??0)/100;return{類型:c.type==="expense"?"支出":c.type==="income"?"收入":c.type==="transfer"?"轉帳":"調整",記帳時間:c.occurred_at??"",交易帳戶:c.account_name??"",交易帳本:c.ledger_name??"",貨幣符號:c.currency_code??"TWD",交易金額:String(b),一級分類:c.category_group_name??"",二級分類:c.category_name??"",交易標籤:c.origin_type??"",備註:c.note??"","退款&轉銷":"",收回:"",歸還:"",手續費:"",匯率:"1"}}),g=i[0]?.交易帳本||"ledger",y=`${String(g).replace(/[\\/:*?"<>|]/g,"_")}_transactions_${n}_${new Date().toISOString().slice(0,10)}.xls`,S=w("Transactions",N,i);return{filename:y,xmlText:S,rowCount:i.length}}function $(t,e){const n=new Blob([JSON.stringify(e,null,2)],{type:"application/json"});_(t,n)}function k(t,e){const n=new Blob([e],{type:"text/csv;charset=utf-8"});_(t,n)}function B(t){const e=new Blob([`\uFEFF${t}`],{type:"application/vnd.ms-excel;charset=utf-8"});return URL.createObjectURL(e)}function M(t){t&&URL.revokeObjectURL(t)}function x(t,e){if(!t)return;const n=document.createElement("a");n.href=t,n.download=e,document.body.appendChild(n),n.click(),n.remove()}function _(t,e){const n=URL.createObjectURL(e);x(n,t),URL.revokeObjectURL(n)}export{C as a,v as b,B as c,$ as d,I as e,j as f,F as g,k as h,M as r,x as t};
