package com.strawcoding.moneybook;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
