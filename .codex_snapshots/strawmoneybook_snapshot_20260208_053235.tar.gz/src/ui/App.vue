<template>
  <div class="app-shell">
    <header class="top-bar">
      <div class="title-wrap">
        <img class="brand-logo" src="@/ui/assets/logo.png" alt="StrawMoneyBook logo" />
        <h1>StrawMoneyBook</h1>
      </div>
      <RouterLink v-if="route.name === 'home'" class="menu-btn" aria-label="開啟選單" to="/features">
        <font-awesome-icon icon="fa-solid fa-bars" />
      </RouterLink>
    </header>

    <main class="page-container">
      <router-view v-slot="{ Component, route }">
        <transition name="route-slide" mode="out-in">
          <component :is="Component" :key="route.fullPath" />
        </transition>
      </router-view>
    </main>

    <BottomNav />
    <ToastHost />
  </div>
</template>

<script setup>
import { useRoute, RouterLink } from 'vue-router'
import BottomNav from '@/ui/components/layout/BottomNav.vue'
import ToastHost from '@/ui/components/common/ToastHost.vue'

const route = useRoute()
</script>

<style scoped>
.app-shell{
  padding-top: 35px;
}
.title-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
}

.brand-logo {
  width: 40px;
  height: 40px;
  border-radius: 10px;
}

.menu-btn {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  border: 1px solid var(--border);
  color: var(--text);
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: #162030;
}
</style>
