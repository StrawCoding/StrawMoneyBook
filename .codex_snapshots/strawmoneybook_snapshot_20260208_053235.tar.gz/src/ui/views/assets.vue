<template>
  <section class="stack">
    <header class="row page-header">
      <h2 class="page-title">資產</h2>
      <button class="btn" @click="isManageMode = !isManageMode">
        {{ isManageMode ? '完成' : '管理' }}
      </button>
    </header>

    <article class="card panel">
      <header class="row">
        <h3>目前帳本</h3>
      </header>
      <LedgerSwitcher />
    </article>
    <article class="card panel">
      <header class="row">
        <h3>資產簡表</h3>
      </header>
      <div class="summary-grid">
        <div class="summary-item">
          <small class="muted">可支配</small>
          <MoneyText :value-minor="disposableMinor" />
        </div>
        <div class="summary-item">
          <small class="muted">負債</small>
          <MoneyText :value-minor="liabilityMinor" />
        </div>
        <div class="summary-item">
          <small class="muted">借出</small>
          <MoneyText :value-minor="loanStore.summary.totalReceivable" />
        </div>
        <div class="summary-item">
          <small class="muted">借入</small>
          <MoneyText :value-minor="loanStore.summary.totalPayable" />
        </div>
      </div>
    </article>



    <article class="card panel">
      <header class="row">
        <h3>資產帳戶</h3>
        <button v-if="isManageMode" class="btn mini-btn" @click="addGroup">新增群組</button>
      </header>

      <ul class="group-list">
        <li v-for="group in accountStore.groupSummaries" :key="group.id" class="group-item">
          <div class="row">
            <h3>{{ group.name }}</h3>
            <div class="group-meta">
              <MoneyText :value-minor="group.totalMinor" />
              <button v-if="isManageMode" class="btn mini-btn" @click="addAccount(group.id)">新增帳戶</button>
            </div>
          </div>

          <ul class="account-list">
            <li v-for="account in accountsByGroup(group.id)" :key="account.id" class="row account-row">
              <RouterLink :to="`/accounts/${account.id}`">{{ account.name }}</RouterLink>
              <div class="account-meta">
                <MoneyText :value-minor="balanceOf(account.id)" />
                <button v-if="isManageMode" class="btn mini-btn danger" @click="removeAccount(account.id, account.name)">
                  刪除/封存
                </button>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </article>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import { useAccountStore } from '@/ui/stores/account.store'
import { useLoanStore } from '@/ui/stores/loan.store'
import { useUiStore } from '@/ui/stores/ui.store'
import LedgerSwitcher from '@/ui/components/common/LedgerSwitcher.vue'

const accountStore = useAccountStore()
const loanStore = useLoanStore()
const uiStore = useUiStore()
const isManageMode = ref(false)

const disposableMinor = computed(() => {
  return accountStore.balances
    .filter((item) => item.account_type === 'asset')
    .reduce((total, item) => total + Number(item.balance_minor ?? 0), 0)
})

const liabilityMinor = computed(() => {
  return accountStore.balances
    .filter((item) => item.account_type === 'liability')
    .reduce((total, item) => total + Math.abs(Number(item.balance_minor ?? 0)), 0)
})

function accountsByGroup(groupId) {
  return accountStore.accounts.filter((account) => account.group_id === groupId)
}

function balanceOf(accountId) {
  return Number(accountStore.balances.find((item) => item.id === accountId)?.balance_minor ?? 0)
}

async function addGroup() {
  const name = window.prompt('群組名稱')
  if (!name?.trim()) return

  try {
    await accountStore.addGroup({
      name: name.trim(),
      type: 'other',
      sortOrder: accountStore.groups.length,
    })
    uiStore.pushToast('群組已新增')
  } catch (error) {
    uiStore.pushToast(error.message ?? '新增失敗', 'error')
  }
}

async function addAccount(groupId) {
  const name = window.prompt('帳戶名稱')
  if (!name?.trim()) return

  const openingText = window.prompt('期初金額（元，可小數）', '0')
  if (openingText === null) return
  const openingMajor = Number(openingText)
  if (!Number.isFinite(openingMajor)) {
    uiStore.pushToast('期初金額格式錯誤', 'error')
    return
  }

  try {
    const currentCount = accountStore.accounts.filter((account) => account.group_id === groupId).length
    await accountStore.addAccount({
      groupId,
      name: name.trim(),
      accountType: 'asset',
      allowNegative: true,
      openingBalanceMinor: Math.round(openingMajor * 100),
      sortOrder: currentCount,
    })
    uiStore.pushToast('帳戶已新增')
  } catch (error) {
    uiStore.pushToast(error.message ?? '新增帳戶失敗', 'error')
  }
}

async function removeAccount(accountId, accountName) {
  const ok = window.confirm(`確定要刪除/封存「${accountName}」？`)
  if (!ok) return

  try {
    await accountStore.removeAccount(accountId)
    uiStore.pushToast('帳戶已處理')
  } catch (error) {
    uiStore.pushToast(error.message ?? '刪除帳戶失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2,
h3 {
  margin: 0;
}

.page-title {
  font-size: 24px;
}

.page-header {
  align-items: center;
}

.group-list,
.account-list {
  list-style: none;
  margin: 0;
  padding: 0;
}

.summary-grid {
  margin-top: 10px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.summary-item {
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px;
  display: grid;
  gap: 6px;
}

.group-list {
  margin-top: 12px;
  display: grid;
  gap: 12px;
}

.group-item {
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 10px;
}

.group-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  justify-content: flex-end;
}

.account-list {
  margin-top: 8px;
  display: grid;
  gap: 6px;
}

.account-row {
  align-items: center;
  padding-left: 16px;
}

.account-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  justify-content: flex-end;
}

a {
  color: var(--text);
  text-decoration: none;
}

.danger {
  background: #4a1f1f;
  color: #ffdede;
}

.mini-btn {
  padding: 10px 12px;
  font-size: inherit;
  border-radius: 12px;
}
</style>
