<template>
  <section class="stack">
    <h2>設定</h2>

    <RouterLink class="card panel item-link" to="/settings/export">匯出資料</RouterLink>
    <RouterLink class="card panel item-link" to="/settings/import">匯入資料</RouterLink>
    <RouterLink class="card panel item-link" to="/settings/repair">資料修復工具</RouterLink>
    <RouterLink class="card panel item-link" to="/settings/ledgers">帳本管理</RouterLink>
    <RouterLink class="card panel item-link" to="/settings/categories">分類管理</RouterLink>
    <RouterLink class="card panel item-link" to="/settings/personalization">個人化</RouterLink>
  </section>
</template>

<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 24px;
}

.item-link {
  display: block;
  text-decoration: none;
  color: var(--text);
  font-weight: 700;
}
</style>
