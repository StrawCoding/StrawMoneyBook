<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>搜尋交易</h2>
        <RouterLink class="btn" to="/">返回</RouterLink>
      </header>
      <input
        v-model.trim="keyword"
        class="input"
        type="search"
        placeholder="搜尋分類、帳戶、備註、金額、日期"
      />
      <small class="muted">共 {{ filteredTransactions.length }} 筆</small>
    </article>

    <article class="card panel">
      <ul class="tx-list">
        <li
          v-for="tx in filteredTransactions"
          :key="tx.id"
          class="tx-item"
          role="button"
          tabindex="0"
          @click="openEdit(tx)"
        >
          <div class="tx-main">
            <strong>{{ labelOfTransaction(tx) }}</strong>
            <small class="muted">{{ accountName(tx.account_id) }} ・ {{ formatTime(tx.occurred_at) }}</small>
            <small class="muted">{{ tx.note || '-' }}</small>
          </div>
          <MoneyText :value-minor="tx.amount_minor" />
        </li>
        <li v-if="!filteredTransactions.length" class="muted empty">找不到符合條件的交易</li>
      </ul>
    </article>

    <HomeTransactionEditSheet
      :open="isEditOpen"
      :tx="editingTx"
      @close="closeEdit"
      @saved="loadTransactions"
    />
  </section>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import HomeTransactionEditSheet from '@/ui/components/home/HomeTransactionEditSheet.vue'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useAccountStore } from '@/ui/stores/account.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { listAllTransactions } from '@/core/repositories/transaction.repo'

const ledgerStore = useLedgerStore()
const categoryStore = useCategoryStore()
const accountStore = useAccountStore()
const uiStore = useUiStore()

const keyword = ref('')
const transactions = ref([])
const isEditOpen = ref(false)
const editingTx = ref(null)

onMounted(() => {
  void loadTransactions()
})

watch(
  () => ledgerStore.activeLedgerId,
  () => {
    void loadTransactions()
  },
)

const filteredTransactions = computed(() => {
  const query = keyword.value.toLowerCase()
  if (!query) return transactions.value

  return transactions.value.filter((tx) => {
    const category = categoryName(tx.category_id)
    const account = accountName(tx.account_id)
    const amount = String(Math.abs(Number(tx.amount_minor ?? 0)) / 100)
    const time = formatTime(tx.occurred_at)
    const note = String(tx.note ?? '')
    const text = `${category} ${account} ${amount} ${time} ${note}`.toLowerCase()
    return text.includes(query)
  })
})

async function loadTransactions() {
  const ledgerId = ledgerStore.activeLedgerId
  if (!ledgerId) {
    transactions.value = []
    return
  }

  try {
    transactions.value = await listAllTransactions(ledgerId)
  } catch (error) {
    uiStore.pushToast(error.message ?? '載入交易失敗', 'error')
  }
}

function openEdit(tx) {
  if (!tx) return
  if (tx.type === 'transfer') {
    uiStore.pushToast('目前不支援編輯轉帳交易')
    return
  }
  editingTx.value = tx
  isEditOpen.value = true
}

function closeEdit() {
  isEditOpen.value = false
  editingTx.value = null
}

function labelOfTransaction(tx) {
  const category = categoryName(tx.category_id)
  if (category) return category
  if (tx.type === 'transfer') return '轉帳'
  if (tx.type === 'adjustment') return '調整'
  return tx.type === 'income' ? '收入' : '支出'
}

function categoryName(categoryId) {
  return categoryStore.categories.find((item) => item.id === categoryId)?.name || ''
}

function accountName(accountId) {
  return accountStore.accounts.find((item) => item.id === accountId)?.name || '未知帳戶'
}

function formatTime(iso) {
  if (!iso) return '-'
  return new Date(iso).toLocaleString('zh-TW', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.tx-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.tx-item {
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
}

.tx-main {
  display: grid;
  gap: 3px;
}

.empty {
  text-align: center;
  padding: 12px;
}
</style>
