<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>{{ accountName }}</h2>
        <button class="btn" @click="refresh">刷新</button>
      </header>
      <p class="muted">最近 {{ transactions.length }} 筆交易</p>
      <ul class="list">
        <li v-for="tx in transactions" :key="tx.id" class="row entry">
          <span>{{ tx.type }}</span>
          <MoneyText :value-minor="tx.amount_minor" />
        </li>
      </ul>
    </article>
  </section>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useAccountStore } from '@/ui/stores/account.store'
import { listTransactionsByAccount } from '@/core/repositories/transaction.repo'
import MoneyText from '@/ui/components/common/MoneyText.vue'

const route = useRoute()
const ledgerStore = useLedgerStore()
const accountStore = useAccountStore()
const transactions = ref([])

const accountName = computed(() => {
  const id = route.params.id
  return accountStore.accounts.find((item) => item.id === id)?.name ?? '帳戶流水'
})

async function refresh() {
  const ledgerId = ledgerStore.activeLedgerId
  const accountId = route.params.id
  transactions.value = await listTransactionsByAccount(ledgerId, accountId)
}

onMounted(() => {
  refresh()
})
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
}

.list {
  list-style: none;
  margin: 8px 0 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.entry {
  border-radius: 10px;
  padding: 10px;
  border: 1px solid var(--border);
}
</style>
