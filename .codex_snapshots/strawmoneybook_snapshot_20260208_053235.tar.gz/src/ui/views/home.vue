<template>
  <section class="stack">
    <article class="card ledger-card">
      <header class="row">
        <h3>目前帳本</h3>
      </header>
      <LedgerSwitcher />
      <div class="period-tabs">
        <button
          v-for="mode in filterModes"
          :key="mode.value"
          class="btn tab-btn"
          :class="{ primary: filterMode === mode.value }"
          @click="switchFilterMode(mode.value)"
        >
          {{ mode.label }}
        </button>
      </div>
      <div class="row month-row">
        <span class="muted">查看範圍</span>
        <div class="all-range">{{ filterMode === 'all' ? '全部交易' : displayRange }}</div>
      </div>
      <div v-if="filterMode !== 'all'" class="picker-row">
        <HomeRangePicker
          v-if="filterMode === 'month'"
          mode="month"
          :month="selectedMonth"
          class="picker-input"
          @update:month="pickMonth"
        />
        <HomeRangePicker
          v-else-if="filterMode === 'day'"
          mode="day"
          :day="selectedDay"
          class="picker-input"
          @update:day="pickDay"
        />
        <HomeRangePicker
          v-else
          mode="year"
          :year="selectedYear"
          class="picker-input"
          @update:year="pickYear"
        />
        <button class="btn quick-btn" :disabled="budgetStore.loading" @click="goCurrentRange">
          {{ currentRangeLabel }}
        </button>
      </div>
    </article>

    <HomeAssetSummaryCard />
    <HomeBudgetSummaryCard />
    <HomeTransactionFeed />

    <teleport to="body">
      <button class="fab btn primary" @click="isSheetOpen = true">+ 快速新增</button>
    </teleport>
    <QuickAddSheet :open="isSheetOpen" @close="isSheetOpen = false" />
  </section>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import HomeAssetSummaryCard from '@/ui/components/home/HomeAssetSummaryCard.vue'
import HomeBudgetSummaryCard from '@/ui/components/home/HomeBudgetSummaryCard.vue'
import HomeTransactionFeed from '@/ui/components/home/HomeTransactionFeed.vue'
import QuickAddSheet from '@/ui/components/home/QuickAddSheet.vue'
import LedgerSwitcher from '@/ui/components/common/LedgerSwitcher.vue'
import HomeRangePicker from '@/ui/components/common/HomeRangePicker.vue'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useBudgetStore } from '@/ui/stores/budget.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useUiStore } from '@/ui/stores/ui.store'

const isSheetOpen = ref(false)
const ledgerStore = useLedgerStore()
const budgetStore = useBudgetStore()
const transactionStore = useTransactionStore()
const uiStore = useUiStore()
const filterMode = ref('month')
const selectedMonth = ref(budgetStore.monthKey || monthKeyFromDate(new Date()))
const selectedDay = ref(dateKeyFromDate(new Date()))
const selectedYear = ref(Number(new Date().getFullYear()))
const filterModes = [
  { value: 'all', label: '全部' },
  { value: 'year', label: '年' },
  { value: 'month', label: '月' },
  { value: 'day', label: '日' },
]

watch(
  () => ledgerStore.activeLedgerId,
  (ledgerId) => {
    if (!ledgerId) return
    void syncHomeTransactions()
  },
  { immediate: true },
)

async function syncHomeTransactions() {
  try {
    if (filterMode.value === 'all') {
      await transactionStore.loadHomeAll()
      return
    }
    if (filterMode.value === 'year') {
      await transactionStore.loadHomeYear(String(selectedYear.value))
      return
    }
    if (filterMode.value === 'day') {
      await transactionStore.loadHomeDay(selectedDay.value)
      return
    }
    await transactionStore.loadHomeMonth(selectedMonth.value)
  } catch (error) {
    uiStore.pushToast(error.message ?? '載入首頁交易失敗', 'error')
  }
}

async function switchFilterMode(nextMode) {
  filterMode.value = nextMode
  if (nextMode === 'month' && budgetStore.monthKey) {
    selectedMonth.value = budgetStore.monthKey
  }
  await syncHomeTransactions()
}

async function goCurrentRange() {
  if (filterMode.value === 'year') {
    selectedYear.value = Number(new Date().getFullYear())
    await syncHomeTransactions()
    return
  }
  if (filterMode.value === 'day') {
    selectedDay.value = dateKeyFromDate(new Date())
    await syncHomeTransactions()
    return
  }
  const monthKey = monthKeyFromDate(new Date())
  selectedMonth.value = monthKey
  try {
    await budgetStore.loadMonth(monthKey)
    await syncHomeTransactions()
  } catch (error) {
    uiStore.pushToast(error.message ?? '月份切換失敗', 'error')
  }
}

async function applyMonthInput() {
  if (!selectedMonth.value) return
  try {
    await budgetStore.loadMonth(selectedMonth.value)
    await syncHomeTransactions()
  } catch (error) {
    uiStore.pushToast(error.message ?? '月份切換失敗', 'error')
  }
}

async function pickMonth(value) {
  selectedMonth.value = value
  await applyMonthInput()
}

async function pickDay(value) {
  selectedDay.value = value
  await syncHomeTransactions()
}

async function pickYear(value) {
  selectedYear.value = Number(value)
  await syncHomeTransactions()
}

const displayRange = computed(() => {
  if (filterMode.value === 'year') return `${selectedYear.value} 年`
  if (filterMode.value === 'day') return selectedDay.value || '-'
  const [year, month] = String(selectedMonth.value ?? '').split('-')
  if (!year || !month) return '-'
  return `${year} 年 ${month} 月`
})

const currentRangeLabel = computed(() => {
  if (filterMode.value === 'year') return '今年'
  if (filterMode.value === 'day') return '今天'
  return '本月'
})

function monthKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}`
}

function dateKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

</script>

<style scoped>
.ledger-card {
  padding: 14px;
}

.month-row {
  margin-top: 10px;
}

.period-tabs {
  margin-top: 10px;
  display: grid;
  gap: 8px;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.tab-btn {
  padding: 8px 0;
}

.all-range {
  font-weight: 700;
}

.picker-row {
  margin-top: 8px;
  display: flex;
  gap: 8px;
  align-items: center;
}

.picker-input {
  flex: 1;
}

.quick-btn {
  white-space: nowrap;
}

h3 {
  margin: 0;
  font-size: 16px;
}

.fab {
  position: fixed;
  right: 15px;
  bottom: 92px;
  border-radius: 999px;
  padding: 12px 18px;
  box-shadow: var(--shadow);
}
</style>
