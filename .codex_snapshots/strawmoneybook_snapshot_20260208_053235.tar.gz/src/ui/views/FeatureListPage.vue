<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>功能列表</h2>
        <RouterLink class="btn" to="/">返回</RouterLink>
      </header>
      <nav class="feature-list">
        <RouterLink class="feature-link" to="/loans">借貸</RouterLink>
        <RouterLink class="feature-link" to="/reimbursements">報銷</RouterLink>
        <RouterLink class="feature-link" to="/transactions/search">搜尋交易</RouterLink>
      </nav>
    </article>
  </section>
</template>

<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.feature-list {
  margin-top: 12px;
  display: grid;
  gap: 8px;
}

.feature-link {
  text-decoration: none;
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 12px;
  background: #152133;
  font-weight: 700;
}
</style>
