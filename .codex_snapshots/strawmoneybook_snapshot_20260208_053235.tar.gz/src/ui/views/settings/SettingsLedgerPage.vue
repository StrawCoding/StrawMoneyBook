<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>帳本管理</h2>
        <RouterLink class="back-link" to="/settings">返回</RouterLink>
      </header>

      <div class="row action-row">
        <button class="btn primary" @click="createLedger">新增帳本</button>
      </div>

      <ul class="ledger-list">
        <li v-for="ledger in ledgerStore.ledgers" :key="ledger.id" class="row">
          <span>{{ ledger.name }}</span>
          <div class="btn-wrap">
            <button class="btn" @click="rename(ledger.id, ledger.name)">改名</button>
            <button class="btn" @click="remove(ledger.id)">刪除</button>
          </div>
        </li>
      </ul>
    </article>
  </section>
</template>

<script setup>
import { RouterLink } from 'vue-router'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useUiStore } from '@/ui/stores/ui.store'

const ledgerStore = useLedgerStore()
const uiStore = useUiStore()

async function rename(ledgerId, currentName) {
  const nextName = window.prompt('帳本新名稱', currentName)
  if (!nextName?.trim()) return

  try {
    await ledgerStore.renameLedger(ledgerId, nextName.trim())
    uiStore.pushToast('帳本已改名')
  } catch (error) {
    uiStore.pushToast(error.message ?? '改名失敗', 'error')
  }
}

async function createLedger() {
  const name = window.prompt('新帳本名稱')
  if (!name?.trim()) return

  try {
    await ledgerStore.addLedger({
      name: name.trim(),
      currencyCode: 'TWD',
      timezone: 'Asia/Taipei',
    })
    uiStore.pushToast('帳本已建立')
  } catch (error) {
    uiStore.pushToast(error.message ?? '建立帳本失敗', 'error')
  }
}

async function remove(ledgerId) {
  const ok = window.confirm('刪除帳本前請先匯出。確定刪除？')
  if (!ok) return

  try {
    await ledgerStore.removeLedger(ledgerId)
    uiStore.pushToast('帳本已刪除')
  } catch (error) {
    uiStore.pushToast(error.message ?? '刪除失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.back-link {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.action-row {
  margin-top: 10px;
}

.ledger-list {
  list-style: none;
  margin: 12px 0 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.btn-wrap {
  display: flex;
  gap: 6px;
}
</style>
