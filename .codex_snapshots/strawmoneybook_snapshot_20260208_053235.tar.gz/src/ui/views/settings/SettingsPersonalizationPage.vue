<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>個人化</h2>
        <RouterLink class="btn" to="/settings">返回</RouterLink>
      </header>

      <label>
        主題主色
        <input v-model="primary" class="color-input" type="color" @input="applyColor" />
      </label>

      <div class="preset-wrap">
        <button
          v-for="color in presets"
          :key="color"
          class="preset-btn"
          :style="{ background: color }"
          :aria-label="`套用顏色 ${color}`"
          @click="pickPreset(color)"
        ></button>
      </div>

      <div class="row action-row">
        <button class="btn primary" @click="saveColor">儲存顏色</button>
        <button class="btn" @click="resetColor">還原預設</button>
      </div>
    </article>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { useUiStore } from '@/ui/stores/ui.store'
import {
  applyThemeColor,
  getDefaultThemeColor,
  loadThemeColor,
  resetThemeColor,
  saveThemeColor,
} from '@/ui/services/theme.service'

const uiStore = useUiStore()
const primary = ref(loadThemeColor())
const presets = ['#e8a228', '#2ecc71', '#3498db', '#e74c3c', '#9b59b6', '#f39c12', '#1abc9c', '#ff5f8f']

function applyColor() {
  primary.value = applyThemeColor(primary.value)
}

function pickPreset(color) {
  primary.value = color
  applyColor()
}

function saveColor() {
  primary.value = saveThemeColor(primary.value)
  uiStore.pushToast('個人化顏色已儲存')
}

function resetColor() {
  primary.value = resetThemeColor()
  if (!primary.value) {
    primary.value = getDefaultThemeColor()
  }
  uiStore.pushToast('已還原預設顏色')
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
}

label {
  display: grid;
  gap: 8px;
  color: var(--muted);
  font-size: 13px;
}

.color-input {
  width: 100%;
  height: 48px;
  border-radius: 10px;
  border: 1px solid var(--border);
  background: #0f161f;
  padding: 6px;
}

.preset-wrap {
  display: grid;
  grid-template-columns: repeat(8, minmax(0, 1fr));
  gap: 8px;
}

.preset-btn {
  border: 2px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
  height: 28px;
  cursor: pointer;
}

.action-row {
  margin-top: 4px;
}
</style>

