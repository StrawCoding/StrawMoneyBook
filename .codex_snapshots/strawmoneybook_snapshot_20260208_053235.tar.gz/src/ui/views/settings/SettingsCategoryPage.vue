<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>分類管理</h2>
        <div class="btn-wrap">
          <button class="btn mini-btn" @click="addGroup">新增群組</button>
          <button class="btn primary mini-btn" @click="addCategory">新增分類</button>
          <RouterLink class="back-link" to="/settings">返回</RouterLink>
        </div>
      </header>
      <p class="muted">L2 分類若已被交易引用，刪除時會自動轉為封存（archive only）。</p>
      <ul class="group-list">
        <li v-for="group in categoryStore.groups" :key="group.id" class="group-item">
          <div class="row group-head">
            <div class="group-title">{{ group.name }}</div>
            <button class="btn mini-btn danger" @click="removeGroup(group.id, group.name)">刪除群組</button>
          </div>
          <ul class="category-list">
            <li v-for="category in categoriesByGroup(group.id)" :key="category.id" class="row">
              <span>{{ category.name }}</span>
              <button class="btn mini-btn" @click="removeCategory(category.id)">刪除/封存</button>
            </li>
          </ul>
        </li>
      </ul>
    </article>
  </section>
</template>

<script setup>
import { RouterLink } from 'vue-router'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useUiStore } from '@/ui/stores/ui.store'

const categoryStore = useCategoryStore()
const uiStore = useUiStore()

function categoriesByGroup(groupId) {
  return categoryStore.categories.filter((category) => category.group_id === groupId)
}

async function addGroup() {
  const name = window.prompt('群組名稱')
  if (!name?.trim()) return

  const kindInput = window.prompt('群組類型（expense/income/both）', 'expense')
  if (kindInput === null) return
  const kind = String(kindInput).trim().toLowerCase()
  if (!['expense', 'income', 'both'].includes(kind)) {
    uiStore.pushToast('群組類型格式錯誤', 'error')
    return
  }

  try {
    await categoryStore.addGroup({
      name: name.trim(),
      kind,
      sortOrder: categoryStore.groups.length,
    })
    uiStore.pushToast('分類群組已新增')
  } catch (error) {
    uiStore.pushToast(error.message ?? '新增群組失敗', 'error')
  }
}

async function addCategory() {
  if (categoryStore.groups.length === 0) {
    uiStore.pushToast('請先新增分類群組', 'error')
    return
  }

  const name = window.prompt('分類名稱')
  if (!name?.trim()) return

  const groupHint = categoryStore.groups.map((group) => `${group.id}:${group.name}`).join('\n')
  const groupIdInput = window.prompt(`輸入群組 ID：\n${groupHint}`, categoryStore.groups[0]?.id ?? '')
  if (!groupIdInput?.trim()) return
  const group = categoryStore.groups.find((item) => item.id === groupIdInput.trim())
  if (!group) {
    uiStore.pushToast('找不到對應群組 ID', 'error')
    return
  }

  const kindInput = window.prompt('分類類型（expense/income/both）', group.kind ?? 'expense')
  if (kindInput === null) return
  const kind = String(kindInput).trim().toLowerCase()
  if (!['expense', 'income', 'both'].includes(kind)) {
    uiStore.pushToast('分類類型格式錯誤', 'error')
    return
  }

  try {
    const sortOrder = categoriesByGroup(group.id).length
    await categoryStore.addCategory({
      groupId: group.id,
      name: name.trim(),
      kind,
      sortOrder,
    })
    uiStore.pushToast('分類已新增')
  } catch (error) {
    uiStore.pushToast(error.message ?? '新增分類失敗', 'error')
  }
}

async function removeCategory(categoryId) {
  try {
    await categoryStore.removeCategory(categoryId)
    uiStore.pushToast('分類已處理')
  } catch (error) {
    uiStore.pushToast(error.message ?? '處理分類失敗', 'error')
  }
}

async function removeGroup(groupId, groupName) {
  const ok = window.confirm(`確定刪除群組「${groupName}」？\n若群組已被交易或預算引用，將改為封存。`)
  if (!ok) return

  try {
    await categoryStore.removeGroup(groupId)
    uiStore.pushToast('群組已處理')
  } catch (error) {
    uiStore.pushToast(error.message ?? '處理群組失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.back-link {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.group-list,
.category-list {
  list-style: none;
  padding: 0;
}

.group-list {
  margin: 12px 0 0;
  display: grid;
  gap: 10px;
}

.group-item {
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px;
}

.group-title {
  font-weight: 700;
}

.group-head {
  margin-bottom: 8px;
}

.category-list {
  margin: 0;
  display: grid;
  gap: 6px;
}

.category-list .row {
  padding-left: 16px;
}

.btn-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: flex-end;
}

.danger {
  background: #4a1f1f;
  color: #ffdede;
}

.mini-btn {
  padding: 10px 12px;
  font-size: inherit;
  border-radius: 12px;
}
</style>
