<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>匯入資料</h2>
        <RouterLink class="back-link" to="/settings">返回</RouterLink>
      </header>

      <div class="stack">
        <div>
          <p class="muted">JSON 匯入會建立新帳本，避免覆蓋現有資料。</p>
          <input ref="jsonInputRef" type="file" accept="application/json" class="input" @change="onImportJsonFile" />
        </div>

        <div>
          <p class="muted">CSV 匯入可選交易/帳戶/分類。</p>
          <div class="row csv-row">
            <select v-model="csvImportType" class="select csv-select">
              <option value="transactions">交易 CSV</option>
              <option value="accounts">帳戶 CSV</option>
              <option value="categories">分類 CSV</option>
            </select>
            <input ref="csvInputRef" type="file" accept=".csv,text/csv" class="input" @change="onImportCsvFile" />
          </div>
        </div>
      </div>
    </article>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { importLedgerCsv, importLedgerJsonAsNewLedger } from '@/core/services/import.service'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { useAccountStore } from '@/ui/stores/account.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useBudgetStore } from '@/ui/stores/budget.store'
import { useLoanStore } from '@/ui/stores/loan.store'
import { useReimbursementStore } from '@/ui/stores/reimbursement.store'

const ledgerStore = useLedgerStore()
const categoryStore = useCategoryStore()
const accountStore = useAccountStore()
const transactionStore = useTransactionStore()
const budgetStore = useBudgetStore()
const loanStore = useLoanStore()
const reimbursementStore = useReimbursementStore()
const uiStore = useUiStore()

const csvImportType = ref('transactions')
const jsonInputRef = ref(null)
const csvInputRef = ref(null)

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result ?? ''))
    reader.onerror = () => reject(new Error('檔案讀取失敗'))
    reader.readAsText(file)
  })
}

async function refreshAllStores() {
  await Promise.all([
    accountStore.load(),
    categoryStore.load(),
    transactionStore.loadRecent(),
    budgetStore.loadMonth(budgetStore.monthKey),
    loanStore.load(),
    reimbursementStore.load(),
  ])
}

async function onImportJsonFile(event) {
  const file = event.target.files?.[0]
  if (!file) return

  try {
    const text = await readFileAsText(file)
    const result = await importLedgerJsonAsNewLedger(text)
    await ledgerStore.refresh()
    await ledgerStore.switchLedger(result.ledgerId)
    await refreshAllStores()
    uiStore.pushToast(`JSON 匯入完成：${result.ledgerName}`)
  } catch (error) {
    uiStore.pushToast(error.message ?? 'JSON 匯入失敗', 'error')
  } finally {
    if (jsonInputRef.value) {
      jsonInputRef.value.value = ''
    }
  }
}

async function onImportCsvFile(event) {
  const file = event.target.files?.[0]
  if (!file) return

  try {
    const text = await readFileAsText(file)
    const result = await importLedgerCsv(ledgerStore.activeLedgerId, text, csvImportType.value)
    await refreshAllStores()
    uiStore.pushToast(`CSV 匯入完成：成功 ${result.inserted} / 略過 ${result.skipped}`)
  } catch (error) {
    uiStore.pushToast(error.message ?? 'CSV 匯入失敗', 'error')
  } finally {
    if (csvInputRef.value) {
      csvInputRef.value.value = ''
    }
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.back-link {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.csv-row {
  gap: 8px;
  align-items: center;
}

.csv-select {
  max-width: 160px;
}
</style>
