<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>資料修復工具</h2>
        <RouterLink class="back-link" to="/settings">返回</RouterLink>
      </header>

      <div class="row tool-row">
        <button class="btn" @click="scanIntegrity">掃描問題</button>
        <button class="btn primary" @click="repairData">執行修復</button>
      </div>

      <pre v-if="integrityReport" class="report">{{ integrityReport }}</pre>
    </article>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { repairLedgerData, scanLedgerIntegrity } from '@/core/services/repair.service'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { useAccountStore } from '@/ui/stores/account.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useBudgetStore } from '@/ui/stores/budget.store'
import { useLoanStore } from '@/ui/stores/loan.store'
import { useReimbursementStore } from '@/ui/stores/reimbursement.store'

const ledgerStore = useLedgerStore()
const categoryStore = useCategoryStore()
const accountStore = useAccountStore()
const transactionStore = useTransactionStore()
const budgetStore = useBudgetStore()
const loanStore = useLoanStore()
const reimbursementStore = useReimbursementStore()
const uiStore = useUiStore()

const integrityReport = ref('')

async function refreshAllStores() {
  await Promise.all([
    accountStore.load(),
    categoryStore.load(),
    transactionStore.loadRecent(),
    budgetStore.loadMonth(budgetStore.monthKey),
    loanStore.load(),
    reimbursementStore.load(),
  ])
}

async function scanIntegrity() {
  try {
    const report = await scanLedgerIntegrity(ledgerStore.activeLedgerId)
    integrityReport.value = JSON.stringify(report, null, 2)
    uiStore.pushToast('掃描完成')
  } catch (error) {
    uiStore.pushToast(error.message ?? '掃描失敗', 'error')
  }
}

async function repairData() {
  try {
    const result = await repairLedgerData(ledgerStore.activeLedgerId)
    integrityReport.value = JSON.stringify(result, null, 2)
    await refreshAllStores()
    uiStore.pushToast('修復完成')
  } catch (error) {
    uiStore.pushToast(error.message ?? '修復失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.back-link {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.tool-row {
  margin-top: 8px;
}

.report {
  margin-top: 10px;
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px;
  background: #101925;
  color: #d2dde9;
  overflow: auto;
}
</style>
