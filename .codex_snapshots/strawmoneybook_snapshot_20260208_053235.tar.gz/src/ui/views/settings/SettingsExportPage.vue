<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>匯出資料</h2>
        <RouterLink class="back-link" to="/settings">返回</RouterLink>
      </header>
      <p class="muted">JSON 含 schema_version，可完整還原。CSV 提供交易/帳戶/分類。</p>

      <div class="export-grid">
        <button class="btn primary" @click="exportJson">匯出 JSON</button>
        <button class="btn" @click="exportCsv('transactions')">匯出交易 CSV</button>
        <button class="btn" @click="exportCsv('accounts')">匯出帳戶 CSV</button>
        <button class="btn" @click="exportCsv('categories')">匯出分類 CSV</button>
      </div>
    </article>
  </section>
</template>

<script setup>
import { RouterLink } from 'vue-router'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useUiStore } from '@/ui/stores/ui.store'
import {
  downloadCsvFile,
  downloadJsonFile,
  exportAccountsCsv,
  exportCategoriesCsv,
  exportLedgerJson,
  exportTransactionsCsv,
} from '@/core/services/export.service'

const ledgerStore = useLedgerStore()
const uiStore = useUiStore()

async function exportJson() {
  try {
    const data = await exportLedgerJson(ledgerStore.activeLedgerId)
    downloadJsonFile(`strawmoneybook-${ledgerStore.activeLedgerId}.json`, data)
    uiStore.pushToast('JSON 匯出完成')
  } catch (error) {
    uiStore.pushToast(error.message ?? '匯出失敗', 'error')
  }
}

async function exportCsv(type) {
  try {
    let csv = ''
    let filename = ''

    if (type === 'transactions') {
      csv = await exportTransactionsCsv(ledgerStore.activeLedgerId)
      filename = `transactions-${ledgerStore.activeLedgerId}.csv`
    }

    if (type === 'accounts') {
      csv = await exportAccountsCsv(ledgerStore.activeLedgerId)
      filename = `accounts-${ledgerStore.activeLedgerId}.csv`
    }

    if (type === 'categories') {
      csv = await exportCategoriesCsv(ledgerStore.activeLedgerId)
      filename = `categories-${ledgerStore.activeLedgerId}.csv`
    }

    downloadCsvFile(filename, csv)
    uiStore.pushToast('CSV 匯出完成')
  } catch (error) {
    uiStore.pushToast(error.message ?? 'CSV 匯出失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
  font-size: 18px;
}

.back-link {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.export-grid {
  margin-top: 10px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}
</style>
