<template>
  <section class="stack">
    <h2 class="page-title">預算</h2>

    <article class="card panel">
      <header class="row">
        <h3>月預算</h3>
        <div class="month-controls">
          <button class="btn month-btn" :disabled="budgetStore.loading" @click="changeMonth(-1)">‹</button>
          <span class="month-label">{{ displayMonth }}</span>
          <button class="btn month-btn" :disabled="budgetStore.loading" @click="changeMonth(1)">›</button>
          <button class="btn month-today" :disabled="budgetStore.loading" @click="goCurrentMonth">本月</button>
        </div>
      </header>

      <div class="stack stat">
        <div class="row">
          <span class="muted">預算總額</span>
          <MoneyText :value-minor="budgetStore.totalBudgetMinor" />
        </div>
        <div class="row">
          <span class="muted">已用</span>
          <MoneyText :value-minor="budgetStore.totalSpentMinor" />
        </div>
        <div class="row">
          <span class="muted">剩餘</span>
          <MoneyText :value-minor="budgetStore.remainMinor" />
        </div>
      </div>

      <div class="row action-row">
        <button class="btn" @click="copyPreviousMonth">複製上月</button>
        <button class="btn primary" @click="openCreate">新增項目</button>
      </div>
    </article>

    <article class="card panel">
      <header class="row">
        <h3>分類預算項目</h3>
        <span class="badge">{{ budgetStore.items.length }} 筆</span>
      </header>

      <ul class="list">
        <li v-for="item in budgetStore.items" :key="item.id" class="item-row">
          <div class="row">
            <span>{{ categoryName(item.category_id) }}</span>
            <MoneyText :value-minor="item.amount_minor" />
          </div>
          <div class="row">
            <small class="muted">已用 {{ formatMajor(spentBy(item.category_id)) }}</small>
            <div class="btn-wrap">
              <button class="btn" @click="openEdit(item)">編輯</button>
              <button class="btn" @click="removeItem(item.id)">刪除</button>
            </div>
          </div>
        </li>
        <li v-if="budgetStore.items.length === 0" class="muted">目前尚無預算項目，請新增。</li>
      </ul>
    </article>

    <BudgetItemSheet
      :open="isSheetOpen"
      :item="editingItem"
      :categories="categoryStore.expenseCategories"
      :category-groups="categoryStore.expenseCategoryGroups"
      @close="closeSheet"
      @save="saveItem"
    />
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useBudgetStore } from '@/ui/stores/budget.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useUiStore } from '@/ui/stores/ui.store'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import BudgetItemSheet from '@/ui/components/budget/BudgetItemSheet.vue'

const budgetStore = useBudgetStore()
const categoryStore = useCategoryStore()
const uiStore = useUiStore()

const isSheetOpen = ref(false)
const editingItem = ref(null)

function changeMonth(offset) {
  const monthKey = shiftMonthKey(budgetStore.monthKey, offset)
  if (!monthKey) return
  budgetStore.loadMonth(monthKey)
}

function goCurrentMonth() {
  const monthKey = monthKeyFromDate(new Date())
  if (monthKey === budgetStore.monthKey) return
  budgetStore.loadMonth(monthKey)
}

const displayMonth = computed(() => {
  if (!budgetStore.monthKey) return '-'
  const [year, month] = budgetStore.monthKey.split('-')
  return `${year} 年 ${month} 月`
})

function shiftMonthKey(monthKey, offset = 0) {
  const [year, month] = String(monthKey ?? '').split('-').map((part) => Number(part))
  if (!year || !month) return ''
  const next = new Date(year, month - 1 + offset, 1)
  return monthKeyFromDate(next)
}

function monthKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}`
}

function categoryName(categoryId) {
  return categoryStore.categories.find((category) => category.id === categoryId)?.name ?? '分類已刪除'
}

function spentBy(categoryId) {
  return Number(budgetStore.spentMap[categoryId] ?? 0)
}

function formatMajor(amountMinor) {
  const minor = Number(amountMinor)
  if (!Number.isFinite(minor)) return ''

  const hasFraction = Math.abs(minor) % 100 !== 0
  return new Intl.NumberFormat('zh-TW', {
    minimumFractionDigits: hasFraction ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(minor / 100)
}

function openCreate() {
  editingItem.value = null
  isSheetOpen.value = true
}

function openEdit(item) {
  editingItem.value = item
  isSheetOpen.value = true
}

function closeSheet() {
  isSheetOpen.value = false
  editingItem.value = null
}

async function saveItem(payload) {
  try {
    await budgetStore.upsertItem(payload)
    uiStore.pushToast('預算項目已儲存')
    closeSheet()
  } catch (error) {
    uiStore.pushToast(error.message ?? '儲存失敗', 'error')
  }
}

async function removeItem(itemId) {
  const ok = window.confirm('確定刪除此預算項目？')
  if (!ok) return

  try {
    await budgetStore.deleteItem(itemId)
    uiStore.pushToast('預算項目已刪除')
  } catch (error) {
    uiStore.pushToast(error.message ?? '刪除失敗', 'error')
  }
}

async function copyPreviousMonth() {
  try {
    const result = await budgetStore.copyFromPreviousMonth()
    if (!result.copied) {
      uiStore.pushToast(`找不到 ${result.fromMonth} 的預算可複製`)
      return
    }
    uiStore.pushToast(`已複製 ${result.copied} 筆上月預算`) 
  } catch (error) {
    uiStore.pushToast(error.message ?? '複製失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2,
h3 {
  margin: 0;
}

.page-title {
  font-size: 24px;
}

.month-controls {
  display: flex;
  align-items: center;
  gap: 6px;
}

.month-label {
  min-width: 90px;
  text-align: center;
  font-weight: 700;
}

.month-btn {
  width: 36px;
  padding: 8px 0;
}

.month-today {
  padding: 8px 10px;
}

.stat {
  margin-top: 10px;
}

.action-row {
  margin-top: 12px;
}

.list {
  list-style: none;
  margin: 12px 0 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.item-row {
  padding: 10px;
  border-radius: 10px;
  border: 1px solid var(--border);
  display: grid;
  gap: 8px;
}

.btn-wrap {
  display: flex;
  gap: 6px;
}
</style>
