<template>
  <section class="stack">
    <article class="card panel">
      <header class="row">
        <h2>圖表分析</h2>
        <RouterLink class="btn icon-btn" :to="printLink">
          <font-awesome-icon icon="fa-solid fa-print" />
        </RouterLink>
      </header>

      <div class="mode-tabs">
        <button class="btn" :class="{ primary: mode === 'all' }" @click="mode = 'all'">全部</button>
        <button class="btn" :class="{ primary: mode === 'year' }" @click="mode = 'year'">年</button>
        <button class="btn" :class="{ primary: mode === 'month' }" @click="mode = 'month'">月</button>
      </div>

      <div v-if="mode !== 'all'" class="picker-wrap">
        <HomeRangePicker v-if="mode === 'year'" mode="year" :year="selectedYear" @update:year="pickYear" />
        <HomeRangePicker v-else mode="month" :month="selectedMonth" @update:month="pickMonth" />
      </div>
    </article>

    <article class="card panel">
      <header class="row">
        <h3>收入分析</h3>
        <MoneyText :value-minor="incomeTotalMinor" />
      </header>

      <div class="chart-wrap">
        <div class="pie" :style="incomePieStyle">
          <div class="pie-hole">
            <div class="pie-total">收入總額</div>
            <MoneyText :value-minor="incomeTotalMinor" />
          </div>
        </div>
      </div>

      <ul class="legend-list">
        <li v-for="item in incomeBreakdown" :key="`income-${item.id}`" class="legend-item">
          <span class="legend-dot" :style="{ background: item.color }"></span>
          <span class="legend-label">{{ item.name }}</span>
          <MoneyText :value-minor="item.amountMinor" />
          <span class="legend-percent">{{ item.percent }}%</span>
        </li>
        <li v-if="incomeBreakdown.length === 0" class="muted">目前沒有收入資料</li>
      </ul>
    </article>

    <article class="card panel">
      <header class="row">
        <h3>支出分析</h3>
        <MoneyText :value-minor="expenseTotalMinor" />
      </header>

      <div class="chart-wrap">
        <div class="pie" :style="expensePieStyle">
          <div class="pie-hole">
            <div class="pie-total">支出總額</div>
            <MoneyText :value-minor="expenseTotalMinor" />
          </div>
        </div>
      </div>

      <ul class="legend-list">
        <li v-for="item in expenseBreakdown" :key="`expense-${item.id}`" class="legend-item">
          <span class="legend-dot" :style="{ background: item.color }"></span>
          <span class="legend-label">{{ item.name }}</span>
          <MoneyText :value-minor="item.amountMinor" />
          <span class="legend-percent">{{ item.percent }}%</span>
        </li>
        <li v-if="expenseBreakdown.length === 0" class="muted">目前沒有支出資料</li>
      </ul>
    </article>

  </section>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import HomeRangePicker from '@/ui/components/common/HomeRangePicker.vue'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { listAllTransactions, listTransactionsByMonth, listTransactionsByYear } from '@/core/repositories/transaction.repo'

const categoryStore = useCategoryStore()
const ledgerStore = useLedgerStore()
const uiStore = useUiStore()

const mode = ref('all')
const selectedYear = ref(new Date().getFullYear())
const selectedMonth = ref(monthKeyFromDate(new Date()))
const statsTransactions = ref([])

const incomePalette = ['#3ecf8e', '#4bc49a', '#5edba7', '#2fbf84', '#8fe8c2', '#35a16f']
const expensePalette = ['#ff6b6b', '#f05353', '#f27474', '#ff8c8c', '#ff5252', '#d64545']

const categoryNameMap = computed(() => {
  const map = new Map()
  for (const category of categoryStore.categories) {
    map.set(category.id, category.name)
  }
  return map
})

const printLink = computed(() => {
  if (mode.value === 'year') {
    return { path: '/analysis/print', query: { mode: 'year', year: String(selectedYear.value) } }
  }
  if (mode.value === 'month') {
    return { path: '/analysis/print', query: { mode: 'month', month: selectedMonth.value } }
  }
  return { path: '/analysis/print', query: { mode: 'all' } }
})

watch(
  () => [ledgerStore.activeLedgerId, mode.value, selectedYear.value, selectedMonth.value],
  () => {
    void loadStatsTransactions()
  },
  { immediate: true },
)

const incomeBreakdown = computed(() => buildBreakdown('income', incomePalette))
const expenseBreakdown = computed(() => buildBreakdown('expense', expensePalette))

const incomeTotalMinor = computed(() => incomeBreakdown.value.reduce((total, item) => total + item.amountMinor, 0))
const expenseTotalMinor = computed(() => expenseBreakdown.value.reduce((total, item) => total + item.amountMinor, 0))

const incomePieStyle = computed(() => buildPieStyle(incomeBreakdown.value))
const expensePieStyle = computed(() => buildPieStyle(expenseBreakdown.value))

function pickYear(value) {
  selectedYear.value = Number(value)
}

function pickMonth(value) {
  selectedMonth.value = value
}

async function loadStatsTransactions() {
  const ledgerId = ledgerStore.activeLedgerId
  if (!ledgerId) {
    statsTransactions.value = []
    return
  }

  try {
    if (mode.value === 'year') {
      statsTransactions.value = await listTransactionsByYear(ledgerId, String(selectedYear.value))
      return
    }
    if (mode.value === 'month') {
      statsTransactions.value = await listTransactionsByMonth(ledgerId, selectedMonth.value)
      return
    }
    statsTransactions.value = await listAllTransactions(ledgerId)
  } catch (error) {
    uiStore.pushToast(error.message ?? '載入分析資料失敗', 'error')
  }
}

function buildBreakdown(type, palette) {
  const map = new Map()
  for (const tx of statsTransactions.value) {
    if (tx.type !== type || tx.origin_type === 'loan_payment') continue
    const key = tx.category_id || '__uncategorized__'
    const amount = type === 'expense' ? Math.abs(Number(tx.amount_minor ?? 0)) : Number(tx.amount_minor ?? 0)
    if (!Number.isFinite(amount) || amount <= 0) continue
    map.set(key, (map.get(key) || 0) + amount)
  }

  const rows = Array.from(map.entries())
    .map(([id, amountMinor]) => ({
      id,
      amountMinor,
      name: id === '__uncategorized__' ? '未分類' : categoryNameMap.value.get(id) || '未分類',
    }))
    .sort((a, b) => b.amountMinor - a.amountMinor)

  const total = rows.reduce((sum, row) => sum + row.amountMinor, 0)
  if (!total) return []

  return rows.map((row, index) => ({
    ...row,
    color: palette[index % palette.length],
    percent: Math.round((row.amountMinor / total) * 100),
  }))
}

function buildPieStyle(items) {
  if (!items.length) {
    return { background: 'conic-gradient(#2a3445 0deg 360deg)' }
  }

  const total = items.reduce((sum, item) => sum + item.amountMinor, 0)
  let cursor = 0
  const segments = []

  for (const item of items) {
    const deg = (item.amountMinor / total) * 360
    const start = cursor
    const end = cursor + deg
    segments.push(`${item.color} ${start}deg ${end}deg`)
    cursor = end
  }

  return { background: `conic-gradient(${segments.join(', ')})` }
}

function monthKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}`
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2,
h3 {
  margin: 0;
}

.icon-btn {
  width: 36px;
  height: 36px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.mode-tabs {
  margin-top: 10px;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}

.picker-wrap {
  margin-top: 10px;
}

.chart-wrap {
  margin-top: 12px;
  display: flex;
  justify-content: center;
}

.pie {
  width: 220px;
  height: 220px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.06);
}

.pie-hole {
  width: 128px;
  height: 128px;
  border-radius: 50%;
  background: #111a26;
  display: grid;
  place-items: center;
  text-align: center;
  gap: 2px;
}

.pie-total {
  font-size: 12px;
  color: var(--muted);
}

.legend-list {
  list-style: none;
  margin: 14px 0 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.legend-item {
  display: grid;
  grid-template-columns: auto 1fr auto auto;
  align-items: center;
  gap: 8px;
  padding: 10px;
  border: 1px solid var(--border);
  border-radius: 10px;
}

.legend-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}

.legend-label {
  color: var(--muted);
}

.legend-percent {
  min-width: 42px;
  text-align: right;
  font-weight: 700;
}

.placeholder {
  min-height: 120px;
}
</style>
