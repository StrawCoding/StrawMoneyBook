<template>
  <section class="stack">
    <article class="card panel summary">
      <header class="row">
        <h2>報銷統整</h2>
      </header>
      <div class="row">
        <span class="muted">未報銷金額</span>
        <MoneyText :value-minor="reimbursementStore.pendingTotalMinor" />
      </div>
      <div class="row">
        <span class="muted">已報銷金額</span>
        <MoneyText :value-minor="reimbursementStore.reimbursedTotalMinor" />
      </div>
    </article>

    <article class="card panel">
      <div class="tab-row">
        <button class="btn" :class="{ primary: tab === 'pending' }" @click="tab = 'pending'">未報銷</button>
        <button class="btn" :class="{ primary: tab === 'reimbursed' }" @click="tab = 'reimbursed'">已報銷</button>
      </div>

      <ul class="list">
        <li v-for="tx in activeList" :key="tx.id" class="entry">
          <div class="row">
            <strong>{{ tx.category_name || tx.note || '未命名分類' }}</strong>
            <MoneyText :value-minor="Math.abs(Number(tx.amount_minor ?? 0))" />
          </div>
          <div class="row muted">
            <span>{{ formatTime(tx.occurred_at) }}</span>
            <span>{{ tx.note || '-' }}</span>
          </div>

          <div class="row btn-wrap">
            <button v-if="tab === 'pending'" class="btn primary" @click="openSettle(tx)">標記已報銷</button>
            <button v-else class="btn" @click="markPending(tx.id)">回到未報銷</button>
          </div>
        </li>

        <li v-if="!activeList.length" class="muted">目前此分頁沒有資料</li>
      </ul>
    </article>

    <teleport to="body">
      <section v-if="isSettleOpen" class="sheet-mask" @click.self="closeSettle">
        <article class="sheet card">
          <header class="row">
            <h3>報銷完成設定</h3>
            <button class="btn" @click="closeSettle">關閉</button>
          </header>

          <div class="stack form-wrap">
            <label>
              報銷金額（元）
              <input v-model.number="settleForm.amountMajor" type="number" min="0" step="1" class="input" />
            </label>

            <label>
              入帳帳戶
              <select v-model="settleForm.accountId" class="select">
                <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                  {{ account.name }}
                </option>
              </select>
            </label>
          </div>

          <footer class="row">
            <button class="btn" @click="closeSettle">取消</button>
            <button class="btn primary" @click="confirmSettle">確認</button>
          </footer>
        </article>
      </section>
    </teleport>
  </section>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import { useReimbursementStore } from '@/ui/stores/reimbursement.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useAccountStore } from '@/ui/stores/account.store'

const reimbursementStore = useReimbursementStore()
const transactionStore = useTransactionStore()
const accountStore = useAccountStore()
const uiStore = useUiStore()

const tab = ref('pending')
const isSettleOpen = ref(false)
const settleTargetTx = ref(null)
const settleForm = reactive({
  amountMajor: 0,
  accountId: '',
})

const activeList = computed(() => {
  return tab.value === 'pending' ? reimbursementStore.pendingItems : reimbursementStore.reimbursedItems
})

onMounted(() => {
  reimbursementStore.load()
})

function formatTime(iso) {
  if (!iso) return '-'
  return new Date(iso).toLocaleString('zh-TW', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function openSettle(tx) {
  settleTargetTx.value = tx
  settleForm.amountMajor = Math.abs(Number(tx.amount_minor ?? 0)) / 100
  settleForm.accountId = accountStore.accounts[0]?.id ?? ''
  isSettleOpen.value = true
}

function closeSettle() {
  isSettleOpen.value = false
  settleTargetTx.value = null
}

async function confirmSettle() {
  if (!settleTargetTx.value?.id) return

  try {
    const result = await reimbursementStore.settle(settleTargetTx.value.id, {
      amountMinor: Math.round(Number(settleForm.amountMajor ?? 0) * 100),
      accountId: settleForm.accountId,
      occurredAt: new Date().toISOString(),
      note: `報銷入帳（來源交易：${settleTargetTx.value.id}）`,
    })
    await Promise.all([transactionStore.loadRecent(), accountStore.load()])
    if (result?.alreadyExists) {
      uiStore.pushToast('已標記為報銷，且已有入帳交易')
    } else {
      uiStore.pushToast('已標記報銷並完成入帳')
    }
    closeSettle()
  } catch (error) {
    uiStore.pushToast(error.message ?? '更新失敗', 'error')
  }
}

async function markPending(txId) {
  try {
    await reimbursementStore.markUnreimbursed(txId)
    await Promise.all([transactionStore.loadRecent(), accountStore.load()])
    uiStore.pushToast('已移回未報銷')
  } catch (error) {
    uiStore.pushToast(error.message ?? '更新失敗', 'error')
  }
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2 {
  margin: 0;
}

.tab-row {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  gap: 8px;
}

.entry {
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px;
  display: grid;
  gap: 8px;
}

.btn-wrap {
  justify-content: flex-end;
}

.sheet-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 70;
}

.sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
}

.form-wrap {
  margin-top: 12px;
}

label {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.check-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
</style>
