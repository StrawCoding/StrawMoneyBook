<template>
  <section class="stack export-page">
    <article class="card panel">
      <header class="row">
        <h2>交易報表匯出</h2>
        <RouterLink class="btn" to="/analysis">返回</RouterLink>
      </header>

      <div class="mode-tabs">
        <button class="btn" :class="{ primary: mode === 'all' }" @click="mode = 'all'">全部</button>
        <button class="btn" :class="{ primary: mode === 'year' }" @click="mode = 'year'">年</button>
        <button class="btn" :class="{ primary: mode === 'month' }" @click="mode = 'month'">月</button>
        <button class="btn" :class="{ primary: mode === 'day' }" @click="mode = 'day'">日</button>
        <button class="btn" :class="{ primary: mode === 'custom' }" @click="mode = 'custom'">自訂</button>
      </div>

      <div class="picker-wrap">
        <HomeRangePicker v-if="mode === 'year'" mode="year" :year="selectedYear" @update:year="pickYear" />
        <HomeRangePicker v-else-if="mode === 'month'" mode="month" :month="selectedMonth" @update:month="pickMonth" />
        <HomeRangePicker v-else-if="mode === 'day'" mode="day" :day="selectedDay" @update:day="pickDay" />

        <div v-else-if="mode === 'custom'" class="custom-grid">
          <label>
            起始日
            <HomeRangePicker mode="day" :day="startDate" @update:day="pickStartDay" />
          </label>
          <label>
            結束日
            <HomeRangePicker mode="day" :day="endDate" @update:day="pickEndDay" />
          </label>
        </div>

        <div v-else class="muted all-hint">將匯出當前帳本全部交易</div>
      </div>

      <div class="action-row">
        <button class="btn primary" :disabled="exporting" @click="exportExcel">
          {{ exporting ? '匯出中...' : '匯出 Excel' }}
        </button>
      </div>

      <div v-if="exportedUrl" class="link-row">
        <button class="btn" @click="downloadFromLink">再次下載</button>
        <button class="btn" @click="copyExportLink">複製連結</button>
      </div>

      <p v-if="exportedFilename" class="muted file-note">檔案：{{ exportedFilename }}</p>
      <p v-if="exportedLocation" class="muted file-note">儲存位置：{{ exportedLocation }}</p>
    </article>

    <article class="card panel">
      <header class="row">
        <h3>匯出欄位</h3>
      </header>
      <ul class="fields-list">
        <li>類型、記帳時間、交易帳戶、交易帳本、貨幣符號、交易金額</li>
        <li>一級分類、二級分類、交易標籤、備註</li>
        <li>退款&轉銷、收回、歸還、手續費、匯率</li>
      </ul>
    </article>
  </section>
</template>

<script setup>
import { onBeforeUnmount, ref } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import HomeRangePicker from '@/ui/components/common/HomeRangePicker.vue'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useUiStore } from '@/ui/stores/ui.store'
import {
  createExcelBlobUrl,
  exportLedgerTransactionsExcel,
  revokeBlobUrl,
  saveExcelFileToDevice,
  triggerDownloadFromUrl,
} from '@/core/services/export.service'

const route = useRoute()
const ledgerStore = useLedgerStore()
const uiStore = useUiStore()

const mode = ref(parseMode(String(route.query.mode || 'all')))
const selectedYear = ref(Number(route.query.year || new Date().getFullYear()))
const selectedMonth = ref(String(route.query.month || monthKeyFromDate(new Date())))
const selectedDay = ref(String(route.query.day || dayKeyFromDate(new Date())))
const startDate = ref(String(route.query.start || dayKeyFromDate(new Date())))
const endDate = ref(String(route.query.end || dayKeyFromDate(new Date())))
const exporting = ref(false)
const exportedUrl = ref('')
const exportedFilename = ref('')
const exportedLocation = ref('')

function parseMode(value) {
  return ['all', 'year', 'month', 'day', 'custom'].includes(value) ? value : 'all'
}

function pickYear(value) {
  selectedYear.value = Number(value)
}

function pickMonth(value) {
  selectedMonth.value = value
}

function pickDay(value) {
  selectedDay.value = value
}

function pickStartDay(value) {
  startDate.value = value
}

function pickEndDay(value) {
  endDate.value = value
}

async function exportExcel() {
  const ledgerId = ledgerStore.activeLedgerId
  if (!ledgerId) {
    uiStore.pushToast('找不到當前帳本', 'error')
    return
  }

  if (mode.value === 'custom' && (!startDate.value || !endDate.value)) {
    uiStore.pushToast('請選擇自訂起訖日', 'error')
    return
  }

  if (mode.value === 'custom' && startDate.value > endDate.value) {
    uiStore.pushToast('起始日不可晚於結束日', 'error')
    return
  }

  exporting.value = true
  try {
    const result = await exportLedgerTransactionsExcel(ledgerId, {
      mode: mode.value,
      yearKey: String(selectedYear.value),
      monthKey: selectedMonth.value,
      dayKey: selectedDay.value,
      startDate: startDate.value,
      endDate: endDate.value,
    })

    exportedFilename.value = result.filename
    const deviceSave = await saveExcelFileToDevice(result.filename, result.xmlText)

    if (deviceSave.saved) {
      revokeBlobUrl(exportedUrl.value)
      exportedUrl.value = ''
      exportedLocation.value = deviceSave.location || '裝置檔案'
      uiStore.pushToast(`已匯出 ${result.rowCount} 筆交易，已存到 ${exportedLocation.value}`)
      return
    }

    exportedLocation.value = ''
    revokeBlobUrl(exportedUrl.value)
    exportedUrl.value = createExcelBlobUrl(result.xmlText)
    triggerDownloadFromUrl(exportedUrl.value, exportedFilename.value)
    uiStore.pushToast(`已匯出 ${result.rowCount} 筆交易（瀏覽器下載）`)
  } catch (error) {
    uiStore.pushToast(error.message ?? '匯出失敗', 'error')
  } finally {
    exporting.value = false
  }
}

function downloadFromLink() {
  if (!exportedUrl.value || !exportedFilename.value) return
  triggerDownloadFromUrl(exportedUrl.value, exportedFilename.value)
}

async function copyExportLink() {
  if (!exportedUrl.value) return
  try {
    await navigator.clipboard.writeText(exportedUrl.value)
    uiStore.pushToast('已複製匯出連結')
  } catch {
    window.prompt('請手動複製連結', exportedUrl.value)
  }
}

onBeforeUnmount(() => {
  revokeBlobUrl(exportedUrl.value)
})

function monthKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}`
}

function dayKeyFromDate(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}
</script>

<style scoped>
.panel {
  padding: 14px;
}

h2,
h3 {
  margin: 0;
}

.export-page {
  padding-bottom: 120px;
}

.mode-tabs {
  margin-top: 10px;
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 8px;
}

.picker-wrap {
  margin-top: 10px;
}

.custom-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

label {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.all-hint {
  padding: 8px 0;
}

.action-row {
  margin-top: 12px;
}

.link-row {
  margin-top: 10px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.file-note {
  margin: 8px 0 0;
}

.fields-list {
  margin: 12px 0 0;
  padding-left: 20px;
  display: grid;
  gap: 6px;
}
</style>
