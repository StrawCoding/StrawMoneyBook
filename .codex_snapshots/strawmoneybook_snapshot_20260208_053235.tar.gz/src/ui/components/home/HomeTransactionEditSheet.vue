<template>
  <teleport to="body">
    <section v-if="open" class="sheet-mask" @click.self="$emit('close')">
      <article class="sheet card">
        <header class="row">
          <h3>編輯交易</h3>
          <button class="btn" @click="$emit('close')">關閉</button>
        </header>

        <div class="type-grid">
          <button
            v-for="item in types"
            :key="item.value"
            class="btn"
            :class="{ primary: model.type === item.value }"
            @click="model.type = item.value"
          >
            {{ item.label }}
          </button>
        </div>

        <div class="stack form-wrap">
          <label>
            金額（元）
            <input
              v-model="model.amountInput"
              type="text"
              inputmode="decimal"
              class="input"
              @input="handleAmountInput"
            />
          </label>

          <div class="date-extra-row">
            <div class="field-block">
              <span class="field-label">交易時間</span>
              <DateTimePickerField
                :date="model.occurredDate"
                :hour="model.occurredHour"
                :minute="model.occurredMinute"
                @update:date="model.occurredDate = $event"
                @update:hour="model.occurredHour = $event"
                @update:minute="model.occurredMinute = $event"
              />
            </div>

            <button type="button" class="btn extra-btn" @click="showExtra = true">
              附加資訊
            </button>
          </div>

          <div v-if="showCategory" class="inline-grid">
            <label>
              帳戶
              <select v-model="model.accountId" class="select">
                <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                  {{ account.name }}
                </option>
              </select>
            </label>

            <label>
              分類
              <select v-model="model.categoryId" class="select">
                <optgroup v-for="group in visibleCategoryGroups" :key="group.id" :label="group.name">
                  <option v-for="category in group.categories" :key="category.id" :value="category.id">
                    {{ category.name }}
                  </option>
                </optgroup>
              </select>
            </label>
          </div>

          <label v-else>
            帳戶
            <select v-model="model.accountId" class="select">
              <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                {{ account.name }}
              </option>
            </select>
          </label>

          <section class="calc-panel">
            <div class="calc-grid">
              <button
                v-for="key in calcKeys"
                :key="key"
                type="button"
                class="calc-key btn"
                :class="{ equal: key === '=' }"
                @click="pressCalcKey(key)"
              >
                {{ key }}
              </button>
            </div>
          </section>
        </div>

        <footer class="row">
          <button class="btn danger" @click="remove">刪除</button>
          <div class="footer-actions">
            <button class="btn" @click="$emit('close')">取消</button>
            <button class="btn primary" @click="submit">儲存</button>
          </div>
        </footer>
      </article>
    </section>

    <section v-if="open && showExtra" class="extra-mask" @click.self="showExtra = false">
      <article class="extra-sheet card">
        <header class="row">
          <h4>附加資訊</h4>
          <button class="btn" @click="showExtra = false">完成</button>
        </header>

        <div class="stack extra-content">
          <div class="addon-wrap">
            <div class="row">
              <span class="field-label">附加項目</span>
              <button type="button" class="btn" @click="addAddonRow">新增項目</button>
            </div>

            <div v-for="item in addonRows" :key="item.id" class="addon-row">
              <input
                v-model.trim="item.label"
                class="input addon-name"
                type="text"
                placeholder="名稱（例：優惠）"
              />
              <select v-model="item.direction" class="select addon-dir">
                <option value="plus">+</option>
                <option value="minus">-</option>
              </select>
              <input
                v-model.number="item.amountMajor"
                class="input addon-amount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0"
              />
              <button type="button" class="btn danger addon-remove" @click="removeAddonRow(item.id)">
                刪除
              </button>
            </div>

            <div class="row">
              <small class="addon-desc">可自訂名稱與加減方式，按下後會套用到金額</small>
              <button type="button" class="addon-btn" @click="applyAddonRows">套用項目</button>
            </div>
          </div>

          <label>
            備註
            <textarea v-model="model.note" class="textarea" rows="3" />
          </label>

          <div v-if="model.type === 'expense'" class="reimburse-wrap">
            <span class="field-label">報銷</span>
            <button
              type="button"
              class="reimburse-btn"
              :class="{ active: model.isReimbursable }"
              @click="model.isReimbursable = !model.isReimbursable"
            >
              <span class="dot"></span>
              <span>{{ model.isReimbursable ? '已設為可報銷' : '設為可報銷' }}</span>
            </button>
          </div>
        </div>
      </article>
    </section>
  </teleport>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import DateTimePickerField from '@/ui/components/common/DateTimePickerField.vue'
import { useAccountStore } from '@/ui/stores/account.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useUiStore } from '@/ui/stores/ui.store'

const props = defineProps({
  open: {
    type: Boolean,
    default: false,
  },
  tx: {
    type: Object,
    default: null,
  },
})

const emit = defineEmits(['close', 'saved'])

const accountStore = useAccountStore()
const categoryStore = useCategoryStore()
const transactionStore = useTransactionStore()
const uiStore = useUiStore()

const types = [
  { value: 'expense', label: '支出' },
  { value: 'income', label: '收入' },
  { value: 'adjustment', label: '調整' },
]

const model = reactive({
  type: 'expense',
  amountMajor: null,
  amountInput: '',
  occurredDate: '',
  occurredHour: 0,
  occurredMinute: 0,
  accountId: '',
  categoryId: '',
  note: '',
  isReimbursable: false,
})

const showExtra = ref(false)
const addonRows = ref([])
let addonSeq = 1

const calcKeys = ['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '-', '0', '.', '⌫', '+', 'C', '=']

const showCategory = computed(() => model.type === 'expense' || model.type === 'income')
const visibleCategoryGroups = computed(() => {
  if (model.type === 'income') return categoryStore.incomeCategoryGroups
  return categoryStore.expenseCategoryGroups
})

watch(
  () => [props.open, props.tx],
  ([open, tx]) => {
    if (!open || !tx) {
      showExtra.value = false
      return
    }

    const occurred = new Date(tx.occurred_at)
    const isIncome = tx.type === 'income'
    const isAdjustment = tx.type === 'adjustment'

    model.type = isIncome ? 'income' : isAdjustment ? 'adjustment' : 'expense'

    const rawMajor = Number(tx.amount_minor) / 100
    model.amountMajor = isAdjustment ? rawMajor : Math.abs(rawMajor)
    model.amountInput = formatAmountInput(model.amountMajor)
    model.occurredDate = toDateInput(occurred)
    model.occurredHour = occurred.getHours()
    model.occurredMinute = occurred.getMinutes()
    model.accountId = tx.account_id ?? accountStore.accounts[0]?.id ?? ''
    model.categoryId = tx.category_id ?? defaultCategoryId(model.type)
    model.note = tx.note ?? ''
    model.isReimbursable = Boolean(tx.is_reimbursable) && model.type === 'expense'

    showExtra.value = false
    addonRows.value = [createAddonRow()]
  },
  { immediate: true },
)

watch(
  () => model.type,
  (type) => {
    if (type === 'income') {
      model.categoryId = ensureInCategories(model.categoryId, categoryStore.incomeCategories)
      model.isReimbursable = false
      return
    }
    if (type === 'expense') {
      model.categoryId = ensureInCategories(model.categoryId, categoryStore.expenseCategories)
      return
    }
    model.categoryId = ''
    model.isReimbursable = false
  },
)

async function submit() {
  if (!props.tx?.id) return

  const occurredAt = toOccurredAtIso(model.occurredDate, model.occurredHour, model.occurredMinute)
  if (!occurredAt) {
    uiStore.pushToast('請選擇有效時間', 'error')
    return
  }

  const rawAmountMinor = Math.round(Number(model.amountMajor ?? 0) * 100)
  if (model.type === 'adjustment') {
    if (!rawAmountMinor) {
      uiStore.pushToast('調整金額不可為 0', 'error')
      return
    }
  } else if (rawAmountMinor <= 0) {
    uiStore.pushToast('請輸入有效金額', 'error')
    return
  }

  try {
    const payloadAmountMinor = model.type === 'adjustment' ? rawAmountMinor : Math.abs(rawAmountMinor)

    await transactionStore.updateTransaction(props.tx.id, {
      type: model.type,
      amountMinor: payloadAmountMinor,
      occurredAt,
      accountId: model.accountId,
      categoryId: model.type === 'adjustment' ? null : model.categoryId,
      note: model.note,
      isReimbursable: model.type === 'expense' && model.isReimbursable,
    })

    uiStore.pushToast('交易已更新')
    emit('saved')
    emit('close')
  } catch (error) {
    uiStore.pushToast(error.message ?? '更新失敗', 'error')
  }
}

function handleAmountInput() {
  syncAmountFromInput()
}

async function pressCalcKey(key) {
  if (key === 'C') {
    model.amountInput = ''
    model.amountMajor = null
    return
  }

  if (key === '⌫') {
    model.amountInput = model.amountInput.slice(0, -1)
    syncAmountFromInput()
    return
  }

  if (key === '=') {
    if (!isFormulaExpression(model.amountInput)) {
      await submit()
      return
    }

    const value = evaluateExpression(model.amountInput)
    if (Number.isFinite(value)) {
      model.amountMajor = value
      model.amountInput = formatAmountInput(value)
    }
    return
  }

  if (isOperator(key)) {
    const last = model.amountInput.slice(-1)
    if (!model.amountInput && key !== '-') return
    if (isOperator(last)) {
      model.amountInput = `${model.amountInput.slice(0, -1)}${key}`
    } else {
      model.amountInput += key
    }
  } else {
    model.amountInput += key
  }

  syncAmountFromInput()
}

function syncAmountFromInput() {
  const value = evaluateExpression(model.amountInput)
  model.amountMajor = Number.isFinite(value) ? value : null
}

function isOperator(char) {
  return ['+', '-', '×', '÷', '*', '/'].includes(char)
}

function isFormulaExpression(input) {
  const source = String(input ?? '').trim().replaceAll('×', '*').replaceAll('÷', '/').replace(/\s+/g, '')
  if (!source) return false
  let operatorCount = 0
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i]
    if (!['+', '-', '*', '/'].includes(ch)) continue
    if (i === 0 && ch === '-') continue
    operatorCount += 1
  }
  return operatorCount > 0
}

function evaluateExpression(input) {
  const source = String(input ?? '').trim()
  if (!source) return null
  if (!/^[0-9+\-×÷*/.\s]+$/.test(source)) return null

  const normalized = source.replaceAll('×', '*').replaceAll('÷', '/').replace(/\s+/g, '')
  const tokens = normalized.match(/(\d+(?:\.\d+)?)|[+\-*/]/g)
  if (!tokens || !tokens.length) return null

  const nums = []
  const ops = []
  let expectingNumber = true

  for (const token of tokens) {
    if (['+', '-', '*', '/'].includes(token)) {
      if (expectingNumber) {
        if (token === '-' && nums.length === 0) {
          nums.push(0)
        } else {
          return null
        }
      }
      while (ops.length && precedence(ops.at(-1)) >= precedence(token)) {
        if (!applyOperator(nums, ops.pop())) return null
      }
      ops.push(token)
      expectingNumber = true
      continue
    }

    const num = Number(token)
    if (!Number.isFinite(num)) return null
    nums.push(num)
    expectingNumber = false
  }

  if (expectingNumber) return null
  while (ops.length) {
    if (!applyOperator(nums, ops.pop())) return null
  }

  const result = nums[0]
  if (!Number.isFinite(result)) return null
  return Math.round(result * 100) / 100
}

function precedence(op) {
  if (op === '+' || op === '-') return 1
  if (op === '*' || op === '/') return 2
  return 0
}

function applyOperator(nums, op) {
  if (nums.length < 2) return false
  const b = nums.pop()
  const a = nums.pop()
  if (op === '/' && b === 0) return false
  const result = op === '+' ? a + b : op === '-' ? a - b : op === '*' ? a * b : a / b
  if (!Number.isFinite(result)) return false
  nums.push(result)
  return true
}

async function remove() {
  if (!props.tx?.id) return
  const confirmed = window.confirm('確定要刪除這筆交易？')
  if (!confirmed) return

  try {
    await transactionStore.deleteTransaction(props.tx.id)
    uiStore.pushToast('交易已刪除')
    emit('saved')
    emit('close')
  } catch (error) {
    uiStore.pushToast(error.message ?? '刪除失敗', 'error')
  }
}

function createAddonRow() {
  return {
    id: `addon-${Date.now()}-${addonSeq++}`,
    label: defaultAddonLabel(),
    direction: defaultAddonDirection(),
    amountMajor: null,
  }
}

function defaultAddonLabel() {
  if (model.type === 'expense') return '優惠'
  if (model.type === 'income') return '手續費'
  return '附加項目'
}

function defaultAddonDirection() {
  if (model.type === 'expense') return 'minus'
  return 'plus'
}

function addAddonRow() {
  addonRows.value.push(createAddonRow())
}

function removeAddonRow(rowId) {
  addonRows.value = addonRows.value.filter((item) => item.id !== rowId)
}

function applyAddonRows() {
  if (!addonRows.value.length) {
    uiStore.pushToast('請先新增附加項目', 'error')
    return
  }

  const base = Number(model.amountMajor ?? 0)
  if (!Number.isFinite(base)) {
    uiStore.pushToast('請先輸入有效金額', 'error')
    return
  }

  const appliedItems = addonRows.value
    .map((item) => ({
      label: String(item.label || '附加項目').trim(),
      direction: item.direction === 'minus' ? 'minus' : 'plus',
      delta: round2(Math.abs(Number(item.amountMajor ?? 0))),
    }))
    .filter((item) => item.delta > 0)

  if (!appliedItems.length) {
    uiStore.pushToast('請輸入至少一筆有效附加金額', 'error')
    return
  }

  const totalDelta = appliedItems.reduce((total, item) => {
    return total + (item.direction === 'plus' ? item.delta : -item.delta)
  }, 0)

  let next = round2(base + totalDelta)
  if (model.type !== 'adjustment') {
    next = Math.max(0, next)
  }

  model.amountMajor = next
  model.amountInput = formatAmountInput(next)

  const sign = totalDelta >= 0 ? '+' : '-'
  uiStore.pushToast(`已套用 ${appliedItems.length} 項，合計 ${sign}${formatAmountInput(Math.abs(totalDelta))} 元`)
}

function defaultCategoryId(type) {
  if (type === 'income') return categoryStore.incomeCategories[0]?.id ?? ''
  if (type === 'expense') return categoryStore.expenseCategories[0]?.id ?? ''
  return ''
}

function ensureInCategories(categoryId, categories) {
  if (!Array.isArray(categories) || !categories.length) return ''
  if (categories.some((item) => item.id === categoryId)) return categoryId
  return categories[0]?.id ?? ''
}

function toDateInput(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function formatAmountInput(value) {
  const rounded = Math.round(Number(value) * 100) / 100
  if (!Number.isFinite(rounded)) return ''
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2).replace(/\.?0+$/, '')
}

function round2(value) {
  return Math.round(Number(value) * 100) / 100
}

function toOccurredAtIso(dateInput, hourInput, minuteInput) {
  if (!dateInput) return ''
  const hour = Number(hourInput)
  const minute = Number(minuteInput)
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) return ''
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return ''

  const local = `${dateInput}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:00`
  const parsed = new Date(local)
  if (Number.isNaN(parsed.getTime())) return ''
  return parsed.toISOString()
}
</script>

<style scoped>
.sheet-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 70;
}

.sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
  animation: slide-in 180ms ease;
}

h3 {
  margin: 0;
}

.type-grid {
  margin-top: 12px;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}

.form-wrap {
  margin-top: 12px;
}

label {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.field-block {
  display: grid;
  gap: 6px;
  min-width: 0;
}

.field-label {
  font-size: 13px;
  color: var(--muted);
}

.calc-panel {
  margin-top: -2px;
}

.calc-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
}

.calc-key {
  padding: 12px 0;
  font-size: 16px;
  font-weight: 700;
}

.calc-key.equal {
  grid-column: 3 / span 2;
}

.inline-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.date-extra-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: end;
}

.extra-btn {
  white-space: nowrap;
  min-height: 42px;
  align-self: end;
  justify-content: center;
}

footer.row {
  justify-content: space-between;
}

.footer-actions {
  display: flex;
  gap: 8px;
}

.danger {
  border-color: color-mix(in srgb, var(--danger) 45%, transparent);
  color: var(--danger);
}

.extra-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 80;
}

.extra-sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
  animation: extra-slide-up 180ms ease;
}

h4 {
  margin: 0;
  font-size: 16px;
}

.extra-content {
  margin-top: 10px;
}

.addon-wrap {
  display: grid;
  gap: 6px;
}

.addon-row {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) 74px minmax(0, 1fr) 68px;
  gap: 8px;
  align-items: end;
}

.addon-name,
.addon-dir,
.addon-amount {
  min-width: 0;
}

.addon-remove {
  padding: 10px 0;
}

.addon-btn {
  border: 1px solid var(--field-border);
  border-radius: 12px;
  background: #1a2c45;
  color: #d7e6ff;
  padding: 10px 14px;
  display: inline-flex;
  align-items: center;
  cursor: pointer;
}

.addon-desc {
  color: #9db2d3;
}

.reimburse-wrap {
  display: grid;
  gap: 6px;
}

.reimburse-btn {
  border: 1px solid var(--field-border);
  border-radius: 12px;
  background: #112233;
  color: #cfe3ff;
  padding: 10px 12px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  cursor: pointer;
}

.reimburse-btn .dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #5b7ea4;
}

.reimburse-btn.active {
  background: linear-gradient(120deg, #22827a, #34b7a9);
  border-color: #5fd4c7;
  color: #08231f;
}

.reimburse-btn.active .dot {
  background: #0f4f47;
}
</style>
