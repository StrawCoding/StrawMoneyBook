<template>
  <article class="card summary-card">
    <header class="row">
      <div class="title-row">
        <h3>交易紀錄</h3>
        <RouterLink class="btn icon-btn" to="/transactions/search">
          <font-awesome-icon icon="fa-solid fa-magnifying-glass" />
        </RouterLink>
        <RouterLink class="btn icon-btn" to="/analysis">
          <font-awesome-icon :icon="['fas', 'chart-pie']" />
        </RouterLink>
      </div>
      <span class="badge">{{ monthLabel }} 共 {{ transactionStore.homeRecent.length }} 筆</span>
    </header>

    <ul class="tx-list">
      <li
        v-for="tx in transactionStore.homeRecent.slice(0, 12)"
        :key="tx.id"
        class="tx-item"
        role="button"
        tabindex="0"
        @click="openEdit(tx)"
      >
        <div>
          <div class="tx-type">{{ labelOfTransaction(tx) }}</div>
          <small class="muted">{{ formatTime(tx.occurred_at) }}</small>
        </div>
        <MoneyText :value-minor="tx.amount_minor" />
      </li>
      <li v-if="transactionStore.homeRecent.length === 0" class="muted empty-item">這個月份沒有交易</li>
    </ul>

    <HomeTransactionEditSheet :open="isEditOpen" :tx="editingTx" @close="closeEdit" @saved="handleSaved" />
  </article>
</template>

<script setup>
import { computed, ref } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useUiStore } from '@/ui/stores/ui.store'
import HomeTransactionEditSheet from '@/ui/components/home/HomeTransactionEditSheet.vue'

const transactionStore = useTransactionStore()
const categoryStore = useCategoryStore()
const uiStore = useUiStore()
const isEditOpen = ref(false)
const editingTx = ref(null)

const monthLabel = computed(() => {
  if (transactionStore.homeFilterMode === 'all') return '全部'
  if (transactionStore.homeFilterMode === 'year') return `${transactionStore.homeFilterKey} 年`
  if (transactionStore.homeFilterMode === 'day') return transactionStore.homeFilterKey
  if (transactionStore.homeFilterMode === 'month') {
    const [year, month] = String(transactionStore.homeFilterKey).split('-')
    if (year && month) return `${year}/${month}`
  }
  return '當月'
})

function labelOf(type) {
  if (type === 'expense') return '支出'
  if (type === 'income') return '收入'
  if (type === 'transfer') return '轉帳'
  return '調整'
}

function labelOfTransaction(tx) {
  if (!tx) return '調整'
  const category = categoryStore.categories.find((item) => item.id === tx.category_id)
  if (category?.name) return category.name
  if (tx.type === 'transfer') return '轉帳'
  if (tx.type === 'adjustment') return '調整'
  const kind = category?.kind
  if (kind === 'income') return '收入'
  if (kind === 'expense') return '支出'
  return labelOf(tx.type)
}

function formatTime(iso) {
  if (!iso) return '-'
  return new Date(iso).toLocaleString('zh-TW', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function openEdit(tx) {
  if (!tx) return
  if (tx.type === 'transfer') {
    uiStore.pushToast('目前不支援編輯轉帳交易')
    return
  }
  editingTx.value = tx
  isEditOpen.value = true
}

function closeEdit() {
  isEditOpen.value = false
  editingTx.value = null
}

async function handleSaved() {
  try {
    if (transactionStore.homeFilterMode) {
      await transactionStore.loadHomeByFilter(transactionStore.homeFilterMode, transactionStore.homeFilterKey)
    } else {
      await transactionStore.loadRecent()
    }
  } finally {
    closeEdit()
  }
}
</script>

<style scoped>
.summary-card {
  padding: 14px;
}

h3 {
  margin: 0;
  font-size: 16px;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tx-list {
  list-style: none;
  padding: 0;
  margin: 12px 0 0;
  display: grid;
  gap: 8px;
}

.tx-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px;
  border: 1px solid var(--border);
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.01);
  cursor: pointer;
}

.tx-type {
  font-weight: 700;
  margin-bottom: 4px;
}

.empty-item {
  text-align: center;
  padding: 8px;
}

.icon-btn {
  width: 32px;
  height: 32px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
</style>
