<template>
  <article class="card summary-card">
    <header class="row">
      <h3>{{ title }}</h3>
      <RouterLink class="jump" to="/assets">查看</RouterLink>
    </header>

    <div class="split-grid">
      <section class="split-card income">
        <div class="label">收入</div>
        <div class="value">
          <MoneyText :value-minor="incomeMinor" />
        </div>
      </section>
      <section class="split-card expense">
        <div class="label">支出</div>
        <div class="value">
          <MoneyText :value-minor="expenseMinor" />
        </div>
      </section>
    </div>
  </article>
</template>

<script setup>
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import { useTransactionStore } from '@/ui/stores/transaction.store'

const transactionStore = useTransactionStore()

const title = computed(() => {
  if (transactionStore.homeFilterMode === 'all') return '全部收支'
  if (transactionStore.homeFilterMode === 'year') return `${transactionStore.homeFilterKey} 年收支`
  if (transactionStore.homeFilterMode === 'day') return `${transactionStore.homeFilterKey} 收支`
  if (transactionStore.homeFilterMode === 'month') {
    const [year, month] = String(transactionStore.homeFilterKey).split('-')
    if (year && month) return `${year}/${month} 收支`
  }
  return '當月收支'
})

const incomeMinor = computed(() => {
  return transactionStore.homeRecent
    .filter((tx) => tx.type === 'income' && tx.origin_type !== 'loan_payment')
    .reduce((total, tx) => total + Number(tx.amount_minor ?? 0), 0)
})

const expenseMinor = computed(() => {
  return transactionStore.homeRecent
    .filter((tx) => tx.type === 'expense' && tx.origin_type !== 'loan_payment')
    .reduce((total, tx) => total + Math.abs(Number(tx.amount_minor ?? 0)), 0)
})
</script>

<style scoped>
.summary-card {
  padding: 14px;
}

h3 {
  margin: 0;
  font-size: 16px;
}

.jump {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.split-grid {
  margin-top: 10px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.split-card {
  border-radius: 12px;
  padding: 12px;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.split-card .label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.9);
}

.split-card .value {
  margin-top: 8px;
  font-weight: 700;
}

.split-card.income {
  background: linear-gradient(145deg, rgba(75, 196, 154, 0.3), rgba(75, 196, 154, 0.12));
}

.split-card.expense {
  background: linear-gradient(145deg, rgba(240, 83, 83, 0.32), rgba(240, 83, 83, 0.12));
}
</style>
