<template>
  <teleport to="body">
    <section v-if="open" class="sheet-mask" @click.self="$emit('close')">
      <article class="sheet card">
        <header class="row">
          <h3>快速新增</h3>
          <button class="btn" @click="$emit('close')">關閉</button>
        </header>

        <div class="type-grid">
          <button
            v-for="item in types"
            :key="item.value"
            class="btn"
            :class="{ primary: model.type === item.value }"
            @click="model.type = item.value"
          >
            {{ item.label }}
          </button>
        </div>

        <div class="stack form-wrap">
          <label>
            金額（元）
            <input
              v-model="model.amountInput"
              type="text"
              inputmode="decimal"
              class="input"
              @input="handleAmountInput"
            />
          </label>

          <div class="date-extra-row">
            <div class="field-block">
              <span class="field-label">交易時間</span>
              <DateTimePickerField
                :date="model.occurredDate"
                :hour="model.occurredHour"
                :minute="model.occurredMinute"
                @update:date="model.occurredDate = $event"
                @update:hour="model.occurredHour = $event"
                @update:minute="model.occurredMinute = $event"
              />
            </div>

            <button type="button" class="btn extra-btn" @click="showExtra = true">
              附加資訊
            </button>
          </div>

          <div v-if="model.type !== 'transfer' && model.type !== 'adjustment'" class="inline-grid">
            <label>
              帳戶
              <select v-model="model.accountId" class="select">
                <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                  {{ account.name }}
                </option>
              </select>
            </label>

            <label>
              分類
              <select v-model="model.categoryId" class="select">
                <optgroup v-for="group in visibleCategoryGroups" :key="group.id" :label="group.name">
                  <option v-for="category in group.categories" :key="category.id" :value="category.id">
                    {{ category.name }}
                  </option>
                </optgroup>
              </select>
            </label>
          </div>

          <label v-else>
            帳戶
            <select v-model="model.accountId" class="select">
              <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                {{ account.name }}
              </option>
            </select>
          </label>

          <label v-if="model.type === 'transfer'">
            轉入帳戶
            <select v-model="model.peerAccountId" class="select">
              <option v-for="account in accountStore.accounts" :key="account.id" :value="account.id">
                {{ account.name }}
              </option>
            </select>
          </label>

          <section class="calc-panel">
            <div class="calc-grid">
              <button
                v-for="key in calcKeys"
                :key="key"
                type="button"
                class="calc-key btn"
                :class="{ equal: key === '=' }"
                @click="pressCalcKey(key)"
              >
                {{ key === '=' && equalShowsDone ? '完成' : key }}
              </button>
            </div>
          </section>
        </div>
      </article>
    </section>

    <section v-if="open && showExtra" class="extra-mask" @click.self="showExtra = false">
      <article class="extra-sheet card">
        <header class="row">
          <h4>附加資訊</h4>
          <button class="btn" @click="showExtra = false">完成</button>
        </header>

        <div class="stack extra-content">
          <div class="addon-wrap">
            <div class="row">
              <span class="field-label">附加項目</span>
              <button type="button" class="btn" @click="addAddonRow()">新增項目</button>
            </div>

            <div v-for="item in addonRows" :key="item.id" class="addon-row">
              <input v-model.trim="item.label" class="input addon-name" type="text" placeholder="名稱（例：優惠）" />
              <select v-model="item.direction" class="select addon-dir">
                <option value="plus">+</option>
                <option value="minus">-</option>
              </select>
              <input v-model.number="item.amountMajor" class="input addon-amount" type="number" min="0" step="0.01" placeholder="0" />
              <button type="button" class="btn danger addon-remove" @click="removeAddonRow(item.id)">刪除</button>
            </div>

            <div class="row">
              <small class="addon-desc">可自訂名稱與加減方式，按下後會套用到金額</small>
              <button type="button" class="addon-btn" @click="applyAddonRows">套用項目</button>
            </div>
          </div>

          <label>
            備註
            <textarea v-model="model.note" class="textarea" rows="3" />
          </label>

          <div v-if="model.type === 'expense'" class="reimburse-wrap">
            <span class="field-label">報銷</span>
            <button
              type="button"
              class="reimburse-btn"
              :class="{ active: model.isReimbursable }"
              @click="model.isReimbursable = !model.isReimbursable"
            >
              <span class="dot"></span>
              <span>{{ model.isReimbursable ? '已設為可報銷' : '設為可報銷' }}</span>
            </button>
          </div>
        </div>
      </article>
    </section>
  </teleport>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { useAccountStore } from '@/ui/stores/account.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useUiStore } from '@/ui/stores/ui.store'
import { useBudgetStore } from '@/ui/stores/budget.store'
import DateTimePickerField from '@/ui/components/common/DateTimePickerField.vue'

const props = defineProps({
  open: {
    type: Boolean,
    default: false,
  },
})

const emit = defineEmits(['close'])

const accountStore = useAccountStore()
const categoryStore = useCategoryStore()
const transactionStore = useTransactionStore()
const uiStore = useUiStore()
const budgetStore = useBudgetStore()

const types = [
  { value: 'expense', label: '支出' },
  { value: 'income', label: '收入' },
  { value: 'transfer', label: '轉帳' },
  { value: 'adjustment', label: '調整' },
]

const model = reactive({
  type: 'expense',
  amount: null,
  amountInput: '',
  occurredDate: '',
  occurredHour: 0,
  occurredMinute: 0,
  accountId: '',
  peerAccountId: '',
  categoryId: '',
  isReimbursable: false,
  note: '',
})
const showExtra = ref(false)
const addonRows = ref([])
let addonSeq = 1

const calcKeys = ['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '-', '0', '.', '⌫', '+', 'C', '=']

const visibleCategoryGroups = computed(() => {
  if (model.type === 'income') return categoryStore.incomeCategoryGroups
  return categoryStore.expenseCategoryGroups
})
const equalShowsDone = computed(() => {
  const input = String(model.amountInput ?? '').trim()
  if (!input || isFormulaExpression(input)) return false
  return Number.isFinite(evaluateExpression(input))
})

watch(
  () => props.open,
  (open) => {
    if (!open) {
      showExtra.value = false
      return
    }

    const defaults = defaultOccurredDateTime()
    model.type = 'expense'
    model.amount = null
    model.amountInput = ''
    model.occurredDate = defaults.date
    model.occurredHour = defaults.hour
    model.occurredMinute = defaults.minute
    model.isReimbursable = false
    model.note = ''
    showExtra.value = false
    model.accountId = accountStore.accounts[0]?.id ?? ''
    model.peerAccountId = accountStore.accounts[1]?.id ?? accountStore.accounts[0]?.id ?? ''
    model.categoryId = categoryStore.expenseCategories[0]?.id ?? ''
    addonRows.value = [createAddonRow()]
  },
  { immediate: true },
)

watch(
  () => model.type,
  (type) => {
    if (type === 'income') {
      model.categoryId = categoryStore.incomeCategories[0]?.id ?? ''
    }
    if (type === 'expense') {
      model.categoryId = categoryStore.expenseCategories[0]?.id ?? ''
    }
    if (!addonRows.value.length) {
      addonRows.value = [createAddonRow()]
    }
  },
)

async function submit() {
  const flowType = resolveTypeByCategory(model.type, model.categoryId)
  const amountMinor = Math.round(Number(model.amount ?? 0) * 100)
  const occurredAt = toOccurredAtIso(model.occurredDate, model.occurredHour, model.occurredMinute)

  if (!amountMinor) {
    uiStore.pushToast('請輸入有效金額', 'error')
    return
  }
  if (!occurredAt) {
    uiStore.pushToast('請選擇有效時間', 'error')
    return
  }
  if (model.type === 'transfer' && model.accountId === model.peerAccountId) {
    uiStore.pushToast('轉出與轉入帳戶不可相同', 'error')
    return
  }

  try {
    if (flowType === 'expense') {
      await transactionStore.addExpense({
        amountMinor,
        occurredAt,
        accountId: model.accountId,
        categoryId: model.categoryId,
        isReimbursable: model.isReimbursable,
        note: model.note,
      })
    } else if (flowType === 'income') {
      await transactionStore.addIncome({
        amountMinor,
        occurredAt,
        accountId: model.accountId,
        categoryId: model.categoryId,
        note: model.note,
      })
    } else if (model.type === 'adjustment') {
      await transactionStore.addAdjustment({
        amountMinor,
        occurredAt,
        accountId: model.accountId,
        note: model.note,
      })
    } else {
      await transactionStore.addTransfer({
        amountMinor,
        occurredAt,
        fromAccountId: model.accountId,
        toAccountId: model.peerAccountId,
        note: model.note,
      })
    }

    uiStore.pushToast('交易已新增')
    emit('close')
  } catch (error) {
    uiStore.pushToast(error.message ?? '新增失敗', 'error')
  }
}

function handleAmountInput() {
  syncAmountFromInput()
}

function createAddonRow() {
  return {
    id: `addon-${Date.now()}-${addonSeq++}`,
    label: defaultAddonLabel(),
    direction: defaultAddonDirection(),
    amountMajor: null,
  }
}

function defaultAddonLabel() {
  if (model.type === 'expense') return '優惠'
  if (model.type === 'income' || model.type === 'transfer') return '手續費'
  return '附加項目'
}

function defaultAddonDirection() {
  if (model.type === 'expense') return 'minus'
  return 'plus'
}

function addAddonRow() {
  addonRows.value.push(createAddonRow())
}

function removeAddonRow(rowId) {
  addonRows.value = addonRows.value.filter((item) => item.id !== rowId)
}

function applyAddonRows() {
  if (!addonRows.value.length) {
    uiStore.pushToast('請先新增附加項目', 'error')
    return
  }

  const base = Number(model.amount ?? 0)
  if (!Number.isFinite(base)) {
    uiStore.pushToast('請先輸入有效金額', 'error')
    return
  }

  const appliedItems = addonRows.value
    .map((item) => ({
      label: String(item.label || '附加項目').trim(),
      direction: item.direction === 'minus' ? 'minus' : 'plus',
      delta: round2(Math.abs(Number(item.amountMajor ?? 0))),
    }))
    .filter((item) => item.delta > 0)

  if (!appliedItems.length) {
    uiStore.pushToast('請輸入至少一筆有效附加金額', 'error')
    return
  }

  const totalDelta = appliedItems.reduce((total, item) => {
    return total + (item.direction === 'plus' ? item.delta : -item.delta)
  }, 0)

  let next = round2(base + totalDelta)
  if (model.type !== 'adjustment') {
    next = Math.max(0, next)
  }

  model.amount = next
  model.amountInput = formatAmountInput(next)

  const sign = totalDelta >= 0 ? '+' : '-'
  uiStore.pushToast(`已套用 ${appliedItems.length} 項，合計 ${sign}${formatAmountInput(Math.abs(totalDelta))} 元`)
}

async function pressCalcKey(key) {
  if (key === 'C') {
    model.amountInput = ''
    model.amount = null
    return
  }

  if (key === '⌫') {
    model.amountInput = model.amountInput.slice(0, -1)
    syncAmountFromInput()
    return
  }

  if (key === '=') {
    if (!isFormulaExpression(model.amountInput)) {
      await submit()
      return
    }

    const value = evaluateExpression(model.amountInput)
    if (Number.isFinite(value)) {
      model.amount = value
      model.amountInput = formatAmountInput(value)
    }
    return
  }

  if (isOperator(key)) {
    const last = model.amountInput.slice(-1)
    if (!model.amountInput && key !== '-') return
    if (isOperator(last)) {
      model.amountInput = `${model.amountInput.slice(0, -1)}${key}`
    } else {
      model.amountInput += key
    }
  } else {
    model.amountInput += key
  }

  syncAmountFromInput()
}

function syncAmountFromInput() {
  const value = evaluateExpression(model.amountInput)
  model.amount = Number.isFinite(value) ? value : null
}

function isOperator(char) {
  return ['+', '-', '×', '÷', '*', '/'].includes(char)
}

function isFormulaExpression(input) {
  const source = String(input ?? '').trim().replaceAll('×', '*').replaceAll('÷', '/').replace(/\s+/g, '')
  if (!source) return false
  let operatorCount = 0
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i]
    if (!['+', '-', '*', '/'].includes(ch)) continue
    if (i === 0 && ch === '-') continue
    operatorCount += 1
  }
  return operatorCount > 0
}

function evaluateExpression(input) {
  const source = String(input ?? '').trim()
  if (!source) return null
  if (!/^[0-9+\-×÷*/.\s]+$/.test(source)) return null

  const normalized = source.replaceAll('×', '*').replaceAll('÷', '/').replace(/\s+/g, '')
  const tokens = normalized.match(/(\d+(?:\.\d+)?)|[+\-*/]/g)
  if (!tokens || !tokens.length) return null

  const nums = []
  const ops = []
  let expectingNumber = true

  for (const token of tokens) {
    if (['+', '-', '*', '/'].includes(token)) {
      if (expectingNumber) {
        if (token === '-' && nums.length === 0) {
          nums.push(0)
        } else {
          return null
        }
      }
      while (ops.length && precedence(ops.at(-1)) >= precedence(token)) {
        if (!applyOperator(nums, ops.pop())) return null
      }
      ops.push(token)
      expectingNumber = true
      continue
    }

    const num = Number(token)
    if (!Number.isFinite(num)) return null
    nums.push(num)
    expectingNumber = false
  }

  if (expectingNumber) return null
  while (ops.length) {
    if (!applyOperator(nums, ops.pop())) return null
  }
  const result = nums[0]
  if (!Number.isFinite(result)) return null
  return Math.round(result * 100) / 100
}

function precedence(op) {
  if (op === '+' || op === '-') return 1
  if (op === '*' || op === '/') return 2
  return 0
}

function applyOperator(nums, op) {
  if (nums.length < 2) return false
  const b = nums.pop()
  const a = nums.pop()
  if (op === '/' && b === 0) return false
  const result = op === '+' ? a + b : op === '-' ? a - b : op === '*' ? a * b : a / b
  if (!Number.isFinite(result)) return false
  nums.push(result)
  return true
}

function formatAmountInput(value) {
  const rounded = Math.round(Number(value) * 100) / 100
  if (!Number.isFinite(rounded)) return ''
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2).replace(/\.?0+$/, '')
}

function round2(value) {
  return Math.round(Number(value) * 100) / 100
}

function defaultOccurredDateTime() {
  const currentMonth = monthKeyFromDate(new Date())
  if (budgetStore.monthKey && budgetStore.monthKey !== currentMonth) {
    return { date: `${budgetStore.monthKey}-01`, hour: 12, minute: 0 }
  }
  const now = new Date()
  return {
    date: formatDateInput(now),
    hour: now.getHours(),
    minute: now.getMinutes(),
  }
}

function toOccurredAtIso(dateInput, hourInput, minuteInput) {
  if (!dateInput) return ''
  const hour = Number(hourInput)
  const minute = Number(minuteInput)
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) return ''
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return ''

  const dateTime = `${dateInput}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:00`
  const parsed = new Date(dateTime)
  if (Number.isNaN(parsed.getTime())) return ''
  return parsed.toISOString()
}

function formatDateInput(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function monthKeyFromDate(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  return `${year}-${month}`
}

function resolveTypeByCategory(fallbackType, categoryId) {
  if (fallbackType !== 'expense' && fallbackType !== 'income') return fallbackType
  if (!categoryId) return fallbackType
  const kind = categoryStore.categories.find((item) => item.id === categoryId)?.kind
  if (kind === 'income') return 'income'
  if (kind === 'expense') return 'expense'
  return fallbackType
}

</script>

<style scoped>
.sheet-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 70;
}

.sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
  animation: slide-in 180ms ease;
}

h3 {
  margin: 0;
}

.type-grid {
  margin-top: 12px;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
}

.form-wrap {
  margin-top: 12px;
}

label {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.field-block {
  display: grid;
  gap: 6px;
  min-width: 0;
}

.field-label {
  font-size: 13px;
  color: var(--muted);
}

.calc-panel {
  margin-top: -2px;
}

.calc-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
}

.calc-key {
  padding: 12px 0;
  font-size: 16px;
  font-weight: 700;
}

.calc-key.equal {
  grid-column: 3 / span 2;
  background: var(--primary);
  border-color: color-mix(in srgb, var(--primary) 70%, black);
  color: var(--primary-contrast, #08111f);
}

.inline-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.date-extra-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: end;
}

.reimburse-wrap {
  display: grid;
  gap: 6px;
}

.reimburse-btn {
  border: 1px solid var(--field-border);
  border-radius: 12px;
  background: #112233;
  color: #cfe3ff;
  padding: 10px 12px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  cursor: pointer;
}

.reimburse-btn .dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #5b7ea4;
}

.reimburse-btn.active {
  background: linear-gradient(120deg, #22827a, #34b7a9);
  border-color: #5fd4c7;
  color: #08231f;
}

.reimburse-btn.active .dot {
  background: #0f4f47;
}

.extra-btn {
  white-space: nowrap;
  min-height: 42px;
  align-self: end;
  justify-content: center;
}

.extra-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 80;
}

.extra-sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
  animation: extra-slide-up 180ms ease;
}

h4 {
  margin: 0;
  font-size: 16px;
}

.extra-content {
  margin-top: 10px;
}

.addon-wrap {
  display: grid;
  gap: 6px;
}

.addon-row {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) 74px minmax(0, 1fr) 68px;
  gap: 8px;
  align-items: end;
}

.addon-name {
  min-width: 0;
}

.addon-dir {
  min-width: 0;
}

.addon-amount {
  min-width: 0;
}

.addon-remove {
  padding: 10px 0;
}

.addon-btn {
  border: 1px solid var(--field-border);
  border-radius: 12px;
  background: linear-gradient(135deg, #1a2c45, #19395b);
  color: #d7e6ff;
  padding: 10px 14px;
  display: inline-flex;
  align-items: center;
  text-align: left;
  cursor: pointer;
}

.addon-title {
  font-weight: 700;
}

.addon-desc {
  color: #9db2d3;
}

@keyframes extra-slide-up {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

@keyframes slide-in {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}
</style>
