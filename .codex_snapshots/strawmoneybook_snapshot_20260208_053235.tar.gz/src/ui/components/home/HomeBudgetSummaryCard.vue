<template>
  <article class="card summary-card">
    <header class="row">
      <h3>預算簡表</h3>
      <RouterLink class="jump" to="/budget">查看</RouterLink>
    </header>

    <div class="stat-wrap">
      <div class="mini-pie" :style="pieStyle"></div>

      <div class="remain-block">
        <div class="muted">剩餘</div>
        <div class="remain-value">
          <MoneyText :value-minor="budgetStore.remainMinor" />
        </div>
      </div>

      <div class="right-stack">
        <div class="line">
          <span class="muted">預算</span>
          <MoneyText :value-minor="budgetStore.totalBudgetMinor" />
        </div>
        <div class="line">
          <span class="muted">已用</span>
          <MoneyText :value-minor="budgetStore.totalSpentMinor" />
        </div>
      </div>
    </div>
  </article>
</template>

<script setup>
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import MoneyText from '@/ui/components/common/MoneyText.vue'
import { useBudgetStore } from '@/ui/stores/budget.store'

const budgetStore = useBudgetStore()

const pieStyle = computed(() => {
  const total = Math.max(0, Number(budgetStore.totalBudgetMinor ?? 0))
  const spent = Math.max(0, Number(budgetStore.totalSpentMinor ?? 0))
  if (!total) {
    return {
      background: 'conic-gradient(#273546 0deg 360deg)',
    }
  }
  const usedDeg = Math.min(360, (spent / total) * 360)
  return {
    background: `conic-gradient(#f0a84a 0deg ${usedDeg}deg, #2f945c ${usedDeg}deg 360deg)`,
  }
})
</script>

<style scoped>
.summary-card {
  padding: 14px;
}

h3 {
  margin: 0;
  font-size: 16px;
}

.jump {
  text-decoration: none;
  color: var(--primary-soft);
  font-size: 13px;
}

.stat-wrap {
  margin-top: 12px;
  display: grid;
  grid-template-columns: 56px minmax(0, 1fr) minmax(0, 1.4fr);
  align-items: center;
  gap: 10px;
}

.mini-pie {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.remain-block {
  display: grid;
  gap: 4px;
}

.remain-value {
  font-weight: 700;
}

.right-stack {
  display: grid;
  gap: 6px;
}

.line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
</style>
