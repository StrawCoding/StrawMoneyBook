<template>
  <teleport to="body">
    <section v-if="open" class="sheet-mask" @click.self="$emit('close')">
      <article class="sheet card">
        <header class="row">
          <h3>{{ model.id ? '編輯預算項目' : '新增預算項目' }}</h3>
          <button class="btn" @click="$emit('close')">關閉</button>
        </header>

        <div class="stack form-wrap">
          <label>
            分類
            <select v-model="model.categoryId" class="select">
              <optgroup v-for="group in groupedCategoryOptions" :key="group.id" :label="group.name">
                <option v-for="category in group.categories" :key="category.id" :value="category.id">
                  {{ category.name }}
                </option>
              </optgroup>
            </select>
          </label>

          <label>
            預算金額（元）
            <input v-model.number="model.amountMajor" class="input" type="number" min="0" step="1" />
          </label>
        </div>

        <footer class="row footer">
          <button class="btn" @click="$emit('close')">取消</button>
          <button class="btn primary" @click="onSave">儲存</button>
        </footer>
      </article>
    </section>
  </teleport>
</template>

<script setup>
import { computed, reactive, watch } from 'vue'

const props = defineProps({
  open: {
    type: Boolean,
    default: false,
  },
  item: {
    type: Object,
    default: null,
  },
  categories: {
    type: Array,
    default: () => [],
  },
  categoryGroups: {
    type: Array,
    default: () => [],
  },
})

const emit = defineEmits(['close', 'save'])

const model = reactive({
  id: '',
  categoryId: '',
  amountMajor: null,
})

const categoryOptions = computed(() => props.categories ?? [])
const groupedCategoryOptions = computed(() => {
  if ((props.categoryGroups ?? []).length > 0) return props.categoryGroups
  return [
    {
      id: '__default__',
      name: '分類',
      categories: categoryOptions.value,
    },
  ]
})

watch(
  () => [props.open, props.item],
  () => {
    if (!props.open) return

    if (props.item) {
      model.id = props.item.id
      model.categoryId = props.item.category_id ?? ''
      model.amountMajor = Number(props.item.amount_minor ?? 0) / 100
      return
    }

    model.id = ''
    model.categoryId = categoryOptions.value[0]?.id ?? ''
    model.amountMajor = null
  },
  { immediate: true },
)

function onSave() {
  emit('save', {
    id: model.id || undefined,
    categoryId: model.categoryId,
    amountMinor: Math.round(Number(model.amountMajor ?? 0) * 100),
  })
}
</script>

<style scoped>
.sheet-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: flex-end;
  z-index: 70;
}

.sheet {
  width: min(900px, 100vw);
  border-radius: 18px 18px 0 0;
  padding: 14px;
  animation: slide-in 180ms ease;
}

h3 {
  margin: 0;
}

.form-wrap {
  margin-top: 12px;
}

label {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.footer {
  margin-top: 12px;
}

@keyframes slide-in {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}
</style>
