<template>
  <div ref="rootRef" class="dt-picker">
    <button type="button" class="input trigger" @click="open = !open">
      <span>{{ displayText }}</span>
      <span class="icon">🗓</span>
    </button>

    <section v-if="open" class="panel card">
      <header class="month-head">
        <button type="button" class="nav-btn" @click="shiftMonth(-1)">‹</button>
        <strong>{{ monthLabel }}</strong>
        <button type="button" class="nav-btn" @click="shiftMonth(1)">›</button>
      </header>

      <div class="week-row">
        <span v-for="w in weekNames" :key="w">{{ w }}</span>
      </div>

      <div class="day-grid">
        <button
          v-for="cell in dayCells"
          :key="cell.iso"
          type="button"
          class="day-btn"
          :class="{ muted: !cell.inMonth, active: cell.iso === date, today: cell.isToday }"
          @click="pickDate(cell.iso)"
        >
          {{ cell.day }}
        </button>
      </div>

      <div class="time-wrap">
        <div class="time-col">
          <small>時</small>
          <div class="time-list">
            <button
              v-for="h in hours"
              :key="`h-${h}`"
              type="button"
              class="time-btn"
              :class="{ active: h === hour }"
              @click="pickHour(h)"
            >
              {{ pad2(h) }}
            </button>
          </div>
        </div>
        <div class="time-col">
          <small>分</small>
          <div class="time-list">
            <button
              v-for="m in minutes"
              :key="`m-${m}`"
              type="button"
              class="time-btn"
              :class="{ active: m === minute }"
              @click="pickMinute(m)"
            >
              {{ pad2(m) }}
            </button>
          </div>
        </div>
      </div>

      <footer class="foot">
        <button type="button" class="btn" @click="setNow">現在</button>
        <button type="button" class="btn" @click="open = false">完成</button>
      </footer>
    </section>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'

const props = defineProps({
  date: {
    type: String,
    required: true,
  },
  hour: {
    type: Number,
    required: true,
  },
  minute: {
    type: Number,
    required: true,
  },
})

const emit = defineEmits(['update:date', 'update:hour', 'update:minute'])

const weekNames = ['日', '一', '二', '三', '四', '五', '六']
const hours = Array.from({ length: 24 }, (_, i) => i)
const minutes = Array.from({ length: 60 }, (_, i) => i)
const open = ref(false)
const rootRef = ref(null)
const viewMonth = ref(parseDate(props.date) ?? new Date())

watch(
  () => props.date,
  (date) => {
    const parsed = parseDate(date)
    if (parsed) viewMonth.value = parsed
  },
)

const monthLabel = computed(() => {
  const y = viewMonth.value.getFullYear()
  const m = viewMonth.value.getMonth() + 1
  return `${y}年${m}月`
})

const displayText = computed(() => {
  const parsed = parseDate(props.date)
  if (!parsed) return '-'
  const datePart = parsed.toLocaleDateString('zh-TW', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  })
  return `${datePart} ${pad2(props.hour)}:${pad2(props.minute)}`
})

const dayCells = computed(() => {
  const first = new Date(viewMonth.value.getFullYear(), viewMonth.value.getMonth(), 1)
  const start = new Date(first)
  start.setDate(first.getDate() - first.getDay())

  const cells = []
  const todayIso = toDateInput(new Date())
  for (let i = 0; i < 42; i += 1) {
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    const iso = toDateInput(d)
    cells.push({
      iso,
      day: d.getDate(),
      inMonth: d.getMonth() === viewMonth.value.getMonth(),
      isToday: iso === todayIso,
    })
  }
  return cells
})

function shiftMonth(delta) {
  const next = new Date(viewMonth.value)
  next.setMonth(next.getMonth() + delta, 1)
  viewMonth.value = next
}

function pickDate(nextDate) {
  emit('update:date', nextDate)
}

function pickHour(nextHour) {
  emit('update:hour', nextHour)
}

function pickMinute(nextMinute) {
  emit('update:minute', nextMinute)
}

function setNow() {
  const now = new Date()
  emit('update:date', toDateInput(now))
  emit('update:hour', now.getHours())
  emit('update:minute', now.getMinutes())
}

function parseDate(dateInput) {
  if (!dateInput) return null
  const parsed = new Date(`${dateInput}T00:00:00`)
  if (Number.isNaN(parsed.getTime())) return null
  return parsed
}

function toDateInput(date) {
  const y = date.getFullYear()
  const m = pad2(date.getMonth() + 1)
  const d = pad2(date.getDate())
  return `${y}-${m}-${d}`
}

function pad2(value) {
  return String(value).padStart(2, '0')
}

function handleWindowClick(event) {
  if (!rootRef.value?.contains(event.target)) {
    open.value = false
  }
}

onMounted(() => {
  window.addEventListener('click', handleWindowClick)
})

onBeforeUnmount(() => {
  window.removeEventListener('click', handleWindowClick)
})
</script>

<style scoped>
.dt-picker {
  position: relative;
}

.trigger {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.icon {
  opacity: 0.85;
}

.panel {
  position: absolute;
  top: -90px;
  left: 0;
  right: 0;
  z-index: 80;
  border: 1px solid var(--field-border);
  border-radius: 14px;
  padding: 10px;
  background: #131b26;
  box-shadow: 0 14px 36px rgba(0, 0, 0, 0.48);
}

.month-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.nav-btn {
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 10px;
  background: #1a2a3d;
  color: var(--primary-soft);
  font-size: 20px;
  cursor: pointer;
}

.week-row {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  text-align: center;
  color: var(--muted);
  font-size: 12px;
  margin-bottom: 4px;
}

.day-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 4px;
}

.day-btn {
  border: 0;
  background: transparent;
  color: var(--text);
  border-radius: 10px;
  height: 34px;
  cursor: pointer;
}

.day-btn.muted {
  color: #627086;
}

.day-btn.today {
  border: 1px solid rgba(232, 162, 40, 0.5);
}

.day-btn.active {
  background: linear-gradient(120deg, #d38f16, var(--primary));
  color: var(--primary-contrast);
  font-weight: 700;
}

.time-wrap {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid var(--field-border);
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.time-col small {
  color: var(--muted);
}

.time-list {
  margin-top: 6px;
  max-height: 132px;
  overflow: auto;
  border: 1px solid var(--field-border);
  border-radius: 10px;
  padding: 4px;
  display: grid;
  gap: 4px;
  background: #0f161f;
}

.time-btn {
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--text);
  height: 28px;
  cursor: pointer;
}

.time-btn.active {
  background: #2a7de1;
  color: #fff;
  font-weight: 700;
}

.foot {
  margin-top: 10px;
  display: flex;
  justify-content: flex-end;
  gap: 6px;
}
</style>
