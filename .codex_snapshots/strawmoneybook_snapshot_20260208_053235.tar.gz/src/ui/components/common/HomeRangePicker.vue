<template>
  <div ref="rootRef" class="range-picker">
    <button ref="triggerRef" type="button" class="input trigger" @click="toggleOpen">
      <span>{{ displayLabel }}</span>
      <span class="icon">▾</span>
    </button>

    <teleport to="body">
      <section v-if="open" ref="panelRef" class="panel card" :style="panelStyle">
        <header class="panel-head">
          <button type="button" class="nav-btn" @click="shift(-1)">‹</button>
          <strong>{{ headerLabel }}</strong>
          <button type="button" class="nav-btn" @click="shift(1)">›</button>
        </header>

        <div v-if="mode === 'year'" class="year-grid">
          <button
            v-for="y in yearOptions"
            :key="`y-${y}`"
            type="button"
            class="cell-btn"
            :class="{ active: y === year }"
            @click="pickYear(y)"
          >
            {{ y }}
          </button>
        </div>

        <div v-else-if="mode === 'month'" class="month-grid">
          <button
            v-for="m in 12"
            :key="`m-${m}`"
            type="button"
            class="cell-btn"
            :class="{ active: m === viewMonth + 1 }"
            @click="pickMonth(m)"
          >
            {{ monthName(m) }}
          </button>
        </div>

        <div v-else>
          <div class="week-row">
            <span v-for="w in weekNames" :key="w">{{ w }}</span>
          </div>
          <div class="day-grid">
            <button
              v-for="cell in dayCells"
              :key="cell.iso"
              type="button"
              class="cell-btn day-btn"
              :class="{ muted: !cell.inMonth, active: cell.iso === day }"
              @click="pickDay(cell.iso)"
            >
              {{ cell.day }}
            </button>
          </div>
        </div>

        <footer class="foot">
          <button type="button" class="btn" @click="pickToday">今天</button>
          <button type="button" class="btn" @click="open = false">關閉</button>
        </footer>
      </section>
    </teleport>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'

const props = defineProps({
  mode: {
    type: String,
    default: 'month',
  },
  year: {
    type: Number,
    default: new Date().getFullYear(),
  },
  month: {
    type: String,
    default: '',
  },
  day: {
    type: String,
    default: '',
  },
})

const emit = defineEmits(['update:year', 'update:month', 'update:day'])

const open = ref(false)
const rootRef = ref(null)
const triggerRef = ref(null)
const panelRef = ref(null)
const panelStyle = ref({})
const weekNames = ['日', '一', '二', '三', '四', '五', '六']
const now = new Date()
const viewYear = ref(props.year || now.getFullYear())
const viewMonth = ref(parseMonth(props.month)?.month ?? now.getMonth())

watch(
  () => props.year,
  (value) => {
    if (Number.isFinite(Number(value))) viewYear.value = Number(value)
  },
)

watch(
  () => props.month,
  (value) => {
    const parsed = parseMonth(value)
    if (!parsed) return
    viewYear.value = parsed.year
    viewMonth.value = parsed.month
  },
)

watch(
  () => props.day,
  (value) => {
    const parsed = parseDay(value)
    if (!parsed) return
    viewYear.value = parsed.year
    viewMonth.value = parsed.month
  },
)

const displayLabel = computed(() => {
  if (props.mode === 'year') return `${props.year || now.getFullYear()} 年`
  if (props.mode === 'day') return props.day || toDayKey(now)
  return props.month || toMonthKey(now)
})

const headerLabel = computed(() => {
  if (props.mode === 'year') return `${viewYear.value} 年`
  if (props.mode === 'month') return `${viewYear.value} 年`
  return `${viewYear.value} 年 ${viewMonth.value + 1} 月`
})

const yearOptions = computed(() => {
  const center = viewYear.value
  return Array.from({ length: 12 }, (_, i) => center - 6 + i)
})

const dayCells = computed(() => {
  const first = new Date(viewYear.value, viewMonth.value, 1)
  const start = new Date(first)
  start.setDate(first.getDate() - first.getDay())

  const cells = []
  for (let i = 0; i < 42; i += 1) {
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    cells.push({
      day: d.getDate(),
      iso: toDayKey(d),
      inMonth: d.getMonth() === viewMonth.value,
    })
  }
  return cells
})

function shift(offset) {
  if (props.mode === 'year') {
    viewYear.value += offset * 12
    return
  }
  if (props.mode === 'month') {
    viewYear.value += offset
    return
  }
  const next = new Date(viewYear.value, viewMonth.value + offset, 1)
  viewYear.value = next.getFullYear()
  viewMonth.value = next.getMonth()
}

function pickYear(value) {
  emit('update:year', value)
  open.value = false
}

function pickMonth(value) {
  const monthKey = `${viewYear.value}-${String(value).padStart(2, '0')}`
  emit('update:month', monthKey)
  open.value = false
}

function pickDay(iso) {
  emit('update:day', iso)
  open.value = false
}

function pickToday() {
  const today = new Date()
  if (props.mode === 'year') {
    emit('update:year', today.getFullYear())
  } else if (props.mode === 'month') {
    emit('update:month', toMonthKey(today))
  } else {
    emit('update:day', toDayKey(today))
  }
  open.value = false
}

function toggleOpen() {
  open.value = !open.value
  if (open.value) {
    updatePanelPosition()
  }
}

function monthName(month) {
  const map = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月']
  return map[month - 1] ?? `${month}月`
}

function parseMonth(monthKey) {
  const [year, month] = String(monthKey ?? '').split('-').map((part) => Number(part))
  if (!year || !month) return null
  return { year, month: month - 1 }
}

function parseDay(dayKey) {
  const [year, month, day] = String(dayKey ?? '').split('-').map((part) => Number(part))
  if (!year || !month || !day) return null
  return { year, month: month - 1, day }
}

function toMonthKey(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  return `${y}-${m}`
}

function toDayKey(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

function handleWindowClick(event) {
  if (rootRef.value?.contains(event.target)) return
  if (panelRef.value?.contains(event.target)) return
  open.value = false
}

function handleWindowResize() {
  if (!open.value) return
  updatePanelPosition()
}

function updatePanelPosition() {
  const trigger = triggerRef.value
  if (!trigger) return
  const rect = trigger.getBoundingClientRect()
  const panelWidth = Math.max(280, rect.width)
  const viewportWidth = window.innerWidth
  const left = Math.min(Math.max(8, rect.left), Math.max(8, viewportWidth - panelWidth - 8))
  const top = rect.bottom + 8
  panelStyle.value = {
    position: 'fixed',
    top: `${top}px`,
    left: `${left}px`,
    width: `${panelWidth}px`,
  }
}

watch(open, (value) => {
  if (value) {
    updatePanelPosition()
  } else {
    panelStyle.value = {}
  }
})

function handleWindowScroll() {
  if (!open.value) return
  updatePanelPosition()
}

onMounted(() => {
  window.addEventListener('click', handleWindowClick)
  window.addEventListener('resize', handleWindowResize)
  window.addEventListener('scroll', handleWindowScroll, true)
})

onBeforeUnmount(() => {
  window.removeEventListener('click', handleWindowClick)
  window.removeEventListener('resize', handleWindowResize)
  window.removeEventListener('scroll', handleWindowScroll, true)
})
</script>

<style scoped>
.range-picker {
  position: relative;
}

.trigger {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.icon {
  opacity: 0.8;
}

.panel {
  border: 1px solid var(--field-border);
  border-radius: 14px;
  padding: 10px;
  background: #131b26;
  box-shadow: 0 14px 36px rgba(0, 0, 0, 0.42);
  z-index: 120;
}

.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.nav-btn {
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 10px;
  background: #1a2a3d;
  color: var(--primary-soft);
  font-size: 20px;
  cursor: pointer;
}

.year-grid,
.month-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
}

.week-row {
  display: grid;
  grid-template-columns: repeat(7, minmax(0, 1fr));
  text-align: center;
  color: var(--muted);
  font-size: 12px;
  margin-bottom: 4px;
}

.day-grid {
  display: grid;
  grid-template-columns: repeat(7, minmax(0, 1fr));
  gap: 6px;
}

.cell-btn {
  border: 0;
  border-radius: 10px;
  background: #1a2433;
  color: var(--text);
  min-height: 34px;
  cursor: pointer;
  font-weight: 700;
}

.day-btn {
  min-height: 32px;
}

.cell-btn.muted {
  opacity: 0.45;
}

.cell-btn.active {
  background: #9fc6f8;
  color: #13263d;
}

.foot {
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
  gap: 8px;
}
</style>
