<template>
  <section class="toast-host">
    <article v-for="toast in uiStore.toasts" :key="toast.id" class="toast" :class="toast.type">
      {{ toast.message }}
    </article>
  </section>
</template>

<script setup>
import { useUiStore } from '@/ui/stores/ui.store'

const uiStore = useUiStore()
</script>

<style scoped>
.toast-host {
  position: fixed;
  left: 14px;
  right: 14px;
  bottom: 86px;
  display: grid;
  gap: 8px;
  pointer-events: none;
  z-index: 80;
}

.toast {
  justify-self: center;
  max-width: 520px;
  width: 100%;
  border-radius: 12px;
  border: 1px solid var(--border);
  background: #14202e;
  color: var(--text);
  padding: 10px 12px;
  box-shadow: var(--shadow);
  animation: slide-up 180ms ease;
}

.toast.error {
  border-color: rgba(240, 83, 83, 0.55);
  background: #311a1a;
}

@keyframes slide-up {
  from {
    transform: translateY(14px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
</style>
