<template>
  <div ref="rootRef" class="ledger-switcher">
    <button class="select switcher-btn" type="button" @click="toggleOpen">
      <span>{{ activeLedgerName }}</span>
      <span class="arrow" :class="{ open: isOpen }">▾</span>
    </button>

    <div v-if="isOpen" class="menu card">
      <button
        v-for="ledger in ledgerStore.ledgers"
        :key="ledger.id"
        class="menu-item"
        :class="{ active: ledger.id === ledgerStore.activeLedgerId }"
        type="button"
        @click="onChange(ledger.id)"
      >
        {{ ledger.name }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useUiStore } from '@/ui/stores/ui.store'

const ledgerStore = useLedgerStore()
const uiStore = useUiStore()
const isOpen = ref(false)
const rootRef = ref(null)

const activeLedgerName = computed(() => {
  return ledgerStore.activeLedger?.name ?? '請選擇帳本'
})

function toggleOpen() {
  isOpen.value = !isOpen.value
}

async function onChange(nextLedgerId) {
  isOpen.value = false
  if (!nextLedgerId || nextLedgerId === ledgerStore.activeLedgerId) return
  await ledgerStore.switchLedger(nextLedgerId)
  uiStore.pushToast('已切換帳本')
}

function onWindowClick(event) {
  if (!rootRef.value?.contains(event.target)) {
    isOpen.value = false
  }
}

onMounted(() => {
  window.addEventListener('click', onWindowClick)
})

onBeforeUnmount(() => {
  window.removeEventListener('click', onWindowClick)
})
</script>

<style scoped>
.ledger-switcher {
  position: relative;
  display: flex;
  align-items: center;
  min-width: 160px;
}

.switcher-btn {
  background-image: none;
  padding-right: 12px;
  justify-content: space-between;
  gap: 10px;
}

.menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 30;
  border-radius: 12px;
  border: 1px solid var(--field-border);
  background: #0f161f;
  overflow: hidden;
  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.36);
}

.menu-item {
  width: 100%;
  border: 0;
  background: transparent;
  color: var(--text);
  text-align: left;
  padding: 10px 12px;
  cursor: pointer;
}

.menu-item:hover {
  background: rgba(232, 162, 40, 0.12);
}

.menu-item.active {
  background: rgba(232, 162, 40, 0.2);
  color: var(--primary-soft);
  font-weight: 700;
}

.arrow {
  transition: transform 120ms ease;
}

.arrow.open {
  transform: rotate(180deg);
}

.switcher-btn {
  min-width: 160px;
}
</style>
