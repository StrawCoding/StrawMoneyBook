import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      name: 'home',
      path: '/',
      component: () => import('@/ui/views/home.vue'),
      meta: { tab: 'home' },
    },
    {
      name: 'budget',
      path: '/budget',
      component: () => import('@/ui/views/budgeting.vue'),
      meta: { tab: 'budget' },
    },
    {
      name: 'analysis',
      path: '/analysis',
      component: () => import('@/ui/views/analysis.vue'),
      meta: { tab: 'analysis' },
    },
    {
      name: 'analysis-print',
      path: '/analysis/print',
      component: () => import('@/ui/views/AnalysisPrintPage.vue'),
      meta: { tab: 'analysis' },
    },
    {
      name: 'transaction-search',
      path: '/transactions/search',
      component: () => import('@/ui/views/TransactionSearchPage.vue'),
      meta: { tab: 'home' },
    },
    {
      name: 'features',
      path: '/features',
      component: () => import('@/ui/views/FeatureListPage.vue'),
      meta: { tab: 'home' },
    },
    {
      name: 'assets',
      path: '/assets',
      component: () => import('@/ui/views/assets.vue'),
      meta: { tab: 'assets' },
    },
    {
      name: 'settings',
      path: '/settings',
      component: () => import('@/ui/views/settings.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/export',
      name: 'settings-export',
      component: () => import('@/ui/views/settings/SettingsExportPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/import',
      name: 'settings-import',
      component: () => import('@/ui/views/settings/SettingsImportPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/repair',
      name: 'settings-repair',
      component: () => import('@/ui/views/settings/SettingsRepairPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/ledgers',
      name: 'settings-ledgers',
      component: () => import('@/ui/views/settings/SettingsLedgerPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/categories',
      name: 'settings-categories',
      component: () => import('@/ui/views/settings/SettingsCategoryPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      path: '/settings/personalization',
      name: 'settings-personalization',
      component: () => import('@/ui/views/settings/SettingsPersonalizationPage.vue'),
      meta: { tab: 'settings' },
    },
    {
      name: 'loans',
      path: '/loans',
      component: () => import('@/ui/views/loans/LoanListPage.vue'),
    },
    {
      name: 'reimbursements',
      path: '/reimbursements',
      component: () => import('@/ui/views/reimbursements/ReimbursementListPage.vue'),
    },
    {
      name: 'account-detail',
      path: '/accounts/:id',
      component: () => import('@/ui/views/accounts/AccountDetailPage.vue'),
      props: true,
    },
  ],
})

export default router
