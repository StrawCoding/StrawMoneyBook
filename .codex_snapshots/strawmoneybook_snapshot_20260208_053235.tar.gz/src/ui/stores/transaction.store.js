import { defineStore } from 'pinia'
import {
  listRecentTransactions,
  listTransactionsByMonth,
  listTransactionsByYear,
  listTransactionsByDay,
  listAllTransactions,
} from '@/core/repositories/transaction.repo'
import {
  createExpense,
  createIncome,
  createAdjustment,
  createTransfer,
  updateManualTransaction,
  deleteManualTransaction,
} from '@/core/services/transaction.service'
import { useLedgerStore } from '@/ui/stores/ledger.store'
import { useAccountStore } from '@/ui/stores/account.store'
import { useBudgetStore } from '@/ui/stores/budget.store'

export const useTransactionStore = defineStore('transaction', {
  state: () => ({
    recent: [],
    homeRecent: [],
    homeFilterMode: '',
    homeFilterKey: '',
    loading: false,
    homeLoading: false,
    filter: {
      accountId: '',
      categoryId: '',
      monthKey: '',
      minMinor: null,
      maxMinor: null,
    },
  }),

  actions: {
    async loadRecent(limit = 30) {
      const ledgerStore = useLedgerStore()
      const ledgerId = ledgerStore.activeLedgerId
      if (!ledgerId) return

      this.loading = true
      try {
        this.recent = await listRecentTransactions(ledgerId, limit)
      } finally {
        this.loading = false
      }
    },

    async loadHomeMonth(monthKey) {
      await this.loadHomeByFilter('month', monthKey)
    },

    async loadHomeYear(yearKey) {
      await this.loadHomeByFilter('year', yearKey)
    },

    async loadHomeDay(dayKey) {
      await this.loadHomeByFilter('day', dayKey)
    },

    async loadHomeAll() {
      await this.loadHomeByFilter('all', '')
    },

    async loadHomeByFilter(mode, key) {
      const ledgerStore = useLedgerStore()
      const ledgerId = ledgerStore.activeLedgerId
      const normalizedMode = ['all', 'year', 'month', 'day'].includes(mode) ? mode : 'month'
      const normalizedKey = String(key ?? '')

      if (normalizedMode !== 'all' && !normalizedKey) {
        this.homeFilterMode = ''
        this.homeFilterKey = ''
        this.homeRecent = []
        return
      }

      this.homeFilterMode = normalizedMode
      this.homeFilterKey = normalizedKey
      if (!ledgerId) return

      this.homeLoading = true
      try {
        if (normalizedMode === 'all') {
          this.homeRecent = await listAllTransactions(ledgerId)
          return
        }
        if (normalizedMode === 'year') {
          this.homeRecent = await listTransactionsByYear(ledgerId, normalizedKey)
          return
        }
        if (normalizedMode === 'day') {
          this.homeRecent = await listTransactionsByDay(ledgerId, normalizedKey)
          return
        }
        this.homeRecent = await listTransactionsByMonth(ledgerId, normalizedKey)
      } finally {
        this.homeLoading = false
      }
    },

    async addExpense(payload) {
      const ledgerStore = useLedgerStore()
      await createExpense(ledgerStore.activeLedgerId, payload)
      await this.refreshAfterWrite()
    },

    async addIncome(payload) {
      const ledgerStore = useLedgerStore()
      await createIncome(ledgerStore.activeLedgerId, payload)
      await this.refreshAfterWrite()
    },

    async addAdjustment(payload) {
      const ledgerStore = useLedgerStore()
      await createAdjustment(ledgerStore.activeLedgerId, payload)
      await this.refreshAfterWrite()
    },

    async addTransfer(payload) {
      const ledgerStore = useLedgerStore()
      await createTransfer(ledgerStore.activeLedgerId, payload)
      await this.refreshAfterWrite()
    },

    async updateTransaction(txId, payload) {
      const ledgerStore = useLedgerStore()
      await updateManualTransaction(ledgerStore.activeLedgerId, txId, payload)
      await this.refreshAfterWrite()
    },

    async deleteTransaction(txId) {
      const ledgerStore = useLedgerStore()
      await deleteManualTransaction(ledgerStore.activeLedgerId, txId)
      await this.refreshAfterWrite()
    },

    async refreshAfterWrite() {
      const accountStore = useAccountStore()
      const budgetStore = useBudgetStore()
      const jobs = [this.loadRecent(), accountStore.load(), budgetStore.loadMonth(budgetStore.monthKey)]

      if (this.homeFilterMode) {
        jobs.push(this.loadHomeByFilter(this.homeFilterMode, this.homeFilterKey))
      }

      await Promise.all(jobs)
    },
  },
})
