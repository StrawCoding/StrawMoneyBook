import { defineStore } from 'pinia'
import {
  listAccountGroups,
  listAccounts,
  getAccountBalances,
  createAccountGroup,
  createAccount,
  deleteAccountIfUnused,
} from '@/core/repositories/account.repo'
import { useLedgerStore } from '@/ui/stores/ledger.store'

export const useAccountStore = defineStore('account', {
  state: () => ({
    groups: [],
    accounts: [],
    balances: [],
    loading: false,
  }),

  getters: {
    groupSummaries(state) {
      const balanceMap = new Map(state.balances.map((item) => [item.id, Number(item.balance_minor)]))
      return state.groups.map((group) => {
        const groupAccounts = state.accounts.filter((account) => account.group_id === group.id)
        const totalMinor = groupAccounts.reduce((total, account) => {
          return total + (balanceMap.get(account.id) ?? Number(account.opening_balance_minor ?? 0))
        }, 0)

        return {
          ...group,
          accountCount: groupAccounts.length,
          totalMinor,
        }
      })
    },

    totalAssetsMinor(state) {
      return state.balances.reduce((total, item) => total + Number(item.balance_minor ?? 0), 0)
    },
  },

  actions: {
    async load(options = {}) {
      const ledgerStore = useLedgerStore()
      const ledgerId = ledgerStore.activeLedgerId
      if (!ledgerId) return

      this.loading = true
      try {
        const includeArchived = Boolean(options.includeArchived)
        const [groups, accounts, balances] = await Promise.all([
          listAccountGroups(ledgerId),
          listAccounts(ledgerId, { includeArchived }),
          getAccountBalances(ledgerId, { includeArchived }),
        ])

        this.groups = groups
        this.accounts = accounts
        this.balances = balances
      } finally {
        this.loading = false
      }
    },

    async addGroup(payload) {
      const ledgerStore = useLedgerStore()
      await createAccountGroup(ledgerStore.activeLedgerId, payload)
      await this.load()
    },

    async addAccount(payload) {
      const ledgerStore = useLedgerStore()
      await createAccount(ledgerStore.activeLedgerId, payload)
      await this.load()
    },

    async removeAccount(accountId) {
      if (this.accounts.length <= 1) {
        throw new Error('至少需要保留一個帳戶')
      }
      const ledgerStore = useLedgerStore()
      await deleteAccountIfUnused(ledgerStore.activeLedgerId, accountId)
      await this.load()
    },
  },
})
