import { defineStore } from 'pinia'
import {
  listCategoryGroups,
  listCategories,
  createCategoryGroup,
  createCategory,
  deleteCategoryIfUnused,
  deleteCategoryGroupIfUnused,
  findFirstCategoryByKind,
} from '@/core/repositories/category.repo'
import { useLedgerStore } from '@/ui/stores/ledger.store'

function buildCategoryGroupsByKind(groups, categories, kind) {
  const filteredCategories = categories.filter((category) => category.kind === kind || category.kind === 'both')
  const grouped = groups
    .filter((group) => group.kind === kind || group.kind === 'both')
    .map((group) => ({
      ...group,
      categories: filteredCategories.filter((category) => category.group_id === group.id),
    }))
    .filter((group) => group.categories.length > 0)

  const orphanCategories = filteredCategories.filter(
    (category) => !grouped.some((group) => group.id === category.group_id),
  )

  if (orphanCategories.length > 0) {
    grouped.push({
      id: '__ungrouped__',
      name: '未分組',
      kind,
      categories: orphanCategories,
    })
  }

  return grouped
}

export const useCategoryStore = defineStore('category', {
  state: () => ({
    groups: [],
    categories: [],
    loading: false,
  }),

  getters: {
    expenseCategories(state) {
      return state.categories.filter((category) => category.kind === 'expense' || category.kind === 'both')
    },

    incomeCategories(state) {
      return state.categories.filter((category) => category.kind === 'income' || category.kind === 'both')
    },

    expenseCategoryGroups(state) {
      return buildCategoryGroupsByKind(state.groups, state.categories, 'expense')
    },

    incomeCategoryGroups(state) {
      return buildCategoryGroupsByKind(state.groups, state.categories, 'income')
    },
  },

  actions: {
    async load(options = {}) {
      const ledgerStore = useLedgerStore()
      const ledgerId = ledgerStore.activeLedgerId
      if (!ledgerId) return

      this.loading = true
      try {
        const includeArchived = Boolean(options.includeArchived)
        const [groups, categories] = await Promise.all([
          listCategoryGroups(ledgerId),
          listCategories(ledgerId, { includeArchived }),
        ])

        this.groups = groups
        this.categories = categories
      } finally {
        this.loading = false
      }
    },

    async addGroup(payload) {
      const ledgerStore = useLedgerStore()
      await createCategoryGroup(ledgerStore.activeLedgerId, payload)
      await this.load()
    },

    async addCategory(payload) {
      const ledgerStore = useLedgerStore()
      await createCategory(ledgerStore.activeLedgerId, payload)
      await this.load()
    },

    async removeCategory(categoryId) {
      const ledgerStore = useLedgerStore()
      await deleteCategoryIfUnused(ledgerStore.activeLedgerId, categoryId)
      await this.load()
    },

    async removeGroup(groupId) {
      const ledgerStore = useLedgerStore()
      await deleteCategoryGroupIfUnused(ledgerStore.activeLedgerId, groupId)
      await this.load()
    },

    async pickDefaultCategory(kind) {
      const ledgerStore = useLedgerStore()
      return findFirstCategoryByKind(ledgerStore.activeLedgerId, kind)
    },
  },
})
