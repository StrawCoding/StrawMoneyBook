import { defineStore } from 'pinia'
import { createLedger, deleteLedger, listLedgers, renameLedger } from '@/core/repositories/ledger.repo'
import { ensureLedgerDefaults } from '@/core/services/seed.service'
import { useAccountStore } from '@/ui/stores/account.store'
import { useCategoryStore } from '@/ui/stores/category.store'
import { useTransactionStore } from '@/ui/stores/transaction.store'
import { useBudgetStore } from '@/ui/stores/budget.store'
import { useLoanStore } from '@/ui/stores/loan.store'
import { useReimbursementStore } from '@/ui/stores/reimbursement.store'

const ACTIVE_LEDGER_KEY = 'straw.active_ledger_id'

export const useLedgerStore = defineStore('ledger', {
  state: () => ({
    ledgers: [],
    activeLedgerId: '',
    loading: false,
    ready: false,
  }),

  getters: {
    activeLedger(state) {
      return state.ledgers.find((ledger) => ledger.id === state.activeLedgerId) ?? null
    },
  },

  actions: {
    async init() {
      this.loading = true
      try {
        await this.refresh()

        if (this.ledgers.length === 0) {
          const ledger = await createLedger({
            name: '我的帳本',
            currencyCode: 'TWD',
            timezone: 'Asia/Taipei',
            color: '#e8a228',
          })
          await ensureLedgerDefaults(ledger.id)
          await this.refresh()
        }

        const cachedLedgerId = localStorage.getItem(ACTIVE_LEDGER_KEY)
        if (cachedLedgerId && this.ledgers.some((item) => item.id === cachedLedgerId)) {
          this.activeLedgerId = cachedLedgerId
        } else {
          this.activeLedgerId = this.ledgers[0]?.id ?? ''
        }

        this.persistActive()
        this.ready = true
      } finally {
        this.loading = false
      }
    },

    async refresh() {
      this.ledgers = await listLedgers()
    },

    persistActive() {
      if (this.activeLedgerId) {
        localStorage.setItem(ACTIVE_LEDGER_KEY, this.activeLedgerId)
      }
    },

    async switchLedger(nextLedgerId) {
      if (!nextLedgerId || nextLedgerId === this.activeLedgerId) return
      this.activeLedgerId = nextLedgerId
      this.persistActive()

      const accountStore = useAccountStore()
      const categoryStore = useCategoryStore()
      const transactionStore = useTransactionStore()
      const budgetStore = useBudgetStore()
      const loanStore = useLoanStore()
      const reimbursementStore = useReimbursementStore()

      await Promise.all([
        accountStore.load(),
        categoryStore.load(),
        transactionStore.loadRecent(),
        budgetStore.loadCurrentMonth(),
        loanStore.load(),
        reimbursementStore.load(),
      ])
    },

    async addLedger(input) {
      const ledger = await createLedger(input)
      await ensureLedgerDefaults(ledger.id)
      await this.refresh()
      await this.switchLedger(ledger.id)
    },

    async renameLedger(ledgerId, name) {
      await renameLedger(ledgerId, name)
      await this.refresh()
    },

    async removeLedger(ledgerId) {
      if (this.ledgers.length <= 1) {
        throw new Error('至少需要保留一個帳本')
      }

      await deleteLedger(ledgerId)
      await this.refresh()

      if (this.activeLedgerId === ledgerId) {
        this.activeLedgerId = this.ledgers[0]?.id ?? ''
      }

      this.persistActive()
      await this.switchLedger(this.activeLedgerId)
    },
  },
})
