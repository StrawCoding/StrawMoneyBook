const STORAGE_KEY = 'strawmoneybook.theme.primary'
const DEFAULT_PRIMARY = '#e8a228'

function normalizeHex(input) {
  const raw = String(input ?? '').trim()
  const hex = raw.startsWith('#') ? raw.slice(1) : raw
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return null
  return `#${hex.toLowerCase()}`
}

function hexToRgb(hex) {
  const normalized = normalizeHex(hex)
  if (!normalized) return null
  const value = normalized.slice(1)
  return {
    r: Number.parseInt(value.slice(0, 2), 16),
    g: Number.parseInt(value.slice(2, 4), 16),
    b: Number.parseInt(value.slice(4, 6), 16),
  }
}

function rgbToHex(r, g, b) {
  const toPart = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')
  return `#${toPart(r)}${toPart(g)}${toPart(b)}`
}

function tint(hex, ratio = 0.45) {
  const rgb = hexToRgb(hex)
  if (!rgb) return DEFAULT_PRIMARY
  return rgbToHex(
    rgb.r + (255 - rgb.r) * ratio,
    rgb.g + (255 - rgb.g) * ratio,
    rgb.b + (255 - rgb.b) * ratio,
  )
}

function contrastText(hex) {
  const rgb = hexToRgb(hex)
  if (!rgb) return '#1a1207'
  // Perceived brightness (YIQ) to choose readable text color on primary surfaces.
  const yiq = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000
  return yiq >= 150 ? '#1a1207' : '#f6fbff'
}

export function applyThemeColor(primaryHex) {
  const primary = normalizeHex(primaryHex) ?? DEFAULT_PRIMARY
  const root = document.documentElement
  root.style.setProperty('--primary', primary)
  root.style.setProperty('--primary-soft', tint(primary, 0.45))
  root.style.setProperty('--primary-contrast', contrastText(primary))
  return primary
}

export function saveThemeColor(primaryHex) {
  const primary = applyThemeColor(primaryHex)
  localStorage.setItem(STORAGE_KEY, primary)
  return primary
}

export function resetThemeColor() {
  localStorage.removeItem(STORAGE_KEY)
  return applyThemeColor(DEFAULT_PRIMARY)
}

export function loadThemeColor() {
  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) return applyThemeColor(DEFAULT_PRIMARY)
  return applyThemeColor(stored)
}

export function getDefaultThemeColor() {
  return DEFAULT_PRIMARY
}
