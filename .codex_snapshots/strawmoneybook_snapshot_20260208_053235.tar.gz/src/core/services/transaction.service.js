import {
  addTransaction,
  addTransfer,
  updateTransactionById,
  findTransactionById,
  softDeleteTransactionById,
  softDeleteTransferGroup,
} from '@/core/repositories/transaction.repo'

function assertPositiveAmount(amountMinor) {
  if (!Number.isFinite(Number(amountMinor)) || Number(amountMinor) <= 0) {
    throw new Error('amountMinor 必須為大於 0 的數字')
  }
}

export async function createExpense(ledgerId, payload) {
  assertPositiveAmount(payload.amountMinor)
  if (!payload.accountId || !payload.categoryId) {
    throw new Error('expense 需要 accountId 與 categoryId')
  }

  return addTransaction(ledgerId, {
    ...payload,
    type: 'expense',
    amountMinor: Math.abs(Number(payload.amountMinor)) * -1,
    isReimbursable: Boolean(payload.isReimbursable),
    reimbursementState: payload.isReimbursable ? 'pending' : 'none',
    occurredAt: payload.occurredAt ?? new Date().toISOString(),
  })
}

export async function createIncome(ledgerId, payload) {
  assertPositiveAmount(payload.amountMinor)
  if (!payload.accountId || !payload.categoryId) {
    throw new Error('income 需要 accountId 與 categoryId')
  }

  return addTransaction(ledgerId, {
    ...payload,
    type: 'income',
    amountMinor: Math.abs(Number(payload.amountMinor)),
    isReimbursable: false,
    reimbursementState: 'none',
    occurredAt: payload.occurredAt ?? new Date().toISOString(),
  })
}

export async function createAdjustment(ledgerId, payload) {
  if (!payload.accountId) {
    throw new Error('adjustment 需要 accountId')
  }
  if (!Number.isFinite(Number(payload.amountMinor)) || Number(payload.amountMinor) === 0) {
    throw new Error('adjustment amountMinor 不能為 0')
  }

  return addTransaction(ledgerId, {
    ...payload,
    type: 'adjustment',
    amountMinor: Number(payload.amountMinor),
    isReimbursable: false,
    reimbursementState: 'none',
    occurredAt: payload.occurredAt ?? new Date().toISOString(),
  })
}

export async function createTransfer(ledgerId, payload) {
  assertPositiveAmount(payload.amountMinor)

  if (!payload.fromAccountId || !payload.toAccountId) {
    throw new Error('transfer 需要 fromAccountId 與 toAccountId')
  }

  if (payload.fromAccountId === payload.toAccountId) {
    throw new Error('轉出與轉入帳戶不可相同')
  }

  return addTransfer(ledgerId, {
    ...payload,
    occurredAt: payload.occurredAt ?? new Date().toISOString(),
    amountMinor: Number(payload.amountMinor),
  })
}

export async function updateManualTransaction(ledgerId, txId, payload) {
  if (!txId) {
    throw new Error('缺少交易 ID')
  }
  if (payload.type === 'transfer') {
    throw new Error('目前不支援編輯轉帳交易')
  }
  if (!payload.accountId) {
    throw new Error('請選擇帳戶')
  }
  if (!payload.occurredAt) {
    throw new Error('請選擇交易時間')
  }

  let amountMinor = Number(payload.amountMinor)
  if (payload.type === 'expense' || payload.type === 'income') {
    assertPositiveAmount(amountMinor)
    amountMinor = Math.abs(amountMinor)
    amountMinor = payload.type === 'expense' ? amountMinor * -1 : amountMinor
    if (!payload.categoryId) {
      throw new Error('請選擇分類')
    }
  } else if (payload.type === 'adjustment') {
    if (!Number.isFinite(amountMinor) || amountMinor === 0) {
      throw new Error('調整金額不可為 0')
    }
  } else {
    throw new Error('不支援的交易類型')
  }

  const isReimbursable = payload.type === 'expense' && Boolean(payload.isReimbursable)

  await updateTransactionById(ledgerId, txId, {
    accountId: payload.accountId,
    peerAccountId: null,
    categoryId: payload.type === 'adjustment' ? null : payload.categoryId ?? null,
    amountMinor,
    occurredAt: payload.occurredAt,
    note: payload.note ?? null,
    isReimbursable,
    reimbursementState: isReimbursable ? 'pending' : 'none',
  })
}

export async function deleteManualTransaction(ledgerId, txId) {
  if (!txId) {
    throw new Error('缺少交易 ID')
  }

  const target = await findTransactionById(ledgerId, txId)
  if (!target) {
    throw new Error('找不到交易資料')
  }

  if (target.type === 'transfer' && target.transfer_group_id) {
    await softDeleteTransferGroup(ledgerId, target.transfer_group_id)
    return
  }

  await softDeleteTransactionById(ledgerId, txId)
}
