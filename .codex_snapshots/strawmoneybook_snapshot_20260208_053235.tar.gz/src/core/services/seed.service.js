import { listAccountGroups, listAccounts, createAccountGroup, createAccount } from '@/core/repositories/account.repo'
import {
  listCategoryGroups,
  listCategories,
  createCategoryGroup,
  createCategory,
} from '@/core/repositories/category.repo'

export async function ensureLedgerDefaults(ledgerId) {
  const groups = await listAccountGroups(ledgerId)
  if (groups.length === 0) {
    const cashGroup = await createAccountGroup(ledgerId, {
      name: '現金',
      type: 'cash',
      sortOrder: 0,
    })

    const bankGroup = await createAccountGroup(ledgerId, {
      name: '銀行',
      type: 'bank',
      sortOrder: 1,
    })

    await createAccount(ledgerId, {
      groupId: cashGroup.id,
      name: '錢包',
      openingBalanceMinor: 0,
      sortOrder: 0,
    })

    await createAccount(ledgerId, {
      groupId: bankGroup.id,
      name: '第一銀行',
      openingBalanceMinor: 0,
      sortOrder: 0,
    })
  } else if ((await listAccounts(ledgerId)).length === 0) {
    await createAccount(ledgerId, {
      groupId: groups[0].id,
      name: '預設帳戶',
      openingBalanceMinor: 0,
      sortOrder: 0,
    })
  }

  const categoryGroups = await listCategoryGroups(ledgerId)
  const categories = await listCategories(ledgerId)

  if (categoryGroups.length === 0 || categories.length === 0) {
    const expenseGroup = await createCategoryGroup(ledgerId, {
      name: '飲食',
      kind: 'expense',
      sortOrder: 0,
    })

    const incomeGroup = await createCategoryGroup(ledgerId, {
      name: '收入',
      kind: 'income',
      sortOrder: 1,
    })

    await createCategory(ledgerId, {
      groupId: expenseGroup.id,
      name: '早餐',
      kind: 'expense',
      sortOrder: 0,
    })

    await createCategory(ledgerId, {
      groupId: expenseGroup.id,
      name: '午餐',
      kind: 'expense',
      sortOrder: 1,
    })

    await createCategory(ledgerId, {
      groupId: incomeGroup.id,
      name: '薪資',
      kind: 'income',
      sortOrder: 0,
    })
  }
}
