import { withTransaction } from '@/core/db/sqlite'
import { nowIso } from '@/core/utils/id'
import { ensureCounterpartyByName } from '@/core/repositories/counterparty.repo'
import {
  addTransaction,
  findReimbursementSettlementIncomeTx,
  markTransactionReimbursed,
} from '@/core/repositories/transaction.repo'
import {
  archiveCategory,
  createCategory,
  createCategoryGroup,
  listCategories,
  listCategoryGroups,
} from '@/core/repositories/category.repo'
import {
  createReimbursement,
  createReimbursementItem,
  findTransactionByIdempotencyKey,
  getReimbursementById,
  listReimbursementItems,
  listReimbursements,
  recomputeReimbursementTotal,
  setReimbursementPaid,
  updateReimbursementStatus,
} from '@/core/repositories/reimbursement.repo'

const ALLOWED_TRANSITIONS = {
  draft: ['submitted'],
  submitted: ['in_review', 'approved', 'rejected'],
  in_review: ['approved', 'rejected'],
  approved: ['paid', 'rejected'],
  rejected: ['draft'],
  paid: [],
}

function normalizeAmountMinor(amountMinor) {
  const value = Math.round(Number(amountMinor))
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error('金額必須大於 0')
  }
  return value
}

function assertCanTransition(currentStatus, nextStatus) {
  const allowed = ALLOWED_TRANSITIONS[currentStatus] ?? []
  if (!allowed.includes(nextStatus)) {
    throw new Error(`狀態不可由 ${currentStatus} 轉為 ${nextStatus}`)
  }
}

async function ensureHiddenReimbursementCategory(ledgerId) {
  const categories = await listCategories(ledgerId, { includeArchived: true })
  const existing = categories.find((item) => item.name === '報銷' && (item.kind === 'income' || item.kind === 'both'))
  if (existing) {
    if (!Number(existing.is_archived)) {
      await archiveCategory(ledgerId, existing.id)
    }
    return existing.id
  }

  const groups = await listCategoryGroups(ledgerId)
  let group = groups.find((item) => (item.kind === 'income' || item.kind === 'both') && !Number(item.is_archived))

  if (!group) {
    group = await createCategoryGroup(ledgerId, {
      name: '收入',
      kind: 'income',
      sortOrder: groups.length,
    })
  }

  const created = await createCategory(ledgerId, {
    groupId: group.id,
    name: '報銷',
    kind: 'income',
    isBudgetable: 0,
    sortOrder: categories.filter((item) => item.group_id === group.id).length,
  })
  await archiveCategory(ledgerId, created.id)
  return created.id
}

export async function loadReimbursementDashboard(ledgerId) {
  const claims = await listReimbursements(ledgerId)
  const pendingCount = claims.filter((item) => item.status !== 'paid' && item.status !== 'rejected').length
  const pendingTotal = claims
    .filter((item) => item.status !== 'paid' && item.status !== 'rejected')
    .reduce((total, item) => total + Number(item.total_minor ?? 0), 0)

  return {
    claims,
    summary: {
      pendingCount,
      pendingTotal,
    },
  }
}

export async function createReimbursementDraft(ledgerId, payload) {
  if (!payload.title?.trim()) {
    throw new Error('請輸入報銷標題')
  }

  if (!Array.isArray(payload.items) || payload.items.length === 0) {
    throw new Error('至少需要一筆報銷明細')
  }

  return withTransaction(async () => {
    const counterpartyId = await ensureCounterpartyByName(ledgerId, payload.counterpartyName ?? '')

    const claim = await createReimbursement(ledgerId, {
      title: payload.title.trim(),
      counterpartyId,
      status: 'draft',
      note: payload.note ?? null,
    })

    for (const [index, item] of payload.items.entries()) {
      const amountMinor = normalizeAmountMinor(item.amountMinor)
      await createReimbursementItem(ledgerId, {
        reimbursementId: claim.id,
        sourceType: item.sourceType ?? 'manual',
        transactionId: item.transactionId ?? null,
        categoryId: item.categoryId ?? null,
        accountId: item.accountId ?? null,
        description: item.description ?? `明細 ${index + 1}`,
        amountMinor,
        occurredAt: item.occurredAt ?? nowIso(),
      })
    }

    return recomputeReimbursementTotal(ledgerId, claim.id)
  })
}

export async function getReimbursementDetail(ledgerId, reimbursementId) {
  const claim = await getReimbursementById(ledgerId, reimbursementId)
  if (!claim) {
    throw new Error('找不到報銷資料')
  }

  const items = await listReimbursementItems(ledgerId, reimbursementId)
  return { claim, items }
}

export async function transitionReimbursementStatus(ledgerId, reimbursementId, nextStatus) {
  return withTransaction(async () => {
    const claim = await getReimbursementById(ledgerId, reimbursementId)
    if (!claim) {
      throw new Error('找不到報銷資料')
    }

    assertCanTransition(claim.status, nextStatus)

    if (nextStatus === 'paid') {
      throw new Error('paid 狀態請使用入帳流程')
    }

    return updateReimbursementStatus(ledgerId, reimbursementId, nextStatus)
  })
}

export async function markReimbursementPaid(ledgerId, payload) {
  if (!payload.reimbursementId) {
    throw new Error('reimbursementId 為必填')
  }

  if (!payload.accountId) {
    throw new Error('報銷入帳必須指定帳戶')
  }

  return withTransaction(async () => {
    const claim = await getReimbursementById(ledgerId, payload.reimbursementId)
    if (!claim) {
      throw new Error('找不到報銷資料')
    }

    if (!['approved', 'in_review', 'submitted', 'paid'].includes(claim.status)) {
      throw new Error(`狀態 ${claim.status} 不能入帳`)
    }

    const idempotencyKey = `reim_paid_${claim.id}`

    if (claim.status === 'paid' && claim.paid_tx_id) {
      return {
        alreadyProcessed: true,
        reimbursementId: claim.id,
        paidTxId: claim.paid_tx_id,
      }
    }

    const existingTx = await findTransactionByIdempotencyKey(ledgerId, idempotencyKey)
    if (existingTx) {
      const updated = await setReimbursementPaid(ledgerId, claim.id, {
        paidTxId: existingTx.id,
        idempotencyKey,
      })
      return {
        alreadyProcessed: true,
        reimbursementId: updated.id,
        paidTxId: existingTx.id,
      }
    }

    const totalMinor = Number(claim.total_minor ?? 0)
    if (totalMinor <= 0) {
      throw new Error('報銷總額必須大於 0 才能入帳')
    }

    const txId = await addTransaction(ledgerId, {
      type: 'income',
      accountId: payload.accountId,
      categoryId: payload.categoryId ?? null,
      amountMinor: totalMinor,
      occurredAt: payload.paidAt ?? nowIso(),
      note: payload.note ?? `報銷入帳：${claim.title}`,
      originType: 'reimbursement',
      externalRefId: claim.id,
      idempotencyKey,
    })

    const updated = await setReimbursementPaid(ledgerId, claim.id, {
      paidTxId: txId,
      idempotencyKey,
    })

    return {
      alreadyProcessed: false,
      reimbursementId: updated.id,
      paidTxId: txId,
    }
  })
}

export async function settleReimbursableExpense(ledgerId, payload) {
  if (!payload?.txId) {
    throw new Error('txId 為必填')
  }

  const amountMinor = Math.round(Number(payload.amountMinor ?? 0))

  return withTransaction(async () => {
    await markTransactionReimbursed(ledgerId, payload.txId, true)

    if (!payload.accountId) {
      throw new Error('請選擇入帳帳戶')
    }

    if (!Number.isFinite(amountMinor) || amountMinor <= 0) {
      throw new Error('報銷金額必須大於 0')
    }

    const existing = await findReimbursementSettlementIncomeTx(ledgerId, payload.txId)
    if (existing) {
      return { marked: true, createdIncome: true, alreadyExists: true, incomeTxId: existing.id }
    }

    const reimbursementCategoryId = await ensureHiddenReimbursementCategory(ledgerId)

    const incomeTxId = await addTransaction(ledgerId, {
      type: 'income',
      accountId: payload.accountId,
      categoryId: reimbursementCategoryId,
      amountMinor,
      occurredAt: payload.occurredAt ?? nowIso(),
      note: payload.note ?? '報銷入帳',
      originType: 'reimbursement',
      externalRefId: payload.txId,
    })

    return { marked: true, createdIncome: true, incomeTxId }
  })
}
