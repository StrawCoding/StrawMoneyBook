import { query, run } from '@/core/db/sqlite'
import { createId, nowIso } from '@/core/utils/id'
import { firstRow, rowsOf } from '@/core/repositories/base.repo'

export async function listLedgers() {
  const result = await query(
    `SELECT id, name, currency_code, timezone, color, icon, is_archived, created_at, updated_at
     FROM ledgers
     WHERE deleted_at IS NULL
     ORDER BY created_at ASC;`,
  )
  return rowsOf(result)
}

export async function getLedger(ledgerId) {
  const result = await query(
    `SELECT id, name, currency_code, timezone, color, icon, is_archived, created_at, updated_at
     FROM ledgers
     WHERE id = ? AND deleted_at IS NULL
     LIMIT 1;`,
    [ledgerId],
  )
  return firstRow(result)
}

export async function createLedger(input) {
  const id = input.id ?? createId('ledger')
  const now = nowIso()

  await run(
    `INSERT INTO ledgers (
      id, name, currency_code, timezone, color, icon, is_archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?);`,
    [
      id,
      input.name,
      input.currencyCode ?? 'TWD',
      input.timezone ?? 'Asia/Taipei',
      input.color ?? null,
      input.icon ?? null,
      now,
      now,
    ],
  )

  return getLedger(id)
}

export async function renameLedger(ledgerId, name) {
  await run('UPDATE ledgers SET name = ?, updated_at = ? WHERE id = ?;', [name, nowIso(), ledgerId])
  return getLedger(ledgerId)
}

export async function deleteLedger(ledgerId) {
  await run('DELETE FROM ledgers WHERE id = ?;', [ledgerId])
}
