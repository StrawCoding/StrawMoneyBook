import { query, run } from '@/core/db/sqlite'
import { createId, nowIso } from '@/core/utils/id'
import { assertLedgerId, rowsOf, firstRow } from '@/core/repositories/base.repo'

export async function listCategoryGroups(ledgerId) {
  assertLedgerId(ledgerId)
  const result = await query(
    `SELECT ledger_id, id, name, kind, sort_order, is_archived
     FROM category_groups
     WHERE ledger_id = ? AND deleted_at IS NULL
     ORDER BY sort_order ASC, created_at ASC;`,
    [ledgerId],
  )
  return rowsOf(result)
}

export async function listCategories(ledgerId, options = {}) {
  assertLedgerId(ledgerId)
  const includeArchived = Boolean(options.includeArchived)
  const result = await query(
    `SELECT ledger_id, id, group_id, name, kind, is_budgetable, sort_order, is_archived
     FROM categories
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND (? = 1 OR is_archived = 0)
     ORDER BY sort_order ASC, created_at ASC;`,
    [ledgerId, includeArchived ? 1 : 0],
  )
  return rowsOf(result)
}

export async function createCategoryGroup(ledgerId, input) {
  assertLedgerId(ledgerId)
  const id = input.id ?? createId('cg')
  const now = nowIso()

  await run(
    `INSERT INTO category_groups (
      ledger_id, id, name, kind, sort_order, is_archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, 0, ?, ?);`,
    [ledgerId, id, input.name, input.kind ?? 'expense', input.sortOrder ?? 0, now, now],
  )

  return { ledger_id: ledgerId, id, ...input }
}

export async function createCategory(ledgerId, input) {
  assertLedgerId(ledgerId)
  const id = input.id ?? createId('cat')
  const now = nowIso()

  await run(
    `INSERT INTO categories (
      ledger_id, id, group_id, name, kind, is_budgetable, sort_order, is_archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?);`,
    [
      ledgerId,
      id,
      input.groupId,
      input.name,
      input.kind ?? 'expense',
      input.isBudgetable ?? 1,
      input.sortOrder ?? 0,
      now,
      now,
    ],
  )

  return { ledger_id: ledgerId, id, ...input }
}

export async function countCategoryTransactions(ledgerId, categoryId) {
  const result = await query(
    `SELECT COUNT(*) AS count
     FROM transactions
     WHERE ledger_id = ? AND category_id = ? AND deleted_at IS NULL;`,
    [ledgerId, categoryId],
  )
  return Number(firstRow(result)?.count ?? 0)
}

export async function archiveCategory(ledgerId, categoryId) {
  await run('UPDATE categories SET is_archived = 1, updated_at = ? WHERE ledger_id = ? AND id = ?;', [
    nowIso(),
    ledgerId,
    categoryId,
  ])
}

export async function archiveCategoryGroup(ledgerId, groupId) {
  await run('UPDATE category_groups SET is_archived = 1, updated_at = ? WHERE ledger_id = ? AND id = ?;', [
    nowIso(),
    ledgerId,
    groupId,
  ])
}

export async function archiveCategoriesByGroup(ledgerId, groupId) {
  await run('UPDATE categories SET is_archived = 1, updated_at = ? WHERE ledger_id = ? AND group_id = ?;', [
    nowIso(),
    ledgerId,
    groupId,
  ])
}

export async function deleteCategoryGroupById(ledgerId, groupId) {
  await run('DELETE FROM category_groups WHERE ledger_id = ? AND id = ?;', [ledgerId, groupId])
}

export async function deleteCategoriesByGroup(ledgerId, groupId) {
  await run('DELETE FROM categories WHERE ledger_id = ? AND group_id = ?;', [ledgerId, groupId])
}

export async function countCategoryTransactionsByGroup(ledgerId, groupId) {
  const result = await query(
    `SELECT COUNT(*) AS count
     FROM transactions t
     INNER JOIN categories c
       ON c.ledger_id = t.ledger_id
      AND c.id = t.category_id
     WHERE t.ledger_id = ?
       AND c.group_id = ?
       AND t.deleted_at IS NULL;`,
    [ledgerId, groupId],
  )
  return Number(firstRow(result)?.count ?? 0)
}

export async function countBudgetItemReferencesByGroup(ledgerId, groupId) {
  const result = await query(
    `SELECT COUNT(*) AS count
     FROM budget_items bi
     INNER JOIN categories c
       ON c.ledger_id = bi.ledger_id
      AND c.id = bi.category_id
     WHERE bi.ledger_id = ?
       AND c.group_id = ?;`,
    [ledgerId, groupId],
  )
  return Number(firstRow(result)?.count ?? 0)
}

export async function deleteCategoryIfUnused(ledgerId, categoryId) {
  const count = await countCategoryTransactions(ledgerId, categoryId)
  if (count > 0) {
    await archiveCategory(ledgerId, categoryId)
    return { archived: true, deleted: false }
  }

  await run('DELETE FROM categories WHERE ledger_id = ? AND id = ?;', [ledgerId, categoryId])
  return { archived: false, deleted: true }
}

export async function deleteCategoryGroupIfUnused(ledgerId, groupId) {
  assertLedgerId(ledgerId)
  const txCount = await countCategoryTransactionsByGroup(ledgerId, groupId)
  const budgetRefCount = await countBudgetItemReferencesByGroup(ledgerId, groupId)

  if (txCount > 0 || budgetRefCount > 0) {
    await archiveCategoryGroup(ledgerId, groupId)
    await archiveCategoriesByGroup(ledgerId, groupId)
    return { archived: true, deleted: false, txCount, budgetRefCount }
  }

  await deleteCategoriesByGroup(ledgerId, groupId)
  await deleteCategoryGroupById(ledgerId, groupId)
  return { archived: false, deleted: true, txCount, budgetRefCount }
}

export async function findFirstCategoryByKind(ledgerId, kind) {
  const result = await query(
    `SELECT id, group_id, name, kind
     FROM categories
     WHERE ledger_id = ?
       AND is_archived = 0
       AND deleted_at IS NULL
       AND (kind = ? OR kind = 'both')
     ORDER BY sort_order ASC, created_at ASC
     LIMIT 1;`,
    [ledgerId, kind],
  )

  return firstRow(result)
}
