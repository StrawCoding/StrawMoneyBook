import { query, run, withTransaction } from '@/core/db/sqlite'
import { createId, nowIso } from '@/core/utils/id'
import { assertLedgerId, rowsOf } from '@/core/repositories/base.repo'

function monthRangeUtc(monthKey) {
  const [year, month] = monthKey.split('-').map((part) => Number(part))
  const start = new Date(year, month - 1, 1, 0, 0, 0)
  const end = new Date(year, month, 1, 0, 0, 0)

  return {
    startUtc: start.toISOString(),
    endUtc: end.toISOString(),
  }
}

function yearRangeUtc(yearKey) {
  const year = Number(yearKey)
  const start = new Date(year, 0, 1, 0, 0, 0)
  const end = new Date(year + 1, 0, 1, 0, 0, 0)
  return {
    startUtc: start.toISOString(),
    endUtc: end.toISOString(),
  }
}

function dayRangeUtc(dayKey) {
  const [year, month, day] = String(dayKey ?? '').split('-').map((part) => Number(part))
  const start = new Date(year, month - 1, day, 0, 0, 0)
  const end = new Date(year, month - 1, day + 1, 0, 0, 0)
  return {
    startUtc: start.toISOString(),
    endUtc: end.toISOString(),
  }
}

export async function listRecentTransactions(ledgerId, limit = 20) {
  assertLedgerId(ledgerId)

  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ? AND deleted_at IS NULL
     ORDER BY occurred_at DESC, created_at DESC
     LIMIT ?;`,
    [ledgerId, limit],
  )

  return rowsOf(result)
}

export async function listTransactionsByMonth(ledgerId, monthKey) {
  assertLedgerId(ledgerId)

  const { startUtc, endUtc } = monthRangeUtc(monthKey)
  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND occurred_at >= ?
       AND occurred_at < ?
     ORDER BY occurred_at DESC, created_at DESC;`,
    [ledgerId, startUtc, endUtc],
  )

  return rowsOf(result)
}

export async function listTransactionsByYear(ledgerId, yearKey) {
  assertLedgerId(ledgerId)
  const { startUtc, endUtc } = yearRangeUtc(yearKey)
  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND occurred_at >= ?
       AND occurred_at < ?
     ORDER BY occurred_at DESC, created_at DESC;`,
    [ledgerId, startUtc, endUtc],
  )

  return rowsOf(result)
}

export async function listTransactionsByDay(ledgerId, dayKey) {
  assertLedgerId(ledgerId)
  const { startUtc, endUtc } = dayRangeUtc(dayKey)
  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND occurred_at >= ?
       AND occurred_at < ?
     ORDER BY occurred_at DESC, created_at DESC;`,
    [ledgerId, startUtc, endUtc],
  )

  return rowsOf(result)
}

export async function listAllTransactions(ledgerId) {
  assertLedgerId(ledgerId)
  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ?
       AND deleted_at IS NULL
     ORDER BY occurred_at DESC, created_at DESC;`,
    [ledgerId],
  )
  return rowsOf(result)
}

export async function listTransactionsByAccount(ledgerId, accountId, limit = 100) {
  assertLedgerId(ledgerId)

  const result = await query(
    `SELECT ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
            category_id, amount_minor, occurred_at, note, location, tags_json,
            origin_type, external_ref_id, is_reimbursable, reimbursement_state,
            reimbursed_at, created_at
     FROM transactions
     WHERE ledger_id = ?
       AND account_id = ?
       AND deleted_at IS NULL
     ORDER BY occurred_at DESC, created_at DESC
     LIMIT ?;`,
    [ledgerId, accountId, limit],
  )

  return rowsOf(result)
}

export async function listReimbursementTransactions(ledgerId, state) {
  assertLedgerId(ledgerId)

  const normalizedState = state === 'reimbursed' ? 'reimbursed' : 'pending'

  const result = await query(
    `SELECT t.ledger_id, t.id, t.type, t.account_id, t.category_id, t.amount_minor,
            t.occurred_at, t.note, t.is_reimbursable, t.reimbursement_state, t.reimbursed_at,
            c.name AS category_name
     FROM transactions t
     LEFT JOIN categories c
       ON c.ledger_id = t.ledger_id
      AND c.id = t.category_id
     WHERE t.ledger_id = ?
       AND t.deleted_at IS NULL
       AND t.type = 'expense'
       AND t.is_reimbursable = 1
       AND t.reimbursement_state = ?
     ORDER BY t.occurred_at DESC, t.created_at DESC;`,
    [ledgerId, normalizedState],
  )

  return rowsOf(result)
}

export async function findReimbursementSettlementIncomeTx(ledgerId, expenseTxId) {
  assertLedgerId(ledgerId)
  const result = await query(
    `SELECT id, amount_minor, occurred_at
     FROM transactions
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND type = 'income'
       AND origin_type = 'reimbursement'
       AND external_ref_id = ?
     ORDER BY created_at DESC
     LIMIT 1;`,
    [ledgerId, expenseTxId],
  )
  return rowsOf(result)[0] ?? null
}

export async function markTransactionReimbursed(ledgerId, txId, reimbursed) {
  assertLedgerId(ledgerId)

  await run(
    `UPDATE transactions
     SET reimbursement_state = ?,
         reimbursed_at = ?,
         updated_at = ?
     WHERE ledger_id = ?
       AND id = ?
       AND is_reimbursable = 1;`,
    [reimbursed ? 'reimbursed' : 'pending', reimbursed ? nowIso() : null, nowIso(), ledgerId, txId],
  )
}

export async function updateTransactionById(ledgerId, txId, input) {
  assertLedgerId(ledgerId)

  await run(
    `UPDATE transactions
     SET account_id = ?,
         peer_account_id = ?,
         category_id = ?,
         amount_minor = ?,
         occurred_at = ?,
         note = ?,
         is_reimbursable = ?,
         reimbursement_state = ?,
         updated_at = ?
     WHERE ledger_id = ?
       AND id = ?
       AND deleted_at IS NULL;`,
    [
      input.accountId,
      input.peerAccountId ?? null,
      input.categoryId ?? null,
      input.amountMinor,
      input.occurredAt,
      input.note ?? null,
      input.isReimbursable ? 1 : 0,
      input.reimbursementState ?? 'none',
      nowIso(),
      ledgerId,
      txId,
    ],
  )
}

export async function findTransactionById(ledgerId, txId) {
  assertLedgerId(ledgerId)
  const result = await query(
    `SELECT id, type, transfer_group_id
     FROM transactions
     WHERE ledger_id = ?
       AND id = ?
       AND deleted_at IS NULL
     LIMIT 1;`,
    [ledgerId, txId],
  )
  return rowsOf(result)[0] ?? null
}

export async function softDeleteTransactionById(ledgerId, txId) {
  assertLedgerId(ledgerId)
  const now = nowIso()
  await run(
    `UPDATE transactions
     SET deleted_at = ?,
         updated_at = ?
     WHERE ledger_id = ?
       AND id = ?
       AND deleted_at IS NULL;`,
    [now, now, ledgerId, txId],
  )
}

export async function softDeleteTransferGroup(ledgerId, transferGroupId) {
  assertLedgerId(ledgerId)
  const now = nowIso()
  await run(
    `UPDATE transactions
     SET deleted_at = ?,
         updated_at = ?
     WHERE ledger_id = ?
       AND transfer_group_id = ?
       AND deleted_at IS NULL;`,
    [now, now, ledgerId, transferGroupId],
  )
}

export async function addTransaction(ledgerId, input) {
  assertLedgerId(ledgerId)

  const id = input.id ?? createId('tx')
  const now = nowIso()

  await run(
    `INSERT INTO transactions (
      ledger_id, id, type, transfer_group_id, account_id, peer_account_id,
      category_id, amount_minor, occurred_at, note, location, tags_json, origin_type,
      external_ref_id, idempotency_key, is_reimbursable, reimbursement_state,
      reimbursed_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
    [
      ledgerId,
      id,
      input.type,
      input.transferGroupId ?? null,
      input.accountId,
      input.peerAccountId ?? null,
      input.categoryId ?? null,
      input.amountMinor,
      input.occurredAt,
      input.note ?? null,
      input.location ?? null,
      input.tagsJson ?? null,
      input.originType ?? 'manual',
      input.externalRefId ?? null,
      input.idempotencyKey ?? null,
      input.isReimbursable ? 1 : 0,
      input.reimbursementState ?? 'none',
      input.reimbursedAt ?? null,
      now,
      now,
    ],
  )

  return id
}

export async function addTransfer(ledgerId, input) {
  assertLedgerId(ledgerId)

  const transferGroupId = input.transferGroupId ?? createId('tf')
  const occurredAt = input.occurredAt
  const amountMinor = Math.abs(Number(input.amountMinor))

  return withTransaction(async () => {
    const outTxId = await addTransaction(ledgerId, {
      type: 'transfer',
      transferGroupId,
      accountId: input.fromAccountId,
      peerAccountId: input.toAccountId,
      amountMinor: amountMinor * -1,
      occurredAt,
      note: input.note,
      originType: input.originType ?? 'manual',
    })

    const inTxId = await addTransaction(ledgerId, {
      type: 'transfer',
      transferGroupId,
      accountId: input.toAccountId,
      peerAccountId: input.fromAccountId,
      amountMinor,
      occurredAt,
      note: input.note,
      originType: input.originType ?? 'manual',
    })

    return { transferGroupId, outTxId, inTxId }
  })
}
