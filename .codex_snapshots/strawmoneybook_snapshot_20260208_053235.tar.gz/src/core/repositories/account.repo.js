import { query, run } from '@/core/db/sqlite'
import { createId, nowIso } from '@/core/utils/id'
import { assertLedgerId, rowsOf, firstRow } from '@/core/repositories/base.repo'

export async function listAccountGroups(ledgerId) {
  assertLedgerId(ledgerId)
  const result = await query(
    `SELECT ledger_id, id, name, type, sort_order, is_archived
     FROM account_groups
     WHERE ledger_id = ? AND deleted_at IS NULL
     ORDER BY sort_order ASC, created_at ASC;`,
    [ledgerId],
  )
  return rowsOf(result)
}

export async function listAccounts(ledgerId, options = {}) {
  assertLedgerId(ledgerId)
  const includeArchived = Boolean(options.includeArchived)

  const result = await query(
    `SELECT ledger_id, id, group_id, name, account_type, allow_negative, opening_balance_minor,
            currency_code, sort_order, is_archived
     FROM accounts
     WHERE ledger_id = ?
       AND deleted_at IS NULL
       AND (? = 1 OR is_archived = 0)
     ORDER BY sort_order ASC, created_at ASC;`,
    [ledgerId, includeArchived ? 1 : 0],
  )

  return rowsOf(result)
}

export async function createAccountGroup(ledgerId, input) {
  assertLedgerId(ledgerId)
  const id = input.id ?? createId('ag')
  const now = nowIso()

  await run(
    `INSERT INTO account_groups (
      ledger_id, id, name, type, sort_order, is_archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, 0, ?, ?);`,
    [ledgerId, id, input.name, input.type ?? 'other', input.sortOrder ?? 0, now, now],
  )

  return { ledger_id: ledgerId, id, ...input }
}

export async function createAccount(ledgerId, input) {
  assertLedgerId(ledgerId)
  const id = input.id ?? createId('acc')
  const now = nowIso()

  await run(
    `INSERT INTO accounts (
      ledger_id, id, group_id, name, account_type, allow_negative, opening_balance_minor,
      currency_code, sort_order, is_archived, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?);`,
    [
      ledgerId,
      id,
      input.groupId,
      input.name,
      input.accountType ?? 'asset',
      input.allowNegative ? 1 : 0,
      input.openingBalanceMinor ?? 0,
      input.currencyCode ?? 'TWD',
      input.sortOrder ?? 0,
      now,
      now,
    ],
  )

  return { ledger_id: ledgerId, id, ...input }
}

export async function countAccountTransactions(ledgerId, accountId) {
  const result = await query(
    `SELECT COUNT(*) AS count
     FROM transactions
     WHERE ledger_id = ? AND account_id = ? AND deleted_at IS NULL;`,
    [ledgerId, accountId],
  )
  return Number(firstRow(result)?.count ?? 0)
}

export async function archiveAccount(ledgerId, accountId) {
  assertLedgerId(ledgerId)
  await run('UPDATE accounts SET is_archived = 1, updated_at = ? WHERE ledger_id = ? AND id = ?;', [
    nowIso(),
    ledgerId,
    accountId,
  ])
}

export async function deleteAccountIfUnused(ledgerId, accountId) {
  const count = await countAccountTransactions(ledgerId, accountId)
  if (count > 0) {
    await archiveAccount(ledgerId, accountId)
    return { archived: true, deleted: false }
  }

  await run('DELETE FROM accounts WHERE ledger_id = ? AND id = ?;', [ledgerId, accountId])
  return { archived: false, deleted: true }
}

export async function getAccountBalances(ledgerId, options = {}) {
  const includeArchived = Boolean(options.includeArchived)

  const result = await query(
    `SELECT
       a.ledger_id,
       a.id,
       a.group_id,
       a.name,
       a.account_type,
       a.allow_negative,
       a.currency_code,
       a.opening_balance_minor,
       a.is_archived,
       a.opening_balance_minor + COALESCE(SUM(t.amount_minor), 0) AS balance_minor
     FROM accounts a
     LEFT JOIN transactions t
       ON t.ledger_id = a.ledger_id
      AND t.account_id = a.id
      AND t.deleted_at IS NULL
     WHERE a.ledger_id = ?
       AND a.deleted_at IS NULL
       AND (? = 1 OR a.is_archived = 0)
     GROUP BY a.ledger_id, a.id
     ORDER BY a.sort_order ASC, a.created_at ASC;`,
    [ledgerId, includeArchived ? 1 : 0],
  )

  return rowsOf(result)
}
