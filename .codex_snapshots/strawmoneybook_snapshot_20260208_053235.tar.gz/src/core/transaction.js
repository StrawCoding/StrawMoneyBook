import {
  createExpense,
  createIncome,
  createAdjustment,
  createTransfer,
} from '@/core/services/transaction.service'

export const transaction = {
  createExpense,
  createIncome,
  createAdjustment,
  createTransfer,
}
