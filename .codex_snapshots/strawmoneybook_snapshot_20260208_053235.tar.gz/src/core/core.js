import { initDatabase } from '@/core/db/sqlite'
import { listLedgers, createLedger } from '@/core/repositories/ledger.repo'

export const core = {
  async init() {
    await initDatabase()
  },

  async ledgerList() {
    return listLedgers()
  },

  async createLedger(input) {
    return createLedger(input)
  },
}
