import migration001 from '@/core/db/migrations/001_init.sql?raw'
import migration002 from '@/core/db/migrations/002_transaction_reimbursement_flags.sql?raw'

const MIGRATIONS = [
  { version: 1, name: 'init_schema', sql: migration001 },
  { version: 2, name: 'transaction_reimbursement_flags', sql: migration002 },
]

const LEGACY_COLUMN_PATCHES = {
  ledgers: [
    "ALTER TABLE ledgers ADD COLUMN currency_code TEXT NOT NULL DEFAULT 'TWD';",
    "ALTER TABLE ledgers ADD COLUMN timezone TEXT NOT NULL DEFAULT 'Asia/Taipei';",
    'ALTER TABLE ledgers ADD COLUMN color TEXT;',
    'ALTER TABLE ledgers ADD COLUMN icon TEXT;',
    'ALTER TABLE ledgers ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE ledgers ADD COLUMN created_at TEXT;',
    'ALTER TABLE ledgers ADD COLUMN updated_at TEXT;',
    'ALTER TABLE ledgers ADD COLUMN deleted_at TEXT;',
  ],
  account_groups: [
    'ALTER TABLE account_groups ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE account_groups ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE account_groups ADD COLUMN deleted_at TEXT;',
    'ALTER TABLE account_groups ADD COLUMN created_at TEXT;',
    'ALTER TABLE account_groups ADD COLUMN updated_at TEXT;',
  ],
  accounts: [
    'ALTER TABLE accounts ADD COLUMN group_id TEXT;',
    "ALTER TABLE accounts ADD COLUMN account_type TEXT NOT NULL DEFAULT 'asset';",
    'ALTER TABLE accounts ADD COLUMN allow_negative INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE accounts ADD COLUMN opening_balance_minor INTEGER NOT NULL DEFAULT 0;',
    "ALTER TABLE accounts ADD COLUMN currency_code TEXT NOT NULL DEFAULT 'TWD';",
    'ALTER TABLE accounts ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE accounts ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE accounts ADD COLUMN deleted_at TEXT;',
    'ALTER TABLE accounts ADD COLUMN created_at TEXT;',
    'ALTER TABLE accounts ADD COLUMN updated_at TEXT;',
  ],
  category_groups: [
    'ALTER TABLE category_groups ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE category_groups ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE category_groups ADD COLUMN deleted_at TEXT;',
    'ALTER TABLE category_groups ADD COLUMN created_at TEXT;',
    'ALTER TABLE category_groups ADD COLUMN updated_at TEXT;',
  ],
  categories: [
    'ALTER TABLE categories ADD COLUMN group_id TEXT;',
    "ALTER TABLE categories ADD COLUMN kind TEXT NOT NULL DEFAULT 'expense';",
    'ALTER TABLE categories ADD COLUMN is_budgetable INTEGER NOT NULL DEFAULT 1;',
    'ALTER TABLE categories ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE categories ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE categories ADD COLUMN deleted_at TEXT;',
    'ALTER TABLE categories ADD COLUMN created_at TEXT;',
    'ALTER TABLE categories ADD COLUMN updated_at TEXT;',
  ],
  transactions: [
    "ALTER TABLE transactions ADD COLUMN type TEXT NOT NULL DEFAULT 'expense';",
    'ALTER TABLE transactions ADD COLUMN transfer_group_id TEXT;',
    'ALTER TABLE transactions ADD COLUMN account_id TEXT;',
    'ALTER TABLE transactions ADD COLUMN peer_account_id TEXT;',
    'ALTER TABLE transactions ADD COLUMN category_id TEXT;',
    'ALTER TABLE transactions ADD COLUMN amount_minor INTEGER;',
    'ALTER TABLE transactions ADD COLUMN occurred_at TEXT;',
    'ALTER TABLE transactions ADD COLUMN note TEXT;',
    'ALTER TABLE transactions ADD COLUMN location TEXT;',
    'ALTER TABLE transactions ADD COLUMN tags_json TEXT;',
    "ALTER TABLE transactions ADD COLUMN origin_type TEXT NOT NULL DEFAULT 'manual';",
    'ALTER TABLE transactions ADD COLUMN external_ref_id TEXT;',
    'ALTER TABLE transactions ADD COLUMN idempotency_key TEXT;',
    'ALTER TABLE transactions ADD COLUMN deleted_at TEXT;',
    'ALTER TABLE transactions ADD COLUMN created_at TEXT;',
    'ALTER TABLE transactions ADD COLUMN updated_at TEXT;',
  ],
  transaction_attachments: [
    'ALTER TABLE transaction_attachments ADD COLUMN file_uri TEXT;',
    'ALTER TABLE transaction_attachments ADD COLUMN mime_type TEXT;',
    'ALTER TABLE transaction_attachments ADD COLUMN file_size INTEGER;',
    'ALTER TABLE transaction_attachments ADD COLUMN checksum TEXT;',
    'ALTER TABLE transaction_attachments ADD COLUMN created_at TEXT;',
  ],
  counterparties: [
    'ALTER TABLE counterparties ADD COLUMN contact_json TEXT;',
    'ALTER TABLE counterparties ADD COLUMN note TEXT;',
    'ALTER TABLE counterparties ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE counterparties ADD COLUMN created_at TEXT;',
    'ALTER TABLE counterparties ADD COLUMN updated_at TEXT;',
  ],
  loans: [
    'ALTER TABLE loans ADD COLUMN counterparty_id TEXT;',
    "ALTER TABLE loans ADD COLUMN direction TEXT NOT NULL DEFAULT 'lend';",
    'ALTER TABLE loans ADD COLUMN principal_minor INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE loans ADD COLUMN interest_rule_json TEXT;',
    'ALTER TABLE loans ADD COLUMN start_date TEXT;',
    'ALTER TABLE loans ADD COLUMN due_date TEXT;',
    "ALTER TABLE loans ADD COLUMN status TEXT NOT NULL DEFAULT 'active';",
    'ALTER TABLE loans ADD COLUMN settled_at TEXT;',
    'ALTER TABLE loans ADD COLUMN note TEXT;',
    'ALTER TABLE loans ADD COLUMN created_at TEXT;',
    'ALTER TABLE loans ADD COLUMN updated_at TEXT;',
    'ALTER TABLE loans ADD COLUMN deleted_at TEXT;',
  ],
  loan_payments: [
    'ALTER TABLE loan_payments ADD COLUMN loan_id TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN account_id TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN paid_at TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN amount_minor INTEGER;',
    'ALTER TABLE loan_payments ADD COLUMN principal_component_minor INTEGER;',
    'ALTER TABLE loan_payments ADD COLUMN interest_component_minor INTEGER;',
    'ALTER TABLE loan_payments ADD COLUMN generated_tx_id TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN note TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN created_at TEXT;',
    'ALTER TABLE loan_payments ADD COLUMN updated_at TEXT;',
  ],
  reimbursements: [
    'ALTER TABLE reimbursements ADD COLUMN title TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN counterparty_id TEXT;',
    "ALTER TABLE reimbursements ADD COLUMN status TEXT NOT NULL DEFAULT 'draft';",
    'ALTER TABLE reimbursements ADD COLUMN submitted_at TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN approved_at TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN paid_at TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN paid_tx_id TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN total_minor INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE reimbursements ADD COLUMN note TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN idempotency_key TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN created_at TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN updated_at TEXT;',
    'ALTER TABLE reimbursements ADD COLUMN deleted_at TEXT;',
  ],
  reimbursement_items: [
    "ALTER TABLE reimbursement_items ADD COLUMN source_type TEXT NOT NULL DEFAULT 'manual';",
    'ALTER TABLE reimbursement_items ADD COLUMN transaction_id TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN category_id TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN account_id TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN description TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN amount_minor INTEGER;',
    'ALTER TABLE reimbursement_items ADD COLUMN occurred_at TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN attachment_uri TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN created_at TEXT;',
    'ALTER TABLE reimbursement_items ADD COLUMN updated_at TEXT;',
  ],
  budgets: [
    'ALTER TABLE budgets ADD COLUMN name TEXT;',
    'ALTER TABLE budgets ADD COLUMN include_transfers INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE budgets ADD COLUMN include_loan_repayments INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE budgets ADD COLUMN include_reimbursed_expenses INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE budgets ADD COLUMN created_at TEXT;',
    'ALTER TABLE budgets ADD COLUMN updated_at TEXT;',
    'ALTER TABLE budgets ADD COLUMN deleted_at TEXT;',
  ],
  budget_items: [
    "ALTER TABLE budget_items ADD COLUMN scope_type TEXT NOT NULL DEFAULT 'category';",
    'ALTER TABLE budget_items ADD COLUMN category_id TEXT;',
    'ALTER TABLE budget_items ADD COLUMN category_group_id TEXT;',
    'ALTER TABLE budget_items ADD COLUMN amount_minor INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE budget_items ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;',
    'ALTER TABLE budget_items ADD COLUMN created_at TEXT;',
    'ALTER TABLE budget_items ADD COLUMN updated_at TEXT;',
  ],
  app_settings: [
    'ALTER TABLE app_settings ADD COLUMN value_json TEXT;',
    'ALTER TABLE app_settings ADD COLUMN updated_at TEXT;',
  ],
  deleted_log: [
    'ALTER TABLE deleted_log ADD COLUMN payload_json TEXT;',
    'ALTER TABLE deleted_log ADD COLUMN deleted_at TEXT;',
  ],
}

function splitSqlStatements(sql) {
  return sql
    .split(';')
    .map((item) => item.trim())
    .filter(Boolean)
}

function isIgnorableMigrationError(error) {
  const message = String(error?.message ?? error ?? '').toLowerCase()
  return (
    message.includes('duplicate column name') ||
    message.includes('already exists') ||
    message.includes('duplicate index name')
  )
}

async function executeMigrationSql(db, sql) {
  const statements = splitSqlStatements(sql)

  for (const statement of statements) {
    try {
      await db.execute(`${statement};`)
    } catch (error) {
      if (!isIgnorableMigrationError(error)) {
        throw error
      }
    }
  }
}

async function tableExists(db, tableName) {
  const result = await db.query(
    `SELECT 1 AS ok
     FROM sqlite_master
     WHERE type = 'table'
       AND name = ?
     LIMIT 1;`,
    [tableName],
  )
  return Boolean(result?.values?.length)
}

async function patchLegacyTableColumns(db, tableName, alterSqlList) {
  if (!(await tableExists(db, tableName))) return

  for (const sql of alterSqlList) {
    try {
      await db.execute(sql)
    } catch (error) {
      if (!isIgnorableMigrationError(error)) {
        throw error
      }
    }
  }
}

async function patchLegacySchema(db) {
  for (const [tableName, sqlList] of Object.entries(LEGACY_COLUMN_PATCHES)) {
    await patchLegacyTableColumns(db, tableName, sqlList)
  }

  const nowExpr = "strftime('%Y-%m-%dT%H:%M:%fZ','now')"

  // Best-effort backfill for legacy rows after adding nullable columns.
  if (await tableExists(db, 'transactions')) {
    await db.execute(
      `UPDATE transactions
       SET created_at = COALESCE(created_at, ${nowExpr}),
           updated_at = COALESCE(updated_at, created_at, ${nowExpr});`,
    )
    await db.execute(
      `UPDATE transactions
       SET occurred_at = COALESCE(occurred_at, created_at, updated_at, ${nowExpr}),
           amount_minor = COALESCE(amount_minor, 0),
           origin_type = COALESCE(origin_type, 'manual');`,
    )
  }

  if (await tableExists(db, 'budgets')) {
    await db.execute(
      `UPDATE budgets
       SET created_at = COALESCE(created_at, ${nowExpr}),
           updated_at = COALESCE(updated_at, created_at, ${nowExpr}),
           include_transfers = COALESCE(include_transfers, 0),
           include_loan_repayments = COALESCE(include_loan_repayments, 0),
           include_reimbursed_expenses = COALESCE(include_reimbursed_expenses, 0);`,
    )
  }

  if (await tableExists(db, 'budget_items')) {
    await db.execute(
      `UPDATE budget_items
       SET created_at = COALESCE(created_at, ${nowExpr}),
           updated_at = COALESCE(updated_at, created_at, ${nowExpr}),
           sort_order = COALESCE(sort_order, 0),
           amount_minor = COALESCE(amount_minor, 0);`,
    )
  }

  if (await tableExists(db, 'accounts')) {
    await db.execute(
      `UPDATE accounts
       SET created_at = COALESCE(created_at, ${nowExpr}),
           updated_at = COALESCE(updated_at, created_at, ${nowExpr}),
           sort_order = COALESCE(sort_order, 0),
           opening_balance_minor = COALESCE(opening_balance_minor, 0),
           account_type = COALESCE(account_type, 'asset'),
           allow_negative = COALESCE(allow_negative, 0),
           currency_code = COALESCE(currency_code, 'TWD'),
           is_archived = COALESCE(is_archived, 0);`,
    )
  }

  if (await tableExists(db, 'categories')) {
    await db.execute(
      `UPDATE categories
       SET created_at = COALESCE(created_at, ${nowExpr}),
           updated_at = COALESCE(updated_at, created_at, ${nowExpr}),
           sort_order = COALESCE(sort_order, 0),
           kind = COALESCE(kind, 'expense'),
           is_budgetable = COALESCE(is_budgetable, 1),
           is_archived = COALESCE(is_archived, 0);`,
    )
  }

  if (await tableExists(db, 'app_settings')) {
    await db.execute(
      `UPDATE app_settings
       SET value_json = COALESCE(value_json, '{}'),
           updated_at = COALESCE(updated_at, ${nowExpr});`,
    )
  }
}

export async function runMigrations(db) {
  await patchLegacySchema(db)

  await db.execute(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
  `)

  const result = await db.query('SELECT version FROM schema_migrations ORDER BY version ASC;')
  const appliedVersions = new Set((result?.values ?? []).map((row) => row.version))

  for (const migration of MIGRATIONS) {
    if (appliedVersions.has(migration.version)) continue

    await executeMigrationSql(db, migration.sql)
    await db.run(
      'INSERT INTO schema_migrations (version, name) VALUES (?, ?);',
      [migration.version, migration.name],
    )
  }
}
