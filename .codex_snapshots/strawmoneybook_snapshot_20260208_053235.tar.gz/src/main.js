import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { Capacitor } from '@capacitor/core'
import { App as CapacitorApp } from '@capacitor/app'
import { library } from '@fortawesome/fontawesome-svg-core'
import { faHouse, faChartPie, faWallet, faGear, faPrint, faBars, faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import App from '@/ui/App.vue'
import router from '@/ui/router'
import { bootstrapApp } from '@/core/services/bootstrap.service'
import { ensureWebSqliteStoreReady } from '@/core/db/web-store'
import { useUiStore } from '@/ui/stores/ui.store'
import { loadThemeColor } from '@/ui/services/theme.service'
import '@/ui/assets/css/global.css'

library.add(faHouse, faChartPie, faWallet, faGear, faPrint, faBars, faMagnifyingGlass)

async function initSqliteWebStoreIfNeeded() {
  await ensureWebSqliteStoreReady()
}

async function main() {
  await initSqliteWebStoreIfNeeded()
  loadThemeColor()

  const app = createApp(App)
  const pinia = createPinia()

  app.component('font-awesome-icon', FontAwesomeIcon)
  app.use(pinia)
  app.use(router)
  app.mount('#app')

  if (Capacitor.getPlatform() === 'android') {
    CapacitorApp.addListener('backButton', async ({ canGoBack }) => {
      if (canGoBack && router.currentRoute.value.path !== '/') {
        await router.back()
        return
      }
      await CapacitorApp.exitApp()
    })
  }

  try {
    await bootstrapApp(pinia)
  } catch (error) {
    console.error('[bootstrap] failed', error)
    const uiStore = useUiStore(pinia)
    const message = String(error?.message ?? '未知錯誤')
    uiStore.pushToast(`初始化失敗：${message}`, 'error')
  }
}

main().catch((error) => {
  console.error('[main] fatal error', error)
})
